import { integer, sqliteTable, text } from "drizzle-orm/sqlite-core";

export const sharedProjects = sqliteTable("shared_projects", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  updatedAt: text("updated_at").notNull(),
  lastUpdatedBy: text("last_updated_by").notNull().default("Unassigned editor"),
  reports: integer("reports").notNull().default(0),
  records: integer("records").notNull().default(0),
  revision: integer("revision").notNull().default(1),
  objectKey: text("object_key").notNull(),
  sizeBytes: integer("size_bytes").notNull().default(0),
  createdAt: text("created_at").notNull(),
});
