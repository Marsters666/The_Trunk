(() => {
  const $ = id => document.getElementById(id);

  $('offlineAbout').onclick = () => $('offlineDialog').showModal();
  $('closeOffline').onclick = () => $('offlineDialog').close();

  $('emailFeedback').onclick = () => {
    const message = $('feedbackText').value.trim();
    if (!message) {
      $('feedbackStatus').textContent = 'Enter your suggestion or comment first.';
      return;
    }
    const subject = encodeURIComponent('Notifier Report Manager website feedback');
    const body = encodeURIComponent(`Notifier Report Manager 1.3.0\n${new Date().toISOString()}\n\n${message}`);
    location.href = `mailto:mike.marsters@gmail.com?subject=${subject}&body=${body}`;
    $('feedbackStatus').textContent = 'Your email app was opened. Review the message before sending.';
  };

  $('saveFeedback').onclick = () => {
    const message = $('feedbackText').value.trim();
    if (!message) {
      $('feedbackStatus').textContent = 'Enter your suggestion or comment first.';
      return;
    }
    const file = new Blob([
      `Notifier Report Manager 1.3.0\n${new Date().toISOString()}\n\n${message}`
    ], {type: 'text/plain'});
    const url = URL.createObjectURL(file);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = 'Notifier-feedback.txt';
    anchor.click();
    setTimeout(() => URL.revokeObjectURL(url), 10000);
    $('feedbackStatus').textContent = 'Feedback file downloaded. Nothing was sent automatically.';
  };

  if ('serviceWorker' in navigator) {
    addEventListener('load', () => {
      navigator.serviceWorker.register('/service-worker.js').then(registration => registration.update()).catch(() => {});
    });
  }
})();
