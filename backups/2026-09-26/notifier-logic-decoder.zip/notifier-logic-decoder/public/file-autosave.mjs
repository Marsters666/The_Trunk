// Each project has its own explicitly chosen device file for this session.
export class FileAutosave {
  constructor(report) { this.report=report; this.targets=new Map(); this.pending=0; }
  attach(id,handle) { const target={handle,tail:Promise.resolve()}; this.targets.set(id,target); }
  save(id,snapshot) {
    const target=this.targets.get(id);
    if(!target)return Promise.resolve();
    const content=JSON.stringify(snapshot);
    this.pending++;
    this.report(id,`Saving to ${target.handle.name}…`);
    target.tail=target.tail.catch(()=>{}).then(async()=>{
      const writer=await target.handle.createWritable();
      try { await writer.write(content); await writer.close(); }
      catch(error) { try { await writer.abort(); } catch {} throw error; }
      this.report(id,`Saved to ${target.handle.name} at ${new Date().toLocaleTimeString()}`);
    }).catch(error=>{this.report(id,`File save failed: ${error.message}. Your browser copy is retained. Choose the file again to retry.`);}).finally(()=>{this.pending--;});
    return target.tail;
  }
  flush() { return Promise.all([...this.targets.values()].map(target=>target.tail)); }
}
