const DB_NAME='fire-alarm-report-manager';
const DB_VERSION=1;
export const ACTIVE_PROJECT_KEY='fire-alarm-active-project-v1';

const request=request=>new Promise((resolve,reject)=>{request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error||Error('Browser storage request failed.'));});
const complete=transaction=>new Promise((resolve,reject)=>{transaction.oncomplete=resolve;transaction.onerror=()=>reject(transaction.error||Error('Browser storage transaction failed.'));transaction.onabort=()=>reject(transaction.error||Error('Browser storage transaction was cancelled.'));});

export function openProjectDatabase(){
 return new Promise((resolve,reject)=>{const opening=indexedDB.open(DB_NAME,DB_VERSION);opening.onupgradeneeded=()=>{const db=opening.result;if(!db.objectStoreNames.contains('projects'))db.createObjectStore('projects',{keyPath:'id'});if(!db.objectStoreNames.contains('datasets'))db.createObjectStore('datasets',{keyPath:'projectId'});if(!db.objectStoreNames.contains('overlays'))db.createObjectStore('overlays',{keyPath:'projectId'});};opening.onsuccess=()=>resolve(opening.result);opening.onerror=()=>reject(opening.error||Error('Could not open saved project storage.'));});
}

export async function listProjectMetadata(db){const tx=db.transaction('projects','readonly'),done=complete(tx),result=await request(tx.objectStore('projects').getAll());await done;return result.sort((a,b)=>String(b.updatedAt).localeCompare(String(a.updatedAt)));}

export async function readProjectBundle(db,id){
 const tx=db.transaction(['projects','datasets','overlays'],'readonly'),done=complete(tx),projects=tx.objectStore('projects'),datasets=tx.objectStore('datasets'),overlays=tx.objectStore('overlays');
 const [meta,dataset,overlay]=await Promise.all([request(projects.get(id)),request(datasets.get(id)),request(overlays.get(id))]);await done;
 return meta&&dataset?{meta,data:dataset.data,changes:overlay?.changes||{}}:null;
}

export async function saveProjectBundle(db,{meta,data,changes}){const tx=db.transaction(['projects','datasets','overlays'],'readwrite'),done=complete(tx);tx.objectStore('projects').put(meta);tx.objectStore('datasets').put({projectId:meta.id,data});tx.objectStore('overlays').put({projectId:meta.id,changes});await done;}

export async function saveProjectState(db,meta,changes){const tx=db.transaction(['projects','overlays'],'readwrite'),done=complete(tx);tx.objectStore('projects').put(meta);tx.objectStore('overlays').put({projectId:meta.id,changes});await done;}

export async function removeSavedProject(db,id){const tx=db.transaction(['projects','datasets','overlays'],'readwrite'),done=complete(tx);for(const store of ['projects','datasets','overlays'])tx.objectStore(store).delete(id);await done;}

export function createProjectId(){return globalThis.crypto?.randomUUID?.()||`project-${Date.now()}-${Math.random().toString(16).slice(2)}`;}

export function emptyDataset(projectName=''){return {schemaVersion:2,projectName:String(projectName).trim(),nodeLabels:{},sourceDirectory:'Saved browser project',manual:{},nodes:[],files:[],records:[],issues:[]};}

export function validateProjectBackup(value){
 if(!value||value.kind!=='fire-alarm-report-manager-project'||value.schemaVersion!==1)throw Error('This is not a Notifier Report Manager project backup.');
 const data=value.data;if(!data||!Array.isArray(data.files)||!Array.isArray(data.records)||!Array.isArray(data.nodes)||!Array.isArray(data.issues))throw Error('The project backup is incomplete.');
 if(data.records.length>250000||data.files.length>5000)throw Error('The project backup is larger than the supported project limits.');
 return {name:String(value.name||data.projectName||'Imported project').trim().slice(0,100)||'Imported project',data,changes:value.changes||{},context:value.context||{}};
}
