const CORE_REPORTS = new Set(['detectors and modules', 'general zones', 'logic equations']);
const MAX_FILES = 100;
const MAX_TOTAL_BYTES = 100 * 1024 * 1024;
const MAX_PDF_PAGES = 500;

const clean = value => {
  if (typeof value === 'number' && Number.isFinite(value) && Number.isInteger(value)) return value;
  return typeof value === 'string' ? value.trim() : value;
};
const normalized = value => String(value ?? '').toUpperCase().replace(/[^A-Z0-9]+/g, '');
const component = value => normalized(value);
const integer = value => {
  if (typeof value === 'number' && Number.isInteger(value)) return value;
  const text = String(value ?? '').trim();
  return /^\d+$/.test(text) ? Number(text) : null;
};
const valuesFrom = (headers, row) => Object.fromEntries(
  headers.map((heading, index) => [String(heading ?? ''), clean(row[index] ?? '')]).filter(([heading]) => heading)
);
const pick = (values, aliases, fallback = '') => {
  const indexed = new Map(Object.entries(values).map(([key, value]) => [normalized(key), value]));
  for (const alias of aliases) {
    const value = indexed.get(normalized(alias));
    if (value !== undefined && value !== '') return value;
  }
  return fallback;
};

function metadataFromRows(rows) {
  const text = rows.flat().filter(Boolean).join(' ');
  const project = text.match(/Project\s*Details\s*:\s*\(\s*Name\s*:\s*(.*?)(?:,\s*Ver\s*:|\))/i);
  const address = text.match(/Node\s*Details\s*:\s*\([^)]*?Address\s*:\s*(\d+)/i);
  const label = text.match(/Node\s*Details\s*:\s*\([^)]*?Label\s*:\s*(.*?)(?:\)|,\s*(?:DBVer|TimeStamp|Type)\s*:)/i);
  return {
    projectName: project?.[1]?.trim() || '',
    node: address ? Number(address[1]) : null,
    nodeLabel: label?.[1]?.trim() || ''
  };
}

function reportFromName(name) {
  const match = String(name).match(/^(?:Node\s+(\d+)\s+)?(Detectors and Modules|General Zones|Logic Equations|ACS(?: Points| Point Report| Report)?|Annunciator(?: Control System)?(?: Points| Report)?)\.(?:xls|xlsx|xlsm|pdf)$/i);
  if (!match) return {node: null, report: null};
  let report = match[2].toLowerCase();
  if (report.startsWith('acs') || report.startsWith('annunciator')) report = 'acs points';
  return {node: match[1] ? Number(match[1]) : null, report};
}

function headerType(row) {
  const keys = new Set(row.filter(value => value !== '').map(normalized));
  const joined = normalized(row.join(' '));
  if (keys.has('ACSBOARD') || joined.includes('ACSBOARD')) return 'acs-board';
  if (keys.has('ACSPOINT') || joined.includes('ACSPOINT')) return 'acs-point';
  if ((keys.has('DEVICEADDR') || joined.includes('DEVICEADDR')) && (keys.has('LOOP') || joined.includes('LOOP'))) return 'device';
  if (keys.has('LOCALZONE') || joined.includes('LOCALZONE')) return 'general';
  if (keys.has('LOGICZONE') || joined.includes('LOGICZONE')) return 'logic';
  const hasPoint = [...keys].some(key => ['POINT', 'POINTNO', 'POINTNUMBER', 'POINTADDR', 'POINTADDRESS'].includes(key));
  const hasModule = [...keys].some(key => ['ACS', 'ACSADDRESS', 'ANNUNCIATOR', 'ANNUNCIATORADDRESS', 'MODULE', 'MODULEADDRESS', 'ANNUNCIATORMODULE'].includes(key));
  if (hasPoint && (hasModule || [...keys].some(key => key.includes('LEDMODE') || key.includes('SWITCHMODE')))) return 'acs';
  return null;
}

async function sha256(buffer) {
  const digest = await crypto.subtle.digest('SHA-256', buffer);
  return [...new Uint8Array(digest)].map(byte => byte.toString(16).padStart(2, '0')).join('');
}

function splitWideText(token) {
  const text = String(token.str || '');
  const pieces = text.split(/\s{2,}/).filter(Boolean);
  if (pieces.length < 2) return [{...token, str: text.trim()}];
  const total = Math.max(text.length, 1);
  let offset = 0;
  return pieces.map(piece => {
    const index = text.indexOf(piece, offset);
    offset = index + piece.length;
    return {
      ...token,
      str: piece.trim(),
      x: token.x + token.width * (index / total),
      width: token.width * (piece.length / total)
    };
  });
}

export function rowsFromPdfTextItems(items) {
  const tokens = items
    .filter(item => String(item.str || '').trim())
    .flatMap(item => splitWideText({
      str: String(item.str || ''),
      x: Number(item.transform?.[4] || 0),
      y: Number(item.transform?.[5] || 0),
      width: Math.max(Number(item.width || 0), 1)
    }));
  const lines = [];
  for (const token of tokens.sort((a, b) => b.y - a.y || a.x - b.x)) {
    let line = lines.find(candidate => Math.abs(candidate.y - token.y) <= 2.5);
    if (!line) {
      line = {y: token.y, tokens: []};
      lines.push(line);
    }
    line.tokens.push(token);
  }
  return lines.sort((a, b) => b.y - a.y).map(line => {
    const ordered = line.tokens.sort((a, b) => a.x - b.x);
    const widths = ordered.map(token => token.width / Math.max(token.str.length, 1)).filter(Number.isFinite).sort((a, b) => a - b);
    const characterWidth = widths[Math.floor(widths.length / 2)] || 4;
    const gapThreshold = Math.max(7, characterWidth * 1.8);
    const cells = [];
    for (const token of ordered) {
      const previous = cells.at(-1);
      const gap = previous ? token.x - previous.end : Infinity;
      if (!previous || gap > gapThreshold) cells.push({text: token.str.trim(), end: token.x + token.width});
      else {
        previous.text += `${previous.text && token.str ? ' ' : ''}${token.str.trim()}`;
        previous.end = Math.max(previous.end, token.x + token.width);
      }
    }
    return cells.map(cell => clean(cell.text));
  }).filter(row => row.some(Boolean));
}

async function readExcel(file, buffer) {
  if (!globalThis.XLSX) throw Error('The Excel reader did not load. Refresh the website and try again.');
  let workbook;
  try {
    workbook = globalThis.XLSX.read(buffer, {type: 'array', raw: true, cellDates: false, dense: true});
  } catch (error) {
    throw Error(`${file.name}: not a readable Excel workbook (${error.message})`);
  }
  return workbook.SheetNames.map(name => ({
    name,
    rows: globalThis.XLSX.utils.sheet_to_json(workbook.Sheets[name], {header: 1, raw: true, defval: '', blankrows: false})
  }));
}

async function readPdf(file, buffer, progress) {
  const pdfjs = await import('./vendor/pdf.min.mjs');
  pdfjs.GlobalWorkerOptions.workerSrc = new URL('./vendor/pdf.worker.min.mjs', import.meta.url).href;
  let loadingTask;
  let document;
  try {
    loadingTask = pdfjs.getDocument({data: new Uint8Array(buffer), isEvalSupported: false, useSystemFonts: true});
    document = await loadingTask.promise;
  } catch (error) {
    throw Error(`${file.name}: not a readable PDF (${error.message})`);
  }
  if (document.numPages > MAX_PDF_PAGES) throw Error(`${file.name}: PDFs are limited to ${MAX_PDF_PAGES} pages.`);
  const sheets = [];
  let textCharacters = 0;
  for (let pageNumber = 1; pageNumber <= document.numPages; pageNumber++) {
    progress(`Reading ${file.name} · page ${pageNumber} of ${document.numPages}`);
    const page = await document.getPage(pageNumber);
    const content = await page.getTextContent({disableNormalization: false});
    textCharacters += content.items.reduce((sum, item) => sum + String(item.str || '').trim().length, 0);
    sheets.push({name: `PDF page ${pageNumber}`, rows: rowsFromPdfTextItems(content.items)});
    page.cleanup();
  }
  await loadingTask.destroy();
  if (textCharacters < 80) throw Error(`${file.name}: no searchable report text was found. Use an exported/searchable PDF or Excel file; scanned PDFs need OCR first.`);
  return sheets;
}

function registerRecord(record, records, seen, issues, filename, rowNumber) {
  if (seen.has(record.id)) {
    seen.get(record.id).ambiguous = true;
    record.ambiguous = true;
    issues.push({message: 'Duplicate point identity', id: record.id, file: filename, row: rowNumber});
  }
  seen.set(record.id, record);
  records.push(record);
}

function processAcsBoardSheet({sheet, node, filename, fileInfo, records, seen, issues, discovered}) {
  const boardHeader = sheet.rows.findIndex(row => headerType(row.map(clean)) === 'acs-board');
  const pointHeader = sheet.rows.findIndex(row => headerType(row.map(clean)) === 'acs-point');
  if (boardHeader < 0 || pointHeader < 0) return false;
  discovered.add('acs');
  const boardHeaders = sheet.rows[boardHeader].map(clean);
  const pointHeaders = sheet.rows[pointHeader].map(clean);
  let currentBoard = null;
  for (let index = Math.max(boardHeader, pointHeader) + 1; index < sheet.rows.length; index++) {
    const raw = sheet.rows[index];
    const row = raw.map(clean);
    const boardAddress = integer(row[0]);
    if (boardAddress !== null) {
      const values = valuesFrom(boardHeaders, row);
      currentBoard = {
        address: boardAddress,
        type: pick(values, ['Board Type']),
        label: pick(values, ['Label']),
        pairingGroup: pick(values, ['Pairing Group']),
        troubleTimer: pick(values, ['Trouble Timer(Secs)', 'Trouble Timer'])
      };
      continue;
    }
    const pointNumber = integer(row[1]);
    if (!currentBoard || pointNumber === null) continue;
    const values = valuesFrom(pointHeaders, row);
    const acsSource = pick(values, ['Source']);
    const acsInput = pick(values, ['Input']);
    const localZone = pick(values, ['Local Zone']);
    const switchGroup = pick(values, ['Switch Group / Zone']);
    const mapped = [acsSource, localZone, switchGroup].filter(value => value !== '' && value !== null && String(value).toUpperCase() !== 'N/A').map(String);
    const address = `ACS${component(currentBoard.address)}P${component(pointNumber)}`;
    const source = {file: filename, sheet: sheet.name, row: index + 1, raw, headers: pointHeaders};
    const record = {
      node,
      source,
      settings: {...currentBoard, ...values},
      address,
      id: `N${node}${address}`,
      kind: 'acs',
      acsModuleAddress: currentBoard.address,
      pointNumber,
      label: '',
      boardLabel: currentBoard.label,
      boardType: currentBoard.type,
      pairingGroup: currentBoard.pairingGroup,
      troubleTimer: currentBoard.troubleTimer,
      mapped,
      acsFunction: pick(values, ['Function']),
      acsSource,
      acsInput,
      localZone,
      switchGroupZone: switchGroup,
      ledMode: '',
      switchMode: ''
    };
    registerRecord(record, records, seen, issues, filename, index + 1);
    fileInfo.records++;
  }
  return true;
}

function processSheet(context) {
  const {sheet, node, filename, fileInfo, records, seen, issues, discovered} = context;
  if (processAcsBoardSheet(context)) return;
  let headers = null;
  let section = null;
  for (let index = 0; index < sheet.rows.length; index++) {
    const raw = sheet.rows[index];
    const row = raw.map(clean);
    const possible = headerType(row);
    if (possible) {
      headers = row;
      section = possible;
      discovered.add(possible === 'acs-point' ? 'acs' : possible);
      continue;
    }
    if (!headers || !section || section === 'acs-board') continue;
    const values = valuesFrom(headers, row);
    const rowNode = integer(pick(values, ['Node', 'Node Address'], node)) ?? node;
    const source = {file: filename, sheet: sheet.name, row: index + 1, raw, headers};
    const record = {node: rowNode, source, settings: values};
    if (section === 'device') {
      const addressNumber = integer(pick(values, ['Device ADDR', 'Device Address']));
      const loop = integer(pick(values, ['LOOP', 'Loop Number']));
      if (addressNumber === null || loop === null) continue;
      const hasModuleType = Object.keys(values).some(key => normalized(key) === 'MODULETYPE');
      const category = hasModuleType ? 'M' : 'D';
      const moduleType = String(pick(values, ['Module Type']));
      const kind = moduleType.toLowerCase() === 'control' ? 'output' : category === 'D' || moduleType.toLowerCase() === 'monitor' ? 'input' : 'device';
      Object.assign(record, {
        address: `L${loop}${category}${addressNumber}`,
        kind,
        loop,
        category,
        number: addressNumber,
        label: pick(values, ['Custom Label', 'Description']),
        extendedLabel: pick(values, ['Extended Label', 'Location']),
        typeCode: pick(values, ['Type Code Label', 'Type Code']),
        flashScan: pick(values, ['FlashScan Type']),
        moduleType: moduleType || 'Detector',
        mappings: Array.from({length: 10}, (_, slot) => ({slot: slot + 1, raw: pick(values, [`CBE ${slot + 1}`, `CBE${slot + 1}`])}))
      });
    } else if (section === 'general') {
      const addressNumber = integer(pick(values, ['Local Zone']));
      if (addressNumber === null) continue;
      Object.assign(record, {address: `Z${addressNumber}`, kind: 'general', number: addressNumber, label: pick(values, ['Label', 'Description'])});
    } else if (section === 'logic') {
      const addressNumber = integer(pick(values, ['Logic Zone']));
      if (addressNumber === null || addressNumber < 1 || addressNumber > 1000) continue;
      Object.assign(record, {address: `ZL${addressNumber}`, kind: 'logic', number: addressNumber, label: pick(values, ['Comment', 'Description']), equation: String(pick(values, ['Logic Equation', 'Equation'])).trim()});
    } else {
      const module = clean(pick(values, ['Annunciator Module', 'Annunciator Address', 'ACS Address', 'Module Address', 'Annunciator', 'ACS', 'Module']));
      const point = clean(pick(values, ['Point Number', 'Point No', 'Point Address', 'Point Addr', 'Point', 'ACS Point']));
      if (module === '' || point === '') continue;
      const moduleKey = component(module);
      const pointKey = component(point);
      if (!moduleKey || !pointKey) continue;
      const mapped = [];
      for (const [heading, value] of Object.entries(values)) {
        const key = normalized(heading);
        if (value !== '' && (key.includes('MAPPED') || key.startsWith('CBE') || /^ZONE\d*$/.test(key))) mapped.push(...String(value).trim().split(/[,;\s]+/).filter(Boolean));
      }
      Object.assign(record, {
        address: `ACS${moduleKey}P${pointKey}`,
        kind: 'acs',
        acsModuleAddress: module,
        pointNumber: point,
        label: pick(values, ['Description', 'Custom Label', 'Point Label', 'Label']),
        mapped,
        ledMode: pick(values, ['LED Mode', 'LED1 Mode', 'LED']),
        switchMode: pick(values, ['Switch Mode', 'Key Mode', 'Button Mode', 'Switch'])
      });
    }
    record.id = `N${rowNode}${record.address}`;
    registerRecord(record, records, seen, issues, filename, index + 1);
    fileInfo.records++;
  }
}

function reportLabel(namedReport, discovered) {
  if (namedReport) return namedReport;
  const labels = [...discovered].map(section => ({device: 'detectors and modules', general: 'general zones', logic: 'logic equations', acs: 'acs points'}[section] || section));
  return labels.length === 1 ? labels[0] : labels.length > 1 ? 'combined reports' : 'detected from headers';
}

export async function importProjectFiles(inputFiles, progress = () => {}) {
  const filesToRead = [...inputFiles];
  if (!filesToRead.length) throw Error('Choose at least one Excel or PDF report.');
  if (filesToRead.length > MAX_FILES) throw Error(`Select no more than ${MAX_FILES} files at once.`);
  const totalBytes = filesToRead.reduce((sum, file) => sum + Number(file.size || 0), 0);
  if (totalBytes > MAX_TOTAL_BYTES) throw Error('Selected files must total less than 100 MB.');
  const names = filesToRead.map(file => String(file.name || '').toLowerCase());
  if (new Set(names).size !== names.length) throw Error('Duplicate report filenames were selected.');

  const records = [];
  const files = [];
  const issues = [];
  const seen = new Map();
  const projectNames = [];
  const labels = new Map();

  for (let fileIndex = 0; fileIndex < filesToRead.length; fileIndex++) {
    const file = filesToRead[fileIndex];
    const extension = String(file.name).split('.').pop().toLowerCase();
    if (!['xls', 'xlsx', 'xlsm', 'pdf'].includes(extension)) {
      issues.push({message: 'Unsupported file type', file: file.name});
      continue;
    }
    progress(`Opening ${file.name} · ${fileIndex + 1} of ${filesToRead.length}`);
    const buffer = await file.arrayBuffer();
    const sheets = extension === 'pdf' ? await readPdf(file, buffer, progress) : await readExcel(file, buffer);
    const metadataRows = sheets.flatMap(sheet => sheet.rows.slice(0, 12));
    const metadata = metadataFromRows(metadataRows);
    const named = reportFromName(file.name);
    const node = named.node || metadata.node;
    if (!node) {
      issues.push({message: 'Node address not found in filename or report metadata', file: file.name});
      continue;
    }
    if (metadata.projectName) projectNames.push(metadata.projectName);
    if (metadata.nodeLabel) {
      if (!labels.has(node)) labels.set(node, []);
      labels.get(node).push(metadata.nodeLabel);
    }
    const fileInfo = {
      file: file.name,
      sha256: await sha256(buffer),
      node,
      report: named.report || 'detected from headers',
      format: extension === 'pdf' ? 'PDF' : 'Excel',
      metadata: sheets.map(sheet => ({sheet: sheet.name, rows: sheet.rows.slice(0, 3)})),
      records: 0
    };
    const discovered = new Set();
    for (const sheet of sheets) processSheet({sheet, node, filename: file.name, fileInfo, records, seen, issues, discovered});
    fileInfo.report = reportLabel(named.report, discovered);
    if (!fileInfo.records) {
      issues.push({message: extension === 'pdf' ? 'No recognized report rows; confirm this is a searchable Notifier report PDF' : 'No recognized report rows', file: file.name});
      continue;
    }
    if (named.report === 'acs points' && !discovered.has('acs')) issues.push({message: 'ACS columns were not recognized', file: file.name});
    files.push(fileInfo);
  }

  if (!files.length) throw Error('No supported Notifier report rows were found. Select report Excel files or searchable report PDFs.');
  const nodes = [...new Set(records.map(record => record.node))].sort((a, b) => a - b);
  const available = new Map(nodes.map(node => [node, new Set()]));
  for (const record of records) {
    const report = ['input', 'output', 'device'].includes(record.kind) ? 'detectors and modules' : record.kind === 'general' ? 'general zones' : record.kind === 'logic' ? 'logic equations' : null;
    if (report) available.get(record.node)?.add(report);
  }
  for (const node of nodes) {
    const present = available.get(node);
    if (present?.size) for (const expected of CORE_REPORTS) if (!present.has(expected)) issues.push({message: 'Missing report', node, report: expected});
  }
  const mostCommon = values => [...new Set(values)].map(value => [value, values.filter(candidate => candidate === value).length]).sort((a, b) => b[1] - a[1])[0]?.[0] || '';
  const projectName = mostCommon(projectNames);
  const nodeLabels = Object.fromEntries([...labels].map(([node, values]) => [String(node), mostCommon(values)]));
  if (new Set(projectNames).size > 1) issues.push({message: 'Conflicting project names found', values: [...new Set(projectNames)].sort()});
  for (const [node, values] of labels) if (new Set(values).size > 1) issues.push({message: 'Conflicting node labels found', node, values: [...new Set(values)].sort()});

  progress('Building project maps…');
  return {
    schemaVersion: 2,
    projectName,
    nodeLabels,
    sourceDirectory: 'Browser import',
    manual: {title: 'NFS2-3030 Programming Manual', document: '52545:N4', date: '2016-11-16', pages: {mappings: 51, zones: '150–151', equations: '152–156', types: '158–163'}},
    nodes,
    files,
    records,
    issues
  };
}
