import {DEFAULT_ACCENT,datasetKey,normalizeChanges,validColor} from './decode.mjs';

export const CONTRIBUTOR_COLORS=['#b7f0d4','#ffb4a2','#b8d8ff','#d7b8ff','#ffd6a5','#a8e6ef','#f4b6d2','#d8ef9f'];
const own=(object,key)=>Object.prototype.hasOwnProperty.call(object||{},key);
const clone=value=>structuredClone(value);
const equal=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
const recordState=(changes,id)=>changes.deleted[id]?{kind:'deleted',value:true}:own(changes.entities,id)?{kind:'entity',value:changes.entities[id]}:null;
const summarize=value=>{if(value?.kind==='deleted')return 'Deleted';const item=value?.kind==='entity'?value.value:value;if(item&&typeof item==='object')return [item.label,item.equation].filter(Boolean).join(' · ')||'Updated point';return String(item??'');};

export function sameProjectBaseline(first,second){try{return datasetKey(first)===datasetKey(second);}catch{return false;}}
export function projectChangeCount(raw){const changes=normalizeChanges(raw);return (changes.projectName!==null?1:0)+Object.keys(changes.nodeLabels).length+Object.keys(changes.entities).length+Object.values(changes.deleted).filter(Boolean).length;}
function hslHex(h,s=70,l=84){s/=100;l/=100;const c=(1-Math.abs(2*l-1))*s,x=c*(1-Math.abs(h/60%2-1)),m=l-c/2,[r,g,b]=h<60?[c,x,0]:h<120?[x,c,0]:h<180?[0,c,x]:h<240?[0,x,c]:h<300?[x,0,c]:[c,0,x];return '#'+[r,g,b].map(value=>Math.round((value+m)*255).toString(16).padStart(2,'0')).join('');}
export function nextContributorColor(index=0,used=[]){const unavailable=new Set(used.map(value=>String(value).toLowerCase()));for(let offset=0;offset<CONTRIBUTOR_COLORS.length;offset++){const color=CONTRIBUTOR_COLORS[(index+offset)%CONTRIBUTOR_COLORS.length];if(!unavailable.has(color.toLowerCase()))return color;}for(let attempt=0;attempt<360;attempt++){const color=hslHex((index*137.508+attempt*47)%360);if(!unavailable.has(color.toLowerCase()))return color;}return DEFAULT_ACCENT;}

export function mergeChanges(rawCurrent,imports,policy='current'){
 if(!['current','incoming'].includes(policy))throw Error('Select a valid conflict rule.');
 const next=clone(normalizeChanges(rawCurrent)),result={applied:0,duplicates:0,conflicts:0,contributors:0};
 const ownerName=(type,address)=>{const owner=type==='project'?next.owners.projectName:type==='node'?next.owners.nodeLabels[address]:next.owners.deleted[address]||next.owners.entities[address];return next.contributors[owner]?.name||'This user';};
 const logConflict=(type,address,currentValue,incomingValue,contributor)=>{result.conflicts++;next.mergeLog.push({type,address,currentSummary:summarize(currentValue),incomingSummary:summarize(incomingValue),currentContributor:ownerName(type,address),incomingContributor:contributor.name,resolution:policy,color:contributor.color,importedAt:new Date().toISOString()});if(next.mergeLog.length>1000)next.mergeLog=next.mergeLog.slice(-1000);};
 const mergeScalar=(type,address,currentExists,currentValue,incomingValue,apply,contributor)=>{if(!currentExists){apply();result.applied++;return;}if(equal(currentValue,incomingValue)){result.duplicates++;return;}logConflict(type,address,currentValue,incomingValue,contributor);if(policy==='incoming'){apply();result.applied++;}};
 for(const source of imports){
  const incoming=normalizeChanges(source.changes),id=String(source.id||`contributor-${Date.now()}-${result.contributors}`),contributor={id,name:String(source.name||'Imported user').trim().slice(0,80)||'Imported user',email:String(source.email||'').trim().slice(0,254),color:validColor(source.color)?source.color:nextContributorColor(result.contributors,Object.values(next.contributors).map(x=>x.color)),importedAt:new Date().toISOString()};
  next.contributors[id]=contributor;result.contributors++;
  if(incoming.projectName!==null)mergeScalar('project','Project name',next.projectName!==null,next.projectName,incoming.projectName,()=>{next.projectName=incoming.projectName;next.owners.projectName=id;},contributor);
  for(const [node,label]of Object.entries(incoming.nodeLabels))mergeScalar('node',node,own(next.nodeLabels,node),next.nodeLabels[node],label,()=>{next.nodeLabels[node]=label;next.owners.nodeLabels[node]=id;},contributor);
  const recordIds=new Set([...Object.keys(incoming.entities),...Object.keys(incoming.deleted).filter(key=>incoming.deleted[key])]);
  for(const address of recordIds){const incomingState=recordState(incoming,address),currentState=recordState(next,address);mergeScalar('record',address,Boolean(currentState),currentState,incomingState,()=>{delete next.entities[address];delete next.deleted[address];delete next.owners.entities[address];delete next.owners.deleted[address];if(incomingState.kind==='deleted'){next.deleted[address]=true;next.owners.deleted[address]=id;}else{next.entities[address]=clone(incomingState.value);next.owners.entities[address]=id;}},contributor);}
 }
 return {changes:normalizeChanges(next),...result};
}

export function markLocalChanges(rawPrevious,rawNext,editor={}){
 const previous=normalizeChanges(rawPrevious),next=clone(normalizeChanges(rawNext));
 const id=String(editor.id||'local-editor'),name=String(editor.name||'Unassigned editor').trim().slice(0,80)||'Unassigned editor',color=validColor(editor.color)?editor.color:next.accent,at=new Date().toISOString();
 next.contributors[id]={id,name,email:'',color,importedAt:next.contributors[id]?.importedAt||at,updatedAt:at};
 const log=(type,address,action)=>next.auditLog.push({type,address,action,editorId:id,editorName:name,color,updatedAt:at});
 if(!equal(previous.projectName,next.projectName)){next.owners.projectName=id;log('Project','Project name','Updated');}
 for(const node of new Set([...Object.keys(previous.nodeLabels),...Object.keys(next.nodeLabels)]))if(!equal(previous.nodeLabels[node],next.nodeLabels[node])){next.owners.nodeLabels[node]=id;log('Node',`Node ${node}`,'Updated');}
 const ids=new Set([...Object.keys(previous.entities),...Object.keys(previous.deleted),...Object.keys(next.entities),...Object.keys(next.deleted)]);
 for(const address of ids)if(!equal(recordState(previous,address),recordState(next,address))){delete next.owners.entities[address];delete next.owners.deleted[address];if(next.deleted[address])next.owners.deleted[address]=id;else if(own(next.entities,address))next.owners.entities[address]=id;log('Record',address,next.deleted[address]?'Deleted':recordState(previous,address)?'Updated':'Added');}
 if(next.auditLog.length>2000)next.auditLog=next.auditLog.slice(-2000);
 return normalizeChanges(next);
}
