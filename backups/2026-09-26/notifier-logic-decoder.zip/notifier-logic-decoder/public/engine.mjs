export function reference(text, localNode) {
  const m=/^(?:N(\d+))?(?:(ZL|ZT|ZR|ZF|Z|T)(\d+)|L(\d+)(D|M)(\d+))$/.exec(String(text).trim().toUpperCase());
  if(!m)return null;
  const node=m[1]?+m[1]:+localNode,address=m[2]?m[2]+Number(m[3]):`L${+m[4]}${m[5]}${+m[6]}`;
  return {id:`N${node}${address}`,node,address,kind:m[2]?({Z:'general',ZL:'logic',ZT:'trouble',ZR:'releasing',ZF:'special',T:'system trouble'}[m[2]]):'device'};
}
export function parse(text,node){
  const s=String(text).replace(/\s+/g,'').toUpperCase();let p=0;
  function expr(){const start=p;while(p<s.length&&!'(),'.includes(s[p]))p++;const token=s.slice(start,p);if(!token)throw Error(`Expected argument at ${p+1}`);
    if(s[p]==='('){p++;const args=[];while(true){args.push(expr());if(s[p]===')'){p++;break;}if(s[p]!==',')throw Error(`Expected comma or closing parenthesis at ${p+1}`);p++;}return {type:'call',fn:token,args};}
    const r=reference(token,node);return r?{type:'ref',...r}:{type:'literal',value:token};}
  const ast=expr();if(p!==s.length)throw Error(`Unexpected text at ${p+1}`);if(ast.type!=='call')throw Error('Equation must begin with a function');return ast;
}
export function rangeArgs(a){
  if(a.args.length!==2||a.args.some(x=>x.type!=='ref'))throw Error('RANGE needs two addresses');
  const [x,y]=a.args.map(x=>/^(.*?)(\d+)$/.exec(x.id));
  if(x[1]!==y[1]||+y[2]<+x[2]||+y[2]-x[2]>=20)throw Error('RANGE must span 1–20 consecutive addresses of the same type and node');
  return Array.from({length:+y[2]-x[2]+1},(_,i)=>({type:'ref',...reference(x[1]+(+x[2]+i),0)}));
}
export function dependencies(a){if(a.type==='ref')return [a.id];if(a.type!=='call')return [];if(a.fn==='RANGE'){try{return rangeArgs(a).map(x=>x.id);}catch{}}return [...new Set(a.args.flatMap(dependencies))];}
export function functionsUsed(a){return a.type==='call'?[a.fn,...a.args.flatMap(functionsUsed)]:[];}
export function translate(a,lookup=()=>null){
  if(a.type==='ref'){const r=lookup(a.id);return `${a.id}${r?.label?` (${r.label}${r.extendedLabel?' / '+r.extendedLabel:''})`:''} is active${r?.missing?' [definition unavailable]':''}`;}
  if(a.type==='literal')return a.value;
  const xs=a.args.map(x=>translate(x,lookup));
  switch(a.fn){
    case 'OR':return `At least one of these conditions is true: ${xs.join('; ')}.`;
    case 'AND':return `All of these conditions are true: ${xs.join('; ')}.`;
    case 'NOT':return `This condition is false: (${xs.join('; ')}).`;
    case 'ONLY1':return `Exactly one of these conditions is true: ${xs.join('; ')}.`;
    case 'ANYX':return `At least ${xs[0]} of these conditions are true: ${xs.slice(1).join('; ')}.`;
    case 'RANGE':return `Addresses ${a.args[0]?.id||xs[0]} through ${a.args[1]?.id||xs[1]}, inclusive, are separate arguments of the enclosing function (OR: any; AND: all).`;
    case 'SDEL':case 'DEL':return `${a.fn==='SDEL'?'Latched delay':'Delay'}: when (${xs.slice(2).join('; ')}) becomes true, wait ${xs[0]}, then activate for duration ${xs[1]}. ${a.fn==='SDEL'?'Clearing the input does not cancel the delay or duration.':'Clearing the input cancels the sequence.'}${xs[1]?.includes('*')?' The report’s **:**:** token is not defined in the supplied manual; exact duration/reset behavior needs verification.':''} Timing and history are not simulated.`;
    case 'TIM':{const days={MO:'Monday',TU:'Tuesday',WE:'Wednesday',TH:'Thursday',FR:'Friday',SA:'Saturday',SU:'Sunday'},ds=xs.filter(x=>days[x]).map(x=>days[x]),ts=xs.filter(x=>/^\d\d:\d\d:\d\d$/.test(x));return `Scheduled activation${ds.length?' on '+ds.join(', '):''}${ts.length?' from '+ts[0]+' until '+(ts[1]||'23:59:59'):''}. Original schedule parameters: ${xs.join(', ')}. Calendar state is not simulated.`;}
    default:return `${a.fn}(${xs.join(', ')}): unsupported function; meaning and state require review.`;
  }
}
export function validateAst(ast){const errors=[];
  function walk(a,parent){if(a.type!=='call')return;
    if(a.fn==='NOT'&&a.args.length!==1)errors.push('NOT needs one argument');
    if(['DEL','SDEL'].includes(a.fn)&&a.args.length!==3)errors.push(`${a.fn} needs delay, duration and condition`);
    if(a.fn==='RANGE'){try{rangeArgs(a);}catch(e){errors.push(e.message);}if(!['OR','AND','ONLY1','ANYX'].includes(parent))errors.push('RANGE needs a governing Boolean function');}
    if(['OR','AND','NOT','ONLY1'].includes(a.fn)&&a.args.some(x=>x.type==='literal'))errors.push(`${a.fn} contains an unrecognized point argument`);
    if(a.fn==='ANYX'&&!/^[1-9]$/.test(a.args[0]?.value||''))errors.push('ANYX needs a threshold of 1–9');
    a.args.forEach(x=>walk(x,a.fn));
  }walk(ast);return errors;
}
const ordinaryOutputs=new Set(['RELAY','CONTROL','CONTROL NAC','STROBE CKT','SPEAKER','BELL CIRCUIT','HORN CIRCUIT','AUDIBLE CKT']);
const cbeInputs=new Set(['SMOKE (PHOTO)','HEAT (RATE OF RISE)','SUP L (DUCT P)','MONITOR','PULL STATION','TRACK SUPERV','LATCH SUPERV','NON FIRE']);
export function mappingMeaning(r,slot,ref){
  if(r.kind==='output')return {direction:'in',supported:ordinaryOutputs.has(r.typeCode?.toUpperCase())&&['general','logic'].includes(ref.kind)&&ref.address!=='Z0',note:'Zone → output CBE request. Physical behavior also depends on panel controls and settings (pp. 150, 162).'};
  if(r.category==='D'&&slot===9)return {direction:'in',supported:false,note:'Slot 9 controls the sounder/relay base, not detector alarm state (p. 51).'};
  if(r.category==='D'&&slot===10)return {direction:'out',supported:false,note:'Slot 10 is Action prealarm; prealarm is not simulated (p. 51).'};
  if(r.category==='D'&&[3,4,5].includes(slot)&&/CO|ACCL|IQUAD/i.test(r.typeCode+' '+r.flashScan))return {direction:'out',supported:false,note:'Element-specific mapping; photo/CO element state is not modeled (p. 51).'};
  const supported=cbeInputs.has(r.typeCode?.toUpperCase())&&ref.kind==='general'&&ref.address!=='Z0';
  return {direction:'out',supported,note:`${supported?'Input contributes to general zone':'Device/zone behavior not simulated'}${slot===1?'; slot 1 also supplies zone label and group-disable association':''} (pp. 51, 150, 158–161).`};
}
export function buildModel(data){
  const points=new Map(),edges=[],out=new Map(),incoming=new Map(),issues=[...data.issues];
  for(const r of data.records){if(points.has(r.id)){points.get(r.id).ambiguous=true;continue;}points.set(r.id,{...r});}
  const ensure=id=>{if(!points.has(id))points.set(id,{...reference(id,0),missing:true,label:'Definition unavailable'});};
  function edge(from,to,extra){ensure(from);ensure(to);const e={from,to,...extra};edges.push(e);if(!out.has(from))out.set(from,[]);out.get(from).push(e);if(!incoming.has(to))incoming.set(to,[]);incoming.get(to).push(e);}
  for(const r of [...points.values()]){
    if(r.equation){try{r.ast=parse(r.equation,r.node);r.errors=validateAst(r.ast);r.functions=functionsUsed(r.ast);if(r.errors.length)issues.push({id:r.id,message:r.errors.join('; ')});for(const id of dependencies(r.ast))edge(id,r.id,{type:'equation',supported:!r.errors.length,note:'Equation argument; polarity and conditions determine its effect.',source:r.source});}catch(e){r.errors=[e.message];issues.push({id:r.id,message:e.message});}}
    for(const m of r.mappings||[]){if(!m.raw)continue;const ref=reference(m.raw,r.node);if(!ref){r.mappingError=true;issues.push({id:r.id,message:`Unrecognized slot ${m.slot}: ${m.raw}`});continue;}const s=mappingMeaning(r,m.slot,ref);edge(s.direction==='in'?ref.id:r.id,s.direction==='in'?r.id:ref.id,{type:'mapping',slot:m.slot,...s,source:r.source});}
    if(r.kind==='acs'&&String(r.acsFunction).trim().toUpperCase()==='MONITOR')for(const raw of r.mapped||[]){const ref=reference(raw,r.node);if(!ref){r.mappingError=true;issues.push({id:r.id,message:`Unrecognized ACS monitor source: ${raw}`});continue;}edge(ref.id,r.id,{type:'acs-monitor',supported:true,note:'ACS Monitor point annunciates the mapped source and is listed as an output.',source:r.source});}
  }
  const cycles=findCycles(points,out);for(const group of cycles)for(const id of group)points.get(id).cycle=group;
  return {data,points,edges,out,incoming,issues,cycles,missing:[...points.values()].filter(r=>r.missing)};
}
function findCycles(points,out){
  const visited=new Set(),order=[],reverse=new Map();for(const [a,es]of out)for(const e of es){if(!reverse.has(e.to))reverse.set(e.to,[]);reverse.get(e.to).push(a);}
  for(const start of points.keys()){if(visited.has(start))continue;const stack=[[start,false]];while(stack.length){const [id,done]=stack.pop();if(done){order.push(id);continue;}if(visited.has(id))continue;visited.add(id);stack.push([id,true]);for(const e of out.get(id)||[])if(!visited.has(e.to))stack.push([e.to,false]);}}
  visited.clear();const groups=[];for(const start of order.reverse()){if(visited.has(start))continue;const group=[],stack=[start];visited.add(start);while(stack.length){const id=stack.pop();group.push(id);for(const prev of reverse.get(id)||[])if(!visited.has(prev)){visited.add(prev);stack.push(prev);}}if(group.length>1||(out.get(start)||[]).some(e=>e.to===start))groups.push(group);}return groups;
}
export const triOr=xs=>xs.includes(true)?true:xs.includes(null)?null:false;
export const triAnd=xs=>xs.includes(false)?false:xs.includes(null)?null:true;
export function evaluateAst(ast,get){
  if(ast.type==='ref')return get(ast.id);if(ast.type!=='call')return null;
  let args=[];for(const a of ast.args){if(a.type==='call'&&a.fn==='RANGE'){try{args.push(...rangeArgs(a));}catch{return null;}}else args.push(a);}
  if(['SDEL','DEL','TIM'].includes(ast.fn))return null;
  const xs=args.map(a=>evaluateAst(a,get));
  switch(ast.fn){case 'OR':return triOr(xs);case 'AND':return triAnd(xs);case 'NOT':return xs.length===1&&xs[0]!==null?!xs[0]:null;case 'ONLY1':{const t=xs.filter(x=>x===true).length;return t>1?false:xs.includes(null)?null:t===1;}case 'ANYX':{const k=Number(args[0]?.value),v=xs.slice(1),t=v.filter(x=>x===true).length,u=v.filter(x=>x===null).length;return !Number.isInteger(k)||k<1||k>9?null:t>=k?true:t+u<k?false:null;}default:return null;}
}
export function simulate(model,overrides={},assumeNormal=false){
  const results=new Map();
  function solve(id,visiting=new Set()){
    if(results.has(id))return results.get(id);const r=model.points.get(id);let value=null,reason='State is unavailable.';
    if(!r||r.missing)reason='Source report or point definition is missing.';
    else if(r.ambiguous)reason='Duplicate source identity; state is ambiguous.';
    else if(r.cycle||visiting.has(id))reason='Cyclic dependency: panel evaluation order/history is not simulated.';
    else if(r.errors?.length)reason=r.errors.join('; ');
    else if(r.kind==='input'){value=Object.hasOwn(overrides,id)?overrides[id]:assumeNormal?false:null;reason=Object.hasOwn(overrides,id)?'Explicit hypothetical input state.':assumeNormal?'Assumed inactive by the normal-input option.':'Input state has not been set.';}
    else if(r.kind==='logic'&&r.ast){visiting.add(id);value=evaluateAst(r.ast,dep=>solve(dep,visiting).value);visiting.delete(id);reason=r.functions.some(f=>['TIM','SDEL','DEL'].includes(f))?'Timing/calendar/history is not simulated.':value===true?'Equation condition is satisfied under the scenario.':value===false?'Equation condition is not satisfied under the scenario.':'A necessary condition is unknown or unsupported.';}
    else if(r.kind==='general'||r.kind==='output'){
      const es=model.incoming.get(id)||[];
      if(r.address==='Z0')reason='General alarm aggregation/type exclusions require panel event state; not simulated.';
      else if(r.kind==='output'&&!ordinaryOutputs.has(r.typeCode?.toUpperCase()))reason='Specialized output type is not simulated.';
      else if(!es.length)reason='No incoming CBE definitions imported; inactive cannot be inferred.';
      else{visiting.add(id);value=triOr([...es.map(e=>e.supported?solve(e.from,visiting).value:null),...(r.mappingError?[null]:[])]);visiting.delete(id);reason=value===true?'At least one supported mapped dependency is active.':value===false?'All imported mapped dependencies are inactive under the scenario.':'Mapped dependencies include unknown or unsupported state.';}
    }else reason='Special, trouble, releasing or device-specific state is not simulated.';
    const result={value,reason};results.set(id,result);return result;
  }for(const id of model.points.keys())solve(id);return results;
}
export function reachable(model,start,direction='forward'){
  const found=new Map([[start,0]]),queue=[start],adj=direction==='backward'?model.incoming:model.out;for(let i=0;i<queue.length;i++)for(const e of adj.get(queue[i])||[]){const next=direction==='backward'?e.from:e.to;if(!found.has(next)){found.set(next,found.get(queue[i])+1);queue.push(next);}}return found;
}
export function shortestPath(model,start,target,direction='forward'){
  const prev=new Map([[start,null]]),queue=[start],adj=direction==='backward'?model.incoming:model.out;for(let i=0;i<queue.length;i++){const id=queue[i];if(id===target){const path=[];let v=id;while(v!==null){path.push(v);v=prev.get(v);}return path.reverse();}for(const e of adj.get(id)||[]){const next=direction==='backward'?e.from:e.to;if(!prev.has(next)){prev.set(next,id);queue.push(next);}}}return [];
}
