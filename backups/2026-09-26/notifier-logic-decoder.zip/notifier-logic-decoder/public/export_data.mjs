import {translate,dependencies} from './engine.mjs';
import {pointLabel,recordStatus,normalizeChanges,changeRows,csv,contributorForChange,changeHighlight} from './decode.mjs';

export const SCOPE_LABELS={devices:'Detectors & Modules',zones:'General Zones',logic:'Logic Equations',acs:'ACS Points'};
const source=r=>r?.source?`${r.source.file} · ${r.source.sheet} · row ${r.source.row}`:'';
const mappings=r=>(r.mappings||[]).map(m=>m.raw).filter(Boolean).join(', ');
const nodeLabel=(model,r)=>model.data.nodeLabels?.[String(r.node)]||'';
function directOutputs(model,id){return [...new Set((model.out.get(id)||[]).filter(e=>{const target=model.points.get(e.to);return target?.kind==='output'||target?.kind==='acs'&&String(target.acsFunction).trim().toUpperCase()==='MONITOR';}).map(e=>e.to))];}
function directInputs(r){return r?.ast?dependencies(r.ast):[];}
export function rowsForScope(scope,model,rawChanges){
 const changes=normalizeChanges(rawChanges),all=[...model.points.values()].filter(r=>!r.missing||r.changeType),wanted={devices:new Set(['input','output','device']),zones:new Set(['general']),logic:new Set(['logic']),acs:new Set(['acs'])}[scope]||new Set();
 return all.filter(r=>wanted.has(r.kind)).sort((a,b)=>a.node-b.node||a.id.localeCompare(b.id,undefined,{numeric:true})).map(r=>{
  const state=recordStatus(r,changes),person=contributorForChange(changes,r.id),modified=['edited','added','deleted'].includes(state),common={Node:r.node,'Node label':nodeLabel(model,r),Address:r.id,Description:r.label||'','Extended label':r.extendedLabel||'',Status:state,Contributor:person?.name||(modified?'This user':''),Source:source(r),__highlight:modified?changeHighlight(changes,r.id):''};
  if(scope==='devices')return {...common,Category:r.category==='D'?'Detector':r.kind==='output'?'Control module':'Module','Module type':r.moduleType||'', 'Type code':r.typeCode||'','FlashScan type':r.flashScan||'',Mappings:mappings(r)};
  if(scope==='zones')return {...common,'Zone number':r.number??'',MappedInputs:(model.incoming.get(r.id)||[]).map(e=>e.from).join(', '),'Dependent equations/outputs':(model.out.get(r.id)||[]).map(e=>e.to).join(', ')};
  if(scope==='logic')return {...common,Equation:r.equation||'',Diagnostic:r.ast?translate(r.ast,id=>model.points.get(id)):'Undefined equation',Inputs:directInputs(r).join(', '),Outputs:directOutputs(model,r.id).join(', ')};
  return {...common,'ACS module':r.acsModuleAddress??'','Board label':r.boardLabel||'','Board type':r.boardType||'','Point number':r.pointNumber??'','Mapped zones/points':(r.mapped||[]).join(', '),Function:r.acsFunction||'',Input:r.acsInput||'','Local zone':r.localZone||'','Switch group / zone':r.switchGroupZone||'','LED mode':r.ledMode||'','Switch mode':r.switchMode||''};
 });
}
export function workbookPayload(model,data,rawChanges,scopes,accent){
 const changes=normalizeChanges(rawChanges),sheets=[];
 for(const scope of scopes){const rawRows=rowsForScope(scope,model,changes);if(!rawRows.length)continue;const highlights=rawRows.map(row=>row.__highlight||''),rows=rawRows.map(({__highlight,...row})=>row);sheets.push({name:SCOPE_LABELS[scope],title:SCOPE_LABELS[scope],rows,highlights});}
 const deltas=changeRows(data,changes);if(deltas.length){const highlights=deltas.map(row=>row.__highlight||changes.accent),rows=deltas.map(({__highlight,...row})=>row);sheets.push({name:'Change Log',title:'Change Log',rows,highlights});}
 return {projectName:model.data.projectName||'Untitled fire alarm project',generatedAt:new Date().toISOString(),accent,summary:`${data.files.length} imported reports. Original source files unchanged.`,sheets};
}
export function combinedCsv(model,data,changes,scopes){const rows=[];for(const scope of scopes)for(const {__highlight,...row} of rowsForScope(scope,model,changes))rows.push({Dataset:SCOPE_LABELS[scope],...row});return csv(rows);}
