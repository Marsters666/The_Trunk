const CACHE = 'notifier-report-manager-web-v12';
const CORE = [
  '/app',
  '/style.css',
  '/dark-highlights.css',
  '/app.mjs',
  '/file-autosave.mjs',
  '/engine.mjs',
  '/decode.mjs',
  '/export_data.mjs',
  '/export_files.mjs',
  '/projects.mjs',
  '/merge.mjs',
  '/importer.mjs',
  '/web-ui.js',
  '/vendor/xlsx.full.min.js',
  '/vendor/pdf.min.mjs',
  '/vendor/pdf.worker.min.mjs',
  '/shared-project.json',
  '/rising-sun-logo.png',
  '/app.ico',
  '/manifest.webmanifest'
];

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(CORE)));
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(key => key !== CACHE).map(key => caches.delete(key))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  if (event.request.method !== 'GET' || url.origin !== location.origin || url.pathname.startsWith('/api/')) return;
  if (event.request.mode === 'navigate') {
    event.respondWith(fetch(event.request).catch(() => caches.match('/app')));
    return;
  }
  event.respondWith(
    caches.match(event.request).then(cached => cached || fetch(event.request).then(response => {
      if (response.ok) caches.open(CACHE).then(cache => cache.put(event.request, response.clone()));
      return response;
    }))
  );
});
