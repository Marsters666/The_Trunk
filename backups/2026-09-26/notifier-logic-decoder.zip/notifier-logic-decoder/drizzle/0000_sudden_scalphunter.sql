CREATE TABLE `shared_projects` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`updated_at` text NOT NULL,
	`last_updated_by` text DEFAULT 'Unassigned editor' NOT NULL,
	`reports` integer DEFAULT 0 NOT NULL,
	`records` integer DEFAULT 0 NOT NULL,
	`revision` integer DEFAULT 1 NOT NULL,
	`object_key` text NOT NULL,
	`size_bytes` integer DEFAULT 0 NOT NULL,
	`created_at` text NOT NULL
);
