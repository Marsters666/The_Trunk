import { env } from "cloudflare:workers";

const jsonHeaders = { "Cache-Control": "no-store" };
const validId = (value: string) => /^[a-zA-Z0-9-]{1,100}$/.test(value);

async function projectRow(id: string) {
  if (!env.DB) throw new Error("Shared project database is unavailable.");
  return env.DB.prepare(`
    SELECT id, name, updated_at AS updatedAt, last_updated_by AS lastUpdatedBy,
           reports, records, revision, object_key AS objectKey,
           size_bytes AS sizeBytes, created_at AS createdAt
    FROM shared_projects WHERE id = ?
  `).bind(id).first<Record<string, unknown>>();
}

function serverError(error: unknown) {
  console.error("shared project storage error", error);
  return Response.json({ error: "Website project storage is temporarily unavailable." }, { status: 500, headers: jsonHeaders });
}

export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await context.params;
    if (!validId(id)) return Response.json({ error: "Invalid project id." }, { status: 400 });
    if (!env.BUCKET) throw new Error("Shared project file storage is unavailable.");
    const meta = await projectRow(id);
    if (!meta) return Response.json({ error: "Project not found." }, { status: 404 });
    const object = await env.BUCKET.get(String(meta.objectKey));
    if (!object) return Response.json({ error: "Project file is unavailable." }, { status: 503 });
    return new Response(object.body, { headers: { ...jsonHeaders, "Content-Type": "application/json; charset=utf-8", ETag: `"${meta.revision}"`, "X-Project-Revision": String(meta.revision) } });
  } catch (error) {
    return serverError(error);
  }
}

export async function PUT(request: Request, context: { params: Promise<{ id: string }> }) {
  let orphanKey = "";
  try {
    const { id } = await context.params;
    if (!validId(id)) return Response.json({ error: "Invalid project id." }, { status: 400 });
    if (!env.DB || !env.BUCKET) throw new Error("Shared project storage is unavailable.");
    const bytes = await request.arrayBuffer();
    if (!bytes.byteLength || bytes.byteLength > 50 * 1024 * 1024) return Response.json({ error: "Project must be between 1 byte and 50 MB." }, { status: 413 });
    let bundle: { meta?: Record<string, unknown>; data?: { files?: unknown[]; records?: unknown[] }; changes?: unknown };
    try { bundle = JSON.parse(new TextDecoder().decode(bytes)); }
    catch { return Response.json({ error: "Project data is not valid JSON." }, { status: 400 }); }
    if (!bundle?.meta || !bundle?.data || !Array.isArray(bundle.data.files) || !Array.isArray(bundle.data.records) || !bundle.changes) return Response.json({ error: "Project data is incomplete." }, { status: 400 });
    if (bundle.data.files.length > 5000 || bundle.data.records.length > 250000) return Response.json({ error: "Project exceeds supported limits." }, { status: 413 });
    const name = String(bundle.meta.name || "Untitled project").trim().slice(0, 100) || "Untitled project";
    const updatedAt = new Date().toISOString();
    const editor = bundle.meta.editor as Record<string, unknown> | undefined;
    const lastUpdatedBy = String(bundle.meta.lastUpdatedBy || editor?.name || "Unassigned editor").trim().slice(0, 80) || "Unassigned editor";
    const current = await projectRow(id);
    const expectedRaw = request.headers.get("If-Match")?.replaceAll('"', "");
    const expected = expectedRaw ? Number(expectedRaw) : null;
    if (current && (!Number.isInteger(expected) || expected !== Number(current.revision))) return Response.json({ error: "This website project has newer changes. Reopen it before saving again.", code: "revision_conflict", currentRevision: current.revision }, { status: 409, headers: jsonHeaders });
    const nextRevision = current ? Number(current.revision) + 1 : 1;
    orphanKey = `projects/${id}/${nextRevision}.json`;
    await env.BUCKET.put(orphanKey, bytes, { httpMetadata: { contentType: "application/json" } });
    if (current) {
      const result = await env.DB.prepare(`
        UPDATE shared_projects
        SET name = ?, updated_at = ?, last_updated_by = ?, reports = ?, records = ?, revision = ?, object_key = ?, size_bytes = ?
        WHERE id = ? AND revision = ?
      `).bind(name, updatedAt, lastUpdatedBy, bundle.data.files.length, bundle.data.records.length, nextRevision, orphanKey, bytes.byteLength, id, expected).run();
      if (!result.meta.changes) {
        await env.BUCKET.delete(orphanKey);
        return Response.json({ error: "This website project changed while you were saving. Reopen it and try again.", code: "revision_conflict" }, { status: 409, headers: jsonHeaders });
      }
    } else {
      try {
        await env.DB.prepare(`
          INSERT INTO shared_projects (id, name, updated_at, last_updated_by, reports, records, revision, object_key, size_bytes, created_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).bind(id, name, updatedAt, lastUpdatedBy, bundle.data.files.length, bundle.data.records.length, nextRevision, orphanKey, bytes.byteLength, String(bundle.meta.createdAt || updatedAt)).run();
      } catch (error) {
        await env.BUCKET.delete(orphanKey);
        const race = await projectRow(id);
        if (race) return Response.json({ error: "This project was created by another user. Reopen it before saving.", code: "revision_conflict", currentRevision: race.revision }, { status: 409, headers: jsonHeaders });
        throw error;
      }
    }
    const meta = { id, name, updatedAt, lastUpdatedBy, reports: bundle.data.files.length, records: bundle.data.records.length, revision: nextRevision, sizeBytes: bytes.byteLength, createdAt: current?.createdAt || bundle.meta.createdAt || updatedAt };
    return Response.json({ project: meta }, { status: current ? 200 : 201, headers: { ...jsonHeaders, ETag: `"${nextRevision}"` } });
  } catch (error) {
    if (orphanKey && env.BUCKET) await env.BUCKET.delete(orphanKey).catch(() => {});
    return serverError(error);
  }
}
