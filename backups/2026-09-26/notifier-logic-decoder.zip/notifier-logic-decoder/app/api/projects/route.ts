import { env } from "cloudflare:workers";

const jsonHeaders = { "Cache-Control": "no-store" };

export async function GET() {
  try {
    if (!env.DB) throw new Error("Shared project database is unavailable.");
    const result = await env.DB.prepare(`
      SELECT id, name, updated_at AS updatedAt, last_updated_by AS lastUpdatedBy,
             reports, records, revision, size_bytes AS sizeBytes, created_at AS createdAt
      FROM shared_projects
      ORDER BY updated_at DESC, name COLLATE NOCASE ASC
      LIMIT 500
    `).all();
    return Response.json({ projects: result.results ?? [] }, { headers: jsonHeaders });
  } catch (error) {
    console.error("shared projects list error", error);
    return Response.json({ error: "Website projects are temporarily unavailable." }, { status: 500, headers: jsonHeaders });
  }
}
