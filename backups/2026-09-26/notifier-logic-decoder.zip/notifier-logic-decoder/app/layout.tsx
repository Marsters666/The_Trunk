import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Notifier Report Manager",
  description: "Review, edit, save, export, and share Notifier fire alarm report projects.",
  icons: {
    icon: "/app.ico",
    shortcut: "/app.ico",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
