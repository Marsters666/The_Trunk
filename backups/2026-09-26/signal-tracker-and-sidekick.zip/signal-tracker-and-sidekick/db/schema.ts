import { sql } from "drizzle-orm";
import { index, integer, sqliteTable, text, uniqueIndex } from "drizzle-orm/sqlite-core";

export const monitorSessions = sqliteTable(
  "monitor_sessions",
  {
    id: integer("id").primaryKey({ autoIncrement: true }),
    code: text("code").notNull(),
    name: text("name").notNull(),
    panelFamily: text("panel_family").notNull(),
    publisherTokenHash: text("publisher_token_hash").notNull(),
    isLive: integer("is_live", { mode: "boolean" }).notNull().default(true),
    createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
    updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  },
  (table) => [uniqueIndex("idx_monitor_sessions_code").on(table.code)],
);

export const serialEvents = sqliteTable(
  "serial_events",
  {
    id: integer("id").primaryKey({ autoIncrement: true }),
    sessionCode: text("session_code")
      .notNull()
      .references(() => monitorSessions.code, { onDelete: "cascade" }),
    batchId: text("batch_id"),
    category: text("category").notNull(),
    message: text("message").notNull(),
    source: text("source").notNull().default("serial"),
    occurredAt: text("occurred_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  },
  (table) => [
    index("idx_serial_events_session_id").on(table.sessionCode, table.id),
    index("idx_serial_events_session_batch").on(table.sessionCode, table.batchId),
    index("idx_serial_events_session_category").on(
      table.sessionCode,
      table.category,
    ),
  ],
);

export const activeSignals = sqliteTable(
  "active_signals",
  {
    id: integer("id").primaryKey({ autoIncrement: true }),
    sessionCode: text("session_code")
      .notNull()
      .references(() => monitorSessions.code, { onDelete: "cascade" }),
    pointKey: text("point_key").notNull(),
    category: text("category").notNull(),
    message: text("message").notNull(),
    firstSeenAt: text("first_seen_at").notNull().default(sql`CURRENT_TIMESTAMP`),
    updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  },
  (table) => [
    uniqueIndex("idx_active_signals_session_point").on(table.sessionCode, table.pointKey),
    index("idx_active_signals_session_category").on(table.sessionCode, table.category),
  ],
);

export const deliveryHealth = sqliteTable("delivery_health", {
  captureStatus: text("capture_status").notNull().default('{}'),
  sessionCode: text("session_code").primaryKey().references(() => monitorSessions.code, { onDelete: "cascade" }),
  probe: text("probe").notNull(),
  publisherAt: integer("publisher_at").notNull(),
});
export const deliveryReceipts = sqliteTable("delivery_receipts", {
  id: text("id").primaryKey(),
  sessionCode: text("session_code").notNull().references(() => monitorSessions.code, { onDelete: "cascade" }),
  probe: text("probe").notNull(),
  receivedAt: integer("received_at").notNull(),
  eventId: integer("event_id").notNull(),
});

export const panelProfiles = sqliteTable("panel_profiles", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  baudRate: text("baud_rate").notNull(),
  dataBits: text("data_bits").notNull(),
  parity: text("parity").notNull(),
  stopBits: text("stop_bits").notNull(),
  flowMode: text("flow_mode").notNull(),
  revision: integer("revision").notNull().default(1),
  verified: integer("verified", {mode:"boolean"}).notNull().default(false),
  updatedAt: text("updated_at").notNull(),
});

export const e3ControlHosts = sqliteTable('e3_control_hosts', {
  sessionCode: text('session_code').primaryKey().references(() => monitorSessions.code, { onDelete: 'cascade' }),
  epoch: text('epoch').notNull(),
  keyHash: text('key_hash').notNull(),
  expiresAt: integer('expires_at').notNull(),
  resetFormat: text('reset_format').notNull(),
});
export const e3Commands = sqliteTable('e3_commands', {
  id: text('id').primaryKey(),
  sessionCode: text('session_code').notNull().references(() => monitorSessions.code, { onDelete: 'cascade' }),
  epoch: text('epoch').notNull(),
  action: text('action').notNull(),
  resetFormat: text('reset_format').notNull(),
  status: text('status').notNull(),
  createdAt: integer('created_at').notNull(),
  expiresAt: integer('expires_at').notNull(),
  result: text('result').notNull().default(''),
}, t => [index('idx_e3_commands_session_status').on(t.sessionCode, t.status)]);

export const accessAttempts = sqliteTable('access_attempts', {
  key: text('key').primaryKey(),
  count: integer('count').notNull(),
  expiresAt: integer('expires_at').notNull(),
});

export const captureBatches = sqliteTable('capture_batches', {
 id: text('id').primaryKey(),
 sessionCode: text('session_code').notNull().references(()=>monitorSessions.code,{onDelete:'cascade'}),
 digest: text('digest').notNull(),
});
