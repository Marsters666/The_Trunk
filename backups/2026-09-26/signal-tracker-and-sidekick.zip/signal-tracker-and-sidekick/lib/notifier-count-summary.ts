import type { EventCategory } from './panelstream';
/** Only a complete label:number printer row is a count snapshot, never an event. */
export function notifierCountSummary(message:string): Partial<Record<EventCategory,number>> | null {
 const text=message.trim().replace(/^[*=\s]+|[*=\s]+$/g,'');
 const field=/((?:FIRE\s+)?ALARMS?|PRE\s*ALARM|TROUBLES?|SUPERVISORY|SECURITY|OTHER)\s*[:=]\s*(\d{1,5})\b/gi;
 const matches=Array.from(text.matchAll(field));
 if(!matches.length || text.replace(field,'').trim())return null;
 const counts:Partial<Record<EventCategory,number>>={};
 for(const match of matches) {
  const name=match[1].toUpperCase();
  const category:EventCategory|null=/^(?:FIRE|ALARM)/.test(name)?'alarm':/^TROUBLE/.test(name)?'trouble':name==='SUPERVISORY'?'supervisory':name==='OTHER'?'other':null;
  if(category)counts[category]=Number(match[2]);
 }
 return counts;
}
