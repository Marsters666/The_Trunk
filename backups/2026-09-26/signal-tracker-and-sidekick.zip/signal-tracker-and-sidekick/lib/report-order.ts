import type { SerialEvent } from './panelstream';
import { eventDate } from './event-time';
export type ReportOrder = 'time' | 'device';
export function reportDeviceAddress(message: string) {
  const match = /(?:^|[^A-Z0-9])(?:N(\d{1,3})\s*)?L(\d{1,2})\s*([DM])(\d{1,3})(?![A-Z0-9])/i.exec(message);
  return match ? {kind:match[3].toUpperCase(),node:match[1]===undefined?-1:Number(match[1]),loop:Number(match[2]),address:Number(match[4])} : null;
}
export function orderReportEvents(events: SerialEvent[], order: ReportOrder = 'time') {
  const chronological = (a:SerialEvent,b:SerialEvent) => {
    const difference=eventDate(a.occurredAt).getTime()-eventDate(b.occurredAt).getTime();
    return (Number.isFinite(difference)?difference:0) || a.id-b.id;
  };
  return [...events].sort((a,b)=>{
    if(order==='device') {
      const left=reportDeviceAddress(a.message),right=reportDeviceAddress(b.message);
      const rank=(device:ReturnType<typeof reportDeviceAddress>)=>device?(device.kind==='D'?0:1):2;
      const kind=rank(left)-rank(right); if(kind)return kind;
      if(left && right) { const address=left.node-right.node || left.loop-right.loop || left.address-right.address; if(address)return address; }
    }
    return chronological(a,b);
  });
}
