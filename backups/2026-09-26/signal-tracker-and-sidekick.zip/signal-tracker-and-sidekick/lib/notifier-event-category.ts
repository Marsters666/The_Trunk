import { notifierCountSummary } from './notifier-count-summary';
import { classifySerialMessage, type EventCategory } from './panelstream';
import { isNotifierDetail, isNotifierActiveEvent } from './notifier-format';
export function notifierEventCategory(message:string,previous=''):EventCategory {
  if(notifierCountSummary(message))return 'other';
  if(isNotifierActiveEvent(message) || (isNotifierDetail(message) && isNotifierActiveEvent(previous)))return "other";
  const header=(isNotifierDetail(message)?previous:message).trim().replace(/^(?:ACK|ACKED|ACKNOWLEDGED|CLR|CLEARED|RESTORED)\s+/i,'');
  if(/^TROUBLE\b/i.test(header))return 'trouble';
  if(/^(?:TRACK SUPERV|SUPERVISORY|SUPERV|SUPV)\b/i.test(header))return 'supervisory';
  if(/^(?:FIRE ALARM|ALARM)\b/i.test(header))return 'alarm';
  if(/^DISABLED\b/i.test(header))return 'other';
  return classifySerialMessage(message);
}
