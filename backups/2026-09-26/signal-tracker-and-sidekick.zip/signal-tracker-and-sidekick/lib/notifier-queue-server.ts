import { and, asc, eq, gt } from 'drizzle-orm';
import { getDb } from '../db';
import { serialEvents } from '../db/schema';
import { NotifierQueue } from './notifier-queue';

// Disposable acceleration only. Stored serial history remains authoritative;
// a new worker rebuilds it, repairing queues created by the old line parser.
const cache=new Map<string,{cursor:number;queue:NotifierQueue}>();
export async function notifierCounts(db:ReturnType<typeof getDb>,code:string,panelFamily:string) {
  const previous=cache.get(code);
  let cursor=previous?.cursor || 0;
  const queue=previous?.queue.clone() || new NotifierQueue(panelFamily === "notifier-n16");
  while(true) {
    const rows=await db.select({id:serialEvents.id,message:serialEvents.message,source:serialEvents.source})
      .from(serialEvents).where(and(eq(serialEvents.sessionCode,code),gt(serialEvents.id,cursor)))
      .orderBy(asc(serialEvents.id)).limit(1000);
    for(const row of rows){queue.push(row);cursor=row.id;}
    if(rows.length<1000)break;
  }
  if(cursor>=(cache.get(code)?.cursor || 0))cache.set(code,{cursor,queue});
  if(cache.size>100)cache.delete(cache.keys().next().value!);
  return queue.counts();
}

export async function notifierCountSources(db:ReturnType<typeof getDb>,code:string,panelFamily:string) {
 await notifierCounts(db,code,panelFamily);
 return [...(cache.get(code)?.queue.summaryCategories ?? [])];
}
