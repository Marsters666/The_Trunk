// Preserve the recording laptop's wall clock and offset for every new event.
export function laptopTimestamp(date=new Date()){
 const pad=(n:number)=>String(n).padStart(2,'0');
 const offset=-date.getTimezoneOffset();
 return `${date.getFullYear()}-${pad(date.getMonth()+1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}.${String(date.getMilliseconds()).padStart(3,'0')}${offset>=0?'+':'-'}${pad(Math.floor(Math.abs(offset)/60))}:${pad(Math.abs(offset)%60)}`;
}
export function eventDate(value:string){return new Date(/^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d$/.test(value)?value.replace(' ','T')+'Z':value);}
export function eventClock(value:string){
 if(/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d+)?[+-]\d\d:\d\d$/.test(value))return `${value.slice(5,7)}/${value.slice(8,10)}/${value.slice(0,4)} ${value.slice(11,19)}`;
 const date=eventDate(value);return Number.isNaN(date.getTime())?'Unknown time':date.toLocaleString(undefined,{year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false});
}
export function validCapturedTime(value:unknown){return typeof value==='string' && /^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}[+-]\d\d:\d\d$/.test(value)&&Number.isFinite(Date.parse(value));}
