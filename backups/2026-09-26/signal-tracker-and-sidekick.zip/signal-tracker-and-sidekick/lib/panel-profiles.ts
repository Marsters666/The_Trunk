export type PanelProfile = {
 id: string; name: string; baudRate: string; dataBits: '7' | '8'; parity: 'none' | 'even' | 'odd'; stopBits: '1' | '2'; flowMode: 'none'; revision: number; verified: boolean; updatedAt: string;
};
export function validProfile(p: Partial<PanelProfile>) {
 return typeof p.name === 'string' && p.name.trim().length > 0 && p.name.trim().length <= 100 && typeof p.baudRate === 'string' && /^\d+$/.test(p.baudRate) && Number(p.baudRate) >= 50 && Number(p.baudRate) <= 4000000 && ['7','8'].includes(p.dataBits ?? '') && ['none','even','odd'].includes(p.parity ?? '') && ['1','2'].includes(p.stopBits ?? '') && ['none'].includes(p.flowMode ?? '');
}
