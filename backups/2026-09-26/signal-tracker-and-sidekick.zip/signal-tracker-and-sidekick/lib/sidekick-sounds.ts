export const ALERT_CATEGORIES = ['alarm', 'supervisory', 'trouble', 'other'] as const;
export type AlertCategory = typeof ALERT_CATEGORIES[number];
export type AlertSoundKey = AlertCategory | `${AlertCategory}-restoral`;
export const ALERT_SOUND_KEYS: AlertSoundKey[] = ALERT_CATEGORIES.flatMap(category=>[category, `${category}-restoral` as AlertSoundKey]);
export function eventSoundKey(event:{category:AlertCategory;message:string}):AlertSoundKey {
 const restored=/\b(?:CLR|CLEAR(?:ED)?|RESTOR(?:E|ED|AL)|RETURN(?:ED)?\s+TO\s+NORMAL|ENABL(?:E|ED)|UNBYPASS(?:ED)?|DEISOLAT(?:E|ED))\b/i.test(event.message) || /^\s*(?:SYSTEM\s+)?NORMAL\b/i.test(event.message);
 return restored?`${event.category}-restoral`:event.category;
}
type Note = { frequency: number; start: number; duration: number; endFrequency?: number };
export const SIDEKICK_SOUNDS = [
  { id: 'two-tone', name: 'Two-tone', wave: 'square', notes: [{frequency:880,start:0,duration:0.18},{frequency:660,start:0.22,duration:0.22}] },
  { id: 'triple-pulse', name: 'Triple pulse', wave: 'sine', notes: [0,0.22,0.44].map(start=>({frequency:1000,start,duration:0.12})) },
  { id: 'rising-chime', name: 'Rising chime', wave: 'sine', notes: [523,659,784].map((frequency,i)=>({frequency,start:i*0.2,duration:0.3})) },
  { id: 'low-knock', name: 'Low knock', wave: 'triangle', notes: [0,0.3].map(start=>({frequency:240,start,duration:0.2,endFrequency:140})) },
  { id: 'warble', name: 'Warble', wave: 'triangle', notes: [0,0.18,0.36,0.54].map((start,i)=>({frequency:i%2?620:1100,start,duration:0.15})) },
  { id: 'upward-sweep', name: 'Upward sweep', wave: 'sine', notes: [{frequency:350,start:0,duration:0.65,endFrequency:1400}] },
  { id:'eagle', name:"Birdy", wave:'sine', notes:[{frequency:2600,start:0,duration:0.45,endFrequency:1300},...Array.from({length:6},(_,i)=>({frequency:2200-i*90,start:0.5+i*0.08,duration:0.06,endFrequency:1700-i*70}))] },
  { id:'cricket', name:'Cricket', wave:'sine', notes:[0,0.35,0.7].flatMap(start=>Array.from({length:5},(_,i)=>({frequency:4300,start:start+i*0.032,duration:0.018,endFrequency:3900}))) },
] satisfies {id:string;name:string;wave:OscillatorType;notes:Note[]}[];
export type SoundId = typeof SIDEKICK_SOUNDS[number]['id'] | 'none';
export type AlertSounds = Record<AlertSoundKey, SoundId>;
export const DEFAULT_ALERT_SOUNDS: AlertSounds = {alarm:'two-tone',supervisory:'rising-chime',trouble:'triple-pulse',other:'low-knock','alarm-restoral':'rising-chime','supervisory-restoral':'rising-chime','trouble-restoral':'rising-chime','other-restoral':'rising-chime'};
export function readAlertSounds(value: unknown): AlertSounds {
  const result = {...DEFAULT_ALERT_SOUNDS};
  if(value && typeof value === 'object') for(const category of ALERT_SOUND_KEYS) {
    const saved = (value as Record<string,unknown>)[category];
    const id = ["car-horn", "frog", "cat", "train"].includes(String(saved)) ? "none" : saved;
    if(id === "none" || SIDEKICK_SOUNDS.some(sound=>sound.id===id)) result[category]=id as SoundId;
  }
  return result;
}
// Preview and live playback share the same loudness-normalized recordings.
export const ALERT_AUDIO_REVISION = '20260926-balanced';
const decodedSounds = new WeakMap<AudioContext, Map<string, AudioBuffer>>();
export async function loadAlertSound(context:AudioContext,id:SoundId):Promise<AudioBuffer> {
 let cache=decodedSounds.get(context);
 if(!cache){cache=new Map();decodedSounds.set(context,cache);}
 const existing=cache.get(id);if(existing)return existing;
 const response=await fetch(`/sounds/${id}.wav?v=${ALERT_AUDIO_REVISION}`,{signal:AbortSignal.timeout(10000)});
 if(!response.ok)throw new Error('Unable to load alert sound');
 const buffer=await context.decodeAudioData(await response.arrayBuffer());
 cache.set(id,buffer);return buffer;
}
export function scheduleAlertSound(context:AudioContext,id:SoundId,buffer?:AudioBuffer) {
 if(id==='none')return ()=>{};
 if(!buffer)throw new Error('Alert sound has not loaded');
 const source=context.createBufferSource();source.buffer=buffer;
 source.connect(context.destination);source.onended=()=>source.disconnect();source.start();
 return ()=>{try{source.stop();}catch{/* Already stopped. */}};
}
