export const FEEDBACK_EMAIL='mike.marsters@gmail.com';
export const SAMPLE_SUBJECT='Signal Tracker / SideKick — Comments and Suggestions test';
export const SAMPLE_MESSAGE='This is a sample Comments and Suggestions message for Rising Sun Projects.\n\nThe feedback destination is mike.marsters@gmail.com. Please confirm that this test message arrived.\n\nThis is a delivery test only; no panel signals or session credentials are included.';
export function feedbackLink(subject:string,body:string){return `mailto:${FEEDBACK_EMAIL}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;}
