export type ReportSheet = {name:string;rows:string[][]};
export function reportFileKind(name:string):'pdf'|'excel'|null {
  return /\.pdf$/i.test(name)?'pdf':/\.xlsx?$/i.test(name)?'excel':null;
}
export async function readReportSheets(bytes:ArrayBuffer):Promise<ReportSheet[]> {
  const XLSX=await import('xlsx');
  const workbook=XLSX.read(bytes,{type:'array',cellHTML:false,cellFormula:false});
  let cells=0;
  const sheets=workbook.SheetNames.map(name=>{
    const sheet=workbook.Sheets[name];
    const range=XLSX.utils.decode_range(sheet['!ref']||'A1');
    cells+=(range.e.r-range.s.r+1)*(range.e.c-range.s.c+1);
    if(cells>250000)throw new Error('This workbook is too large for browser printing. Open it in Excel to print; you can still share the original file here.');
    const rows=XLSX.utils.sheet_to_json<string[]>(sheet,{header:1,raw:false,defval:'',blankrows:false}).map(row=>row.map(value=>String(value??'')));
    return {name,rows};
  });
  if(!sheets.length)throw new Error('The workbook has no worksheets to print.');
  return sheets;
}
