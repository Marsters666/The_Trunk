type ReusablePort = { readable: ReadableStream<Uint8Array> | null; close(): Promise<void> };
/** Retain the OS handle between reports. No session callback or reader is retained. */
export class SerialReuse<T extends ReusablePort> {
  private held: {port:T;settings:string} | null = null;
  retain(port:T, settings:string) { this.held = {port,settings}; }
  async take(selected:T, settings:string):Promise<boolean> {
    if (!this.held) return false;
    if (this.held.port !== selected || this.held.settings !== settings || !selected.readable) {
      await this.release();
      return false;
    }
    // Flush software/hardware receive buffers; inactive-session bytes must not enter the next report.
    await selected.readable.cancel();
    this.held = null;
    return true;
  }
  async release() {
    if (!this.held) return;
    await this.held.port.close();
    this.held = null;
  }
}
