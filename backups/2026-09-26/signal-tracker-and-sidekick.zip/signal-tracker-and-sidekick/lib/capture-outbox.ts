// Device-local safety buffer; acknowledged copies remain authoritative on the server.
export type CapturedEvent = {message:string;category:string;source:'serial'|'manual';occurredAt:string};
export type CaptureBatch = {id?:number;batchId:string;code:string;events:CapturedEvent[]};
let database:Promise<IDBDatabase>|undefined;
function open() {
 return database ??= new Promise<IDBDatabase>((resolve,reject)=>{
  const request=indexedDB.open('signal-tracker-capture',1);
  request.onupgradeneeded=()=>{const store=request.result.createObjectStore('outbox',{keyPath:'id',autoIncrement:true});store.createIndex('session','code');};
  request.onsuccess=()=>resolve(request.result);request.onerror=()=>{database=undefined;reject(request.error);};
 });
}
async function transaction<T>(mode:IDBTransactionMode,run:(store:IDBObjectStore)=>IDBRequest<T>):Promise<T> {
 const db=await open();return new Promise((resolve,reject)=>{
  const tx=db.transaction('outbox',mode),request=run(tx.objectStore('outbox'));
  tx.oncomplete=()=>resolve(request.result);tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error ?? new Error('Local capture could not be saved'));
 });
}
export async function saveCapture(code:string,events:CapturedEvent[]) {
 // Commit the entire read before returning to the serial reader.
 const db=await open();await new Promise<void>((resolve,reject)=>{
  const tx=db.transaction('outbox','readwrite'),store=tx.objectStore('outbox');
  for(let i=0;i<events.length;i+=100)store.add({batchId:crypto.randomUUID(),code,events:events.slice(i,i+100)});
  tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error);
 });
}
export const pendingCapture=(code:string)=>transaction<CaptureBatch[]>('readonly',store=>store.index('session').getAll(code));
export const removeCapture=(id:number)=>transaction('readwrite',store=>store.delete(id));
