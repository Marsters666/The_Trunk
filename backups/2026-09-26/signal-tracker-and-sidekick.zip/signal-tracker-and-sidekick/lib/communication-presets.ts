export type CommPreset = {
  value: string;
  label: string;
  baud: number[];
  bits: 7 | 8;
  parity: "even" | "none";
  stops: 1;
  flow: "none";
  notes: string[];
};

const notifier = (
  model: string,
  baud: number[],
  bits: 7 | 8,
  parity: "even" | "none",
  flow: "none",
  notes: string[] = [],
): CommPreset => ({
  value: `notifier-${model.toLowerCase()}`,
  label: `Notifier ${model}`,
  baud,
  bits,
  parity,
  stops: 1,
  flow,
  notes,
});

const gamewellE3 = (value: string, label: string): CommPreset => ({
  value,
  label,
  baud: [9600, 115200, 19200, 4800, 2400, 1200],
  bits: 8,
  parity: "none",
  stops: 1,
  flow: "none",
  notes: [
    "E3 RS-232 starts at 9600 baud when SW2-5 is off; SW2-5 on forces 115200 baud. CAMWorks can define another supported baud.",
    "Use 8 data bits, no parity, 1 stop bit and no software handshake for the plain-text terminal connection.",
  ],
});

export const COMM_PRESETS: CommPreset[] = [
  gamewellE3("ili-mb-e3", "Gamewell-FCI ILI-MB-E3"),
  gamewellE3("ili95-mb-e3", "Gamewell-FCI ILI95-MB-E3"),
  gamewellE3("ili-s-e3", "Gamewell-FCI ILI-S-E3"),
  gamewellE3("gamewell-e3", "Gamewell-FCI E3 Series"),
  notifier("N16", [9600, 4800, 2400], 8, "none", "none", [
  ]),
  notifier("NFW-100", [9600, 4800, 2400], 7, "even", "none", [
    "Supplied FireWarden reference: 7 data bits, even parity, 1 stop bit; select the panel's configured baud.",
    "The reference does not specify a software handshake protocol.",
  ]),
  notifier("NFW2-100", [9600, 4800, 2400], 7, "even", "none", [
    "Supplied FireWarden reference: 7 data bits, even parity, 1 stop bit; select the panel's configured baud.",
    "The reference does not specify a software handshake protocol.",
  ]),
  notifier("NFS-320", [9600, 4800, 2400], 7, "even", "none", [
    "Supplied PRN-series reference: 7 data bits, even parity, 1 stop bit.",
  ]),
  notifier("NFS2-640", [9600, 4800, 2400], 7, "even", "none", [
    "Supplied PRN-series reference: 7 data bits, even parity, 1 stop bit.",
  ]),
  notifier("NFS2-3030", [9600, 4800, 2400], 8, "none", "none", [
  ]),
  notifier("NCA-2", [9600, 4800, 2400], 8, "none", "none", [
  ]),
  notifier("AFP-100", [2400], 7, "even", "none", [
    "Supplied AFP-100 printer reference: 2400 baud, 7 data bits, even parity and 1 stop bit.",
  ]),
  notifier("AFP-200", [2400], 7, "even", "none", [
    "Supplied AFP-200 PRN-4 reference: 2400 baud, 7 data bits, even parity, 1 stop bit.",
  ]),
  notifier("AFP-400", [2400], 7, "even", "none", [
    "The supplied AFP-400 reference establishes the CPU-400 terminal mapping. Use the documented 2400 baud, 7E1 printer profile and verify the installed revision.",
  ]),
  { value: "firelite-es-200x", label: "Fire-Lite ES-200X", baud: [2400, 4800, 9600], bits: 7, parity: "even", stops: 1, flow: "none", notes: ["PDF: BUFFER = LARGE. Choose the baud rate configured at the panel; flow control is not specified."] },
  ...["AFP-1010", "AM-2020", "UZC-256"].map((model) => notifier(model, [2400], 7, "even", "none")),
  notifier("NFS-640", [9600], 7, "even", "none"),
  notifier("NFS-3030", [9600], 8, "even", "none"),
  notifier("NCA", [9600], 8, "even", "none"),
  notifier("DVC", [9600], 8, "even", "none"),
  notifier("XPIQ", [57600], 7, "even", "none", ["The PDF requires gateway shutdown before communicating with XPIQ. Arrange the documented service procedure before connection."]),
  { value: "monaco-m2", label: "Monaco M2", baud: [9600], bits: 8, parity: "even", stops: 1, flow: "none", notes: [] },
  { value: "spectronics-mxv", label: "Spectronics MXV", baud: [9600], bits: 8, parity: "even", stops: 1, flow: "none", notes: ["PDF: shut down the gateway before communication; use port S2 with MXT output enabled. Verify the installed revision and service procedure."] },
];

export const FONT_CHOICES = [
  { value: "mono", label: "System monospace", family: "ui-monospace, SFMono-Regular, Consolas, \"Liberation Mono\", monospace" },
  { value: "consolas", label: "Consolas", family: "Consolas, \"Liberation Mono\", monospace" },
  { value: "courier", label: "Courier New", family: "\"Courier New\", Courier, monospace" },
  { value: "arial", label: "Arial", family: "Arial, Helvetica, sans-serif" },
  { value: "verdana", label: "Verdana", family: "Verdana, Geneva, sans-serif" },
];

export function inspectSerialBytes(bytes: Uint8Array) {
  let printable = 0, bad = 0, controls = 0;
  for (const byte of bytes) {
    if ((byte >= 32 && byte <= 126) || [9, 10, 13].includes(byte)) printable++;
    else if ([2, 3, 5, 6, 12, 17, 19].includes(byte)) controls++;
    else bad++;
  }
  return { printable, bad, controls };
}
