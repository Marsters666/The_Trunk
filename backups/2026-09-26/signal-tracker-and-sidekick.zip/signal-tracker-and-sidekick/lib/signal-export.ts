import { orderReportEvents, type ReportOrder } from "./report-order";
import {eventDate,eventClock} from './event-time';
import type { EventCategory, SerialEvent } from "@/lib/panelstream";
import { CATEGORY_LABELS } from "@/lib/panelstream";

export type ExportFilter = "all" | EventCategory;
export type ExportFormat = "xlsx" | "pdf";

type ExportOptions = {
  events: SerialEvent[];
  reportName?: string;
  order?: ReportOrder;
  categories?: EventCategory[];
  from?: string;
  to?: string;
  filter: ExportFilter;
  format: ExportFormat;
  sessionCode: string;
  sessionName: string;
  panelLabel: string;
};

function safeName(value: string) {
  return value
    .trim()
    .replace(/[^a-z0-9]+/gi, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60) || "signal-log";
}

export function selectReportEvents(options: ExportOptions) {
  const from=options.from?new Date(options.from).getTime():-Infinity;
  const to=options.to?new Date(options.to).getTime()+59999:Infinity;
  return orderReportEvents(options.events.filter(event=>{
    const time=eventDate(event.occurredAt).getTime();
    return (options.categories?options.categories.includes(event.category):options.filter==='all'||event.category===options.filter) && time>=from && time<=to;
  }), options.order);
}
function selectionLabel(options:ExportOptions){return (options.categories?options.categories.map(c=>CATEGORY_LABELS[c]).join(', '):exportLabel(options.filter)) + ` | ${options.from||'Beginning'} to ${options.to||'Latest'} (local time) | Order: ${options.order === "device" ? "Device" : "Time"}`;}


function exportLabel(filter: ExportFilter) {
  return filter === "all" ? "All signals" : `${CATEGORY_LABELS[filter]} only`;
}

function fileStem(options: ExportOptions) {
  if(options.reportName) return safeName(options.reportName);
  const filter = options.filter === "all" ? "all-signals" : options.filter;
  return `${safeName(options.sessionName)}-${filter}-${new Date().toISOString().slice(0, 10)}`;
}

async function makeWorkbook(options: ExportOptions) {
  const XLSX = await import("xlsx");
  const rows = selectReportEvents(options).map((event) => ({
    "Date / time": eventClock(event.occurredAt),
    "Signal type": CATEGORY_LABELS[event.category],
    Message: event.message,
    Source: event.source === "manual" ? "Manual / test" : "RS-232",
    "Session code": options.sessionCode,
    "Job / panel": options.sessionName,
    Panel: options.panelLabel,
  }));
  const worksheet = XLSX.utils.json_to_sheet(rows, {
    header: ["Date / time", "Signal type", "Message", "Source", "Session code", "Job / panel", "Panel"],
  });
  worksheet["!cols"] = [{ wch: 24 }, { wch: 21 }, { wch: 76 }, { wch: 16 }, { wch: 15 }, { wch: 30 }, { wch: 28 }];
  worksheet["!autofilter"] = rows.length ? { ref: `A1:G${rows.length + 1}` } : undefined;
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "Signals");
  const summary = XLSX.utils.aoa_to_sheet([
    ["Signal Tracker export", options.reportName || options.sessionName],
    ["Job / panel", options.sessionName],
    ["Panel", options.panelLabel],
    ["Session code", options.sessionCode],
    ["Selection", selectionLabel(options)],
    ["Exported", new Date().toLocaleString()],
    ["Rows", rows.length],
  ]);
  summary["!cols"] = [{ wch: 20 }, { wch: 54 }];
  XLSX.utils.book_append_sheet(workbook, summary, "Export details");
  const bytes = XLSX.write(workbook, { bookType: "xlsx", type: "array" });
  return new File([bytes], `${fileStem(options)}.xlsx`, {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });
}

function rgb(hex: string): [number, number, number] {
  const normalized = hex.replace("#", "");
  const value = Number.parseInt(normalized, 16);
  return [(value >> 16) & 255, (value >> 8) & 255, value & 255];
}

async function makePdf(options: ExportOptions) {
  const { jsPDF } = await import("jspdf");
  const doc = new jsPDF({ orientation: "landscape", unit: "pt", format: "letter" });
  const rows = selectReportEvents(options);
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 38;
  const messageWidth = pageWidth - margin * 2 - 210;
  const categoryColors: Record<EventCategory, string> = {
    alarm: "#ef4444",
    supervisory: "#3b82f6",
    trouble: "#eab308",
    other: "#f97316",
  };

  const drawHeader = (continued = false) => {
    doc.setFillColor(9, 13, 16);
    doc.rect(0, 0, pageWidth, 66, "F");
    doc.setTextColor(255, 255, 255);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(17);
    const title=`Signal Tracker - ${options.reportName || options.sessionName}${continued ? " (continued)" : ""}`;
    doc.setFontSize(Math.min(17,17*(pageWidth-2*margin)/Math.max(1,doc.getTextWidth(title))));
    doc.text(title, margin, 27);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8.5);
    doc.setTextColor(185, 197, 205);
    doc.text(doc.splitTextToSize(`${options.panelLabel} | Session ${options.sessionCode} | ${rows.length} signals | ${selectionLabel(options)}`,pageWidth-margin*2), margin, 45);
    doc.setTextColor(70, 78, 84);
    doc.text("TIME", margin + 12, 84);
    doc.text("TYPE", margin + 112, 84);
    doc.text("MESSAGE", margin + 210, 84);
    doc.setDrawColor(200, 207, 212);
    doc.line(margin, 91, pageWidth - margin, 91);
  };

  drawHeader();
  let y = 110;
  for (const event of rows) {
    const timestamp = eventClock(event.occurredAt);
    const lines = doc.splitTextToSize(event.message, messageWidth) as string[];
    const rowHeight = Math.max(25, lines.length * 11 + 10);
    if (y + rowHeight > pageHeight - 38) {
      doc.addPage();
      drawHeader(true);
      y = 110;
    }
    const [red, green, blue] = rgb(categoryColors[event.category]);
    doc.setFillColor(red, green, blue);
    doc.rect(margin, y - 11, 4, rowHeight - 3, "F");
    doc.setFont("courier", "normal");
    doc.setFontSize(8.2);
    doc.setTextColor(75, 84, 90);
    doc.text(timestamp, margin + 12, y);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(red, green, blue);
    doc.text(CATEGORY_LABELS[event.category].toUpperCase(), margin + 112, y);
    doc.setFont("courier", "normal");
    doc.setTextColor(22, 27, 30);
    doc.text(lines, margin + 210, y);
    y += rowHeight;
  }

  if (!rows.length) {
    doc.setFont("helvetica", "normal");
    doc.setTextColor(92, 102, 109);
    doc.text("No saved signals match this selection.", margin, 122);
  }

  const pages = doc.getNumberOfPages();
  for (let page = 1; page <= pages; page += 1) {
    doc.setPage(page);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    doc.setTextColor(115, 124, 130);
    doc.text(`Exported ${new Date().toLocaleString()}  •  Page ${page} of ${pages}`, pageWidth - margin, pageHeight - 18, { align: "right" });
  }
  return new File([doc.output("arraybuffer")], `${fileStem(options)}.pdf`, { type: "application/pdf" });
}

export async function createSignalExport(options: ExportOptions) {
  return options.format === "xlsx" ? makeWorkbook(options) : makePdf(options);
}

export function downloadFile(file: File) {
  const url = URL.createObjectURL(file);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = file.name;
  anchor.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export function countExportRows(events: SerialEvent[], filter: ExportFilter) {
  return (filter === "all" ? events : events.filter(event=>event.category===filter)).length;
}
