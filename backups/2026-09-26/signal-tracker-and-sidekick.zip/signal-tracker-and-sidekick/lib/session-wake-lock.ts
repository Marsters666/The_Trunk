export type AwakeStatus = 'requesting' | 'active' | 'paused' | 'unavailable';
type Lock = { released:boolean; release:()=>Promise<void>; addEventListener:(type:'release', listener:()=>void)=>void };
export function createSessionWakeLock({request,visible,onStatus}:{request?:()=>Promise<Lock>;visible:()=>boolean;onStatus:(status:AwakeStatus)=>void}) {
 let stopped=false, pending=false, lock:Lock|null=null;
 async function acquire() {
  if(stopped || pending) return;
  if(!request) {onStatus('unavailable');return;}
  if(!visible()) {onStatus('paused');return;}
  if(lock && !lock.released) {onStatus('active');return;}
  pending=true;onStatus('requesting');
  try {
   const next=await request();
   if(stopped || !visible()) {await next.release();if(!stopped)onStatus('paused');return;}
   lock=next;
   next.addEventListener('release',()=>{if(lock===next){lock=null;if(!stopped)onStatus('paused');}});
   if(next.released) {lock=null;onStatus('paused');} else onStatus('active');
  } catch {if(!stopped)onStatus(visible()?'unavailable':'paused');}
  finally {pending=false;}
 }
 function stop() {stopped=true;const held=lock;lock=null;if(held)void held.release().catch(()=>undefined);}
 return {acquire,stop};
}
