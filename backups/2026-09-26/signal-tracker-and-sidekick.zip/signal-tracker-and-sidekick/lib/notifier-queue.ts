import { notifierCountSummary } from './notifier-count-summary';
import { classifySerialMessage, deriveQueueMutation, type EventCategory } from './panelstream';

type RecordLine = { message:string; source:string };
import { isNotifierDetail, isNotifierActiveEvent, isSpecialZone, isN16GeneralZone } from "./notifier-format";
export class NotifierQueue {
  constructor(private readonly n16Mode = false) {}
  active = new Map<string,EventCategory>();
  summaryCategories = new Set<string>();
  pending: string | null = null;
  pendingAcknowledged = false;
  private unobserved = {alarm:0,supervisory:0,trouble:0,other:0};
  private clearedUnknown = new Set<string>();
  private flushPending() {
    if(this.pending && !this.pendingAcknowledged)this.apply(this.pending);
    this.pending=null;this.pendingAcknowledged=false;
  }
  clone() { const copy=new NotifierQueue(this.n16Mode);copy.summaryCategories=new Set(this.summaryCategories);copy.active=new Map(this.active);copy.pending=this.pending;copy.pendingAcknowledged=this.pendingAcknowledged;copy.unobserved={...this.unobserved};copy.clearedUnknown=new Set(this.clearedUnknown);return copy; }
  private apply(message:string, address?:string, acknowledged=false) {
    if(isSpecialZone(message) || (address && isSpecialZone(address)) || (this.n16Mode && isN16GeneralZone(message)))return;
    // Classify the transition header, never the device-type label on line two.
    const header=message.trim().replace(/^(?:CLEARED|RESTORED)\s+/i,'');
    const category:EventCategory=/^TROUBLE\b/i.test(header)?'trouble':/^(?:TRACK SUPERV|SUPERVISORY|SUPERV|SUPV)\b/i.test(header)?'supervisory':/^(?:FIRE ALARM|ALARM)\b/i.test(header)?'alarm':classifySerialMessage(message);
    const mutation=deriveQueueMutation(address ? `${message} ${address}` : message,category);
    if(!mutation)return;
    if(mutation.action==='reset-alarms') { this.unobserved.alarm=0; for(const [key,value] of this.active)if(value==='alarm')this.active.delete(key);return; }
    const key=`${category}:${address || mutation.pointKey}`;
    if(mutation.action==='clear') {
      if(!this.active.delete(key) && !this.clearedUnknown.has(key) && this.unobserved[category]>0)this.unobserved[category]--;
      this.clearedUnknown.add(key);
    } else {
      // An acknowledgement identifies an already-present condition from the snapshot.
      if(acknowledged && !this.active.has(key) && this.unobserved[category]>0)this.unobserved[category]--;
      this.active.set(key,category);this.clearedUnknown.delete(key);
    }
  }
  push(line:RecordLine) {
    if(line.source!=='serial')return;
    const message=line.message.trim().replace(/^CLR\s+/i,"CLEARED ");
    const summary=notifierCountSummary(message);
    if(summary) {
      this.flushPending();
      for(const [name,count] of Object.entries(summary)) {
        const category=name as EventCategory;
        this.summaryCategories.add(category);
        let known=[...this.active.values()].filter(value=>value===category).length;
        // A smaller authoritative total invalidates our incomplete identity list.
        if(known>count) { for(const [key,value] of this.active)if(value===category)this.active.delete(key); known=0; }
        this.unobserved[category]=count-known;
        for(const key of this.clearedUnknown)if(key.startsWith(category+':'))this.clearedUnknown.delete(key);
      }
      return;
    }
    if(/^[*=\s-]*EVENT\s+COUNTS?\b/i.test(message)){this.flushPending();return;}
    if (this.n16Mode && isNotifierActiveEvent(message)) {
      this.flushPending();
      this.pending=null;
      return; // Preserve the raw event in history, but never change queue state.
    }
    // A typed trouble acknowledgement proves that condition is present,
    // even when capture started after its original activation. Wait for the
    // detail line so a known device keeps the same key instead of a label alias.
    if (/^(?:ACK|ACKED|ACKNOWLEDGED)\s+TROUBLE\b/i.test(message)) {
      this.flushPending();
      this.pending=message.replace(/^(?:ACK|ACKED|ACKNOWLEDGED)\s+/i,'');
      this.pendingAcknowledged=true;
      return;
    }
    // Generic acknowledgement commands and other ACK records are not states.
    if (/^(?:ACK|ACKED|ACKNOWLEDGED|ACKNOWLEDGEMENT)\b/i.test(message)) {
      this.flushPending();
      return;
    }
    if(isNotifierDetail(message)) {
      if(isSpecialZone(message) || (this.n16Mode && isN16GeneralZone(message))) {this.pending=null;this.pendingAcknowledged=false;return;}
      if(this.pending) {
        const address=message.match(/\b(?:(?:N\d{1,3}[- ]?)?L\d{1,3}[DM]\d{1,4}|N\d{1,3}(?:ZF?|T)\d{1,4})\b/i)?.[0].toUpperCase().replace(/\s/g,'');
        this.apply(this.pending,address,this.pendingAcknowledged);
        this.pending=null;this.pendingAcknowledged=false;
      }
      return; // Orphan device details must never activate a queue.
    }
    this.flushPending();
    this.pending=null;
    if(/^(?:(?:CLEARED|RESTORED)\s+)?(?:TROUBLE|FIRE ALARM|ALARM|TRACK SUPERV|SUPERVISORY|SUPERV|SUPV|DISABLED)\b/i.test(message))this.pending=message;
    else this.apply(message);
  }
  counts() {
    const snapshot=this.clone();
    // A header without an address may belong to a Special Zone. Wait for
    // its detail line instead of temporarily counting an unidentified event.
    if(snapshot.pending && /\b(?:N\d{1,3})?L\d{1,3}[DM]\d{1,4}\b/i.test(snapshot.pending))snapshot.apply(snapshot.pending);
    const counts={...snapshot.unobserved};
    for(const [key,category] of snapshot.active) {
      // Show a supervisory point in Trouble while its trouble is active.
      // Retain its supervisory state so a trouble restoral can reveal it again.
      if(category==='supervisory' && snapshot.active.has(`trouble:${key.slice('supervisory:'.length)}`))continue;
      counts[category]++;
    }
    return counts;
  }
}
