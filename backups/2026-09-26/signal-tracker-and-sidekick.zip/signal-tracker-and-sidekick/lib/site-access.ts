import { env } from 'cloudflare:workers';

export const ACCESS_COOKIE = 'signal_tracker_access';
export const ACCESS_AGE = 30 * 24 * 60 * 60;
const encoder = new TextEncoder();
const hex = (bytes: ArrayBuffer) => Array.from(new Uint8Array(bytes), b => b.toString(16).padStart(2, '0')).join('');
async function key() {
  if (!env.ACCESS_SIGNING_KEY || !env.COWORKER_PASSCODE) throw new Error('Access is not configured');
  return crypto.subtle.importKey('raw', encoder.encode(env.ACCESS_SIGNING_KEY), {name:'HMAC', hash:'SHA-256'}, false, ['sign', 'verify']);
}
export async function signature(value: string) {
  return hex(await crypto.subtle.sign('HMAC', await key(), encoder.encode(value)));
}
export async function validPasscode(value: string) {
  return await signature('passcode:' + value) === await signature('passcode:' + env.COWORKER_PASSCODE);
}
export async function issueAccess() {
  const payload = String(Math.floor(Date.now()/1000) + ACCESS_AGE);
  return payload + '.' + await signature(payload + ':' + env.COWORKER_PASSCODE);
}
export async function hasAccess(request: Request) {
  try {
    const bearer = request.headers.get('authorization')?.match(/^Bearer ([0-9]{10}\.[a-f0-9]{64})$/)?.[1];
    const value = bearer || request.headers.get('cookie')?.split(';').map(c => c.trim()).find(c => c.startsWith(ACCESS_COOKIE + '='))?.slice(ACCESS_COOKIE.length+1) || '';
    const [expiry, sig, extra] = value.split('.');
    if (extra || !/^\d{10}$/.test(expiry) || !/^[a-f0-9]{64}$/.test(sig || '') || Number(expiry) <= Date.now()/1000 || Number(expiry) > Date.now()/1000+ACCESS_AGE+60) return false;
    const bytes = Uint8Array.from(sig.match(/../g)!, b => parseInt(b,16));
    return crypto.subtle.verify('HMAC', await key(), bytes, encoder.encode(expiry + ':' + env.COWORKER_PASSCODE));
  } catch { return false; }
}
export function safeReturn(value: string | null) {
  if (!value || !value.startsWith('/') || value.startsWith('//') || value.includes('\\') || /[\r\n]/.test(value)) return '/';
  const url = new URL(value, 'https://local.invalid');
  if (url.origin !== 'https://local.invalid' || url.pathname.startsWith('/unlock')) return '/';
  return url.pathname + url.search;
}
