import { COMM_PRESETS } from "./communication-presets";

export type WiringGuide = {
  value: string;
  manufacturer: string;
  model: string;
  series: string;
  port: string;
  columns: [string, string, string];
  rows: string[][];
  notes: string[];
};

const notifier = (
  value: string,
  model: string,
  series: string,
  port: string,
  terminals: [string, string, string],
  notes: string[] = [],
): WiringGuide => ({
  value,
  manufacturer: "Notifier",
  model,
  series,
  port,
  columns: ["Panel terminal", "DB-9 pin", "Wire color"],
  rows: [
    [terminals[0], "Pin 2 · PTX", "Black"],
    [terminals[1], "Pin 3 · PRX", "Red"],
    [terminals[2], "Pin 5 · REF", "Green"],
  ],
  notes,
});

const threeWireNotes = [
  "DB-9 female connector is shown from the rear / wiring side.",
  "The colors shown are Signal Tracker's standard field-cable convention; they replace cable colors printed in older manuals.",
];

export const WIRING_GUIDES: WiringGuide[] = [
  notifier("notifier-n16", "N16", "INSPIRE Series", "Printer connection · TX / RX / CTS / REF", ["TX", "RX", "REF"], ["Connect by the printed TX, RX and REF markings. Leave CTS unconnected in this three-wire receive configuration.", ...threeWireNotes]),
  notifier("notifier-nfw-100", "NFW-100", "FireWarden Series", "TB8 · serial printer / computer connection", ["TX", "RCV", "GRND"], ["Use the TX, RCV and GRND points shown at the TB8 serial interface. DTR is not used in this three-wire connection.", ...threeWireNotes]),
  notifier("notifier-nfw2-100", "NFW2-100", "FireWarden Series", "TB8 · serial printer / computer connection", ["TX", "RCV", "GRND"], ["Use the TX, RCV and GRND points shown at the TB8 serial interface. DTR is not used in this three-wire connection.", ...threeWireNotes]),
  notifier("notifier-nfs-320", "NFS-320", "ONYX Series", "TB12 · PRN-series printer connection", ["TB12 PTX", "TB12 PRX", "TB12 REF"], threeWireNotes),
  notifier("notifier-nfs2-640", "NFS2-640", "ONYX Series", "TB12 · PRN-series printer connection", ["TB12 PTX", "TB12 PRX", "TB12 REF"], threeWireNotes),
  notifier("notifier-nfs2-3030", "NFS2-3030", "ONYX Series", "TB5 · PRN-series printer connection", ["TB5 PTX", "TB5 PRX", "TB5 REF"], ["Leave CTX, CTS/CRX and the second REF terminal unconnected in this three-wire connection.", ...threeWireNotes]),
  notifier("notifier-nca-2", "NCA-2", "ONYX Network Annunciator", "TB5 · PRN-series printer connection", ["TB5 PTX", "TB5 PRX", "TB5 REF"], ["Leave CTX, CTS/CRX and the second REF terminal unconnected in this three-wire connection.", ...threeWireNotes]),
  notifier("notifier-afp-100", "AFP-100", "AFP Series", "TB7 · printer / computer interface", ["TB7 TX", "TB7 RCV", "TB7 GRND"], ["Use the TX, RCV and GRND terminals at the printer interface. The manual's cable-color labels are superseded by the Signal Tracker color standard.", ...threeWireNotes]),
  notifier("notifier-afp-200", "AFP-200", "AFP Series", "TB4 · EIA-232 printer interface", ["TB4-1 TX", "TB4-3 RX", "TB4-2 REF"], ["The supplied reference identifies TB4-1 as TX, TB4-2 as REF and TB4-3 as RX. A pin 4-to-6 jumper mentioned for upload/download is outside this three-wire monitor cable.", ...threeWireNotes]),
  notifier("notifier-afp-400", "AFP-300/400", "AFP Series", "CPU-400 TB1 · EIA-232 printer interface", ["TB1-1 TX", "TB1-2 RX", "TB1-3 REF"], ["The source depicts a PRN-4 DB-25 connection; this drawing adapts the same TX, RX and REF terminal roles to the Signal Tracker DB-9 standard.", ...threeWireNotes]),
  {
    value: "ili-mb-e3", manufacturer: "Gamewell-FCI", model: "ILI-MB-E3", series: "E3 Series", port: "TB6 · RS-232 download or printer port",
    columns: ["Panel terminal", "DB-9 pin", "Wire color"],
    rows: [["TB6-2 TxD", "Pin 2 · PTX", "Black"], ["TB6-4 RxD", "Pin 3 · PRX", "Red"], ["TB6-1 GND", "Pin 5 · REF", "Green"]],
    notes: ["TB6-3 supervision is not used in this three-wire connection.", ...threeWireNotes],
  },
  {
    value: "ili95-mb-e3", manufacturer: "Gamewell-FCI", model: "ILI95-MB-E3", series: "E3 Series", port: "TB6 · RS-232 download or printer port",
    columns: ["Panel terminal", "DB-9 pin", "Wire color"],
    rows: [["TB6-4 TxD", "Pin 2 · PTX", "Black"], ["TB6-2 RxD", "Pin 3 · PRX", "Red"], ["TB6-1 GND", "Pin 5 · REF", "Green"]],
    notes: ["This board revision reverses the TB6-2 and TB6-4 TX/RX roles shown on the other supplied E3 references. TB6-3 supervision is not used.", ...threeWireNotes],
  },
  {
    value: "ili-s-e3", manufacturer: "Gamewell-FCI", model: "ILI-S-E3", series: "E3 Series", port: "TB6 · RS-232 download or printer port",
    columns: ["Panel terminal", "DB-9 pin", "Wire color"],
    rows: [["TB6-2 TxD", "Pin 2 · PTX", "Black"], ["TB6-4 RxD", "Pin 3 · PRX", "Red"], ["TB6-1 GND", "Pin 5 · REF", "Green"]],
    notes: ["TB6-3 supervision is not used in this three-wire connection.", ...threeWireNotes],
  },
  {
    value: "est3", manufacturer: "Edwards / EST", model: "EST3", series: "CPU terminal reference", port: "CPU · TB2 port 2",
    columns: ["Panel terminal", "DB-9 pin", "Wire color"],
    rows: [["TB2 TX2", "Pin 2 · PTX", "Black"], ["TB2 RX2", "Pin 3 · PRX", "Red"], ["TB2 COM2", "Pin 5 · REF", "Green"]],
    notes: ["The supplied source calls this a modem serial cable. Confirm that port 2 is programmed for the required event output.", ...threeWireNotes],
  },
  {
    value: "est-io64", manufacturer: "Edwards / EST", model: "iO64", series: "SA-232 card", port: "SA-232 card to computer DB-9",
    columns: ["Panel terminal", "DB-9 pin", "Wire color"],
    rows: [["SA-232 TXD", "Pin 2 · PTX", "Black"], ["SA-232 RXD", "Pin 3 · PRX", "Red"], ["SA-232 GND", "Pin 5 · REF", "Green"]],
    notes: ["RTS is not used in this three-wire connection.", ...threeWireNotes],
  },
];

const WIRING_PANEL_OPTIONS = WIRING_GUIDES.map(({ value, manufacturer, model, series }) => ({ value, manufacturer, model, series, label: `${manufacturer} ${model}` }));
export const PANEL_OPTIONS = [
  ...WIRING_PANEL_OPTIONS,
  ...COMM_PRESETS.filter((preset) => !WIRING_PANEL_OPTIONS.some((guide) => guide.value === preset.value)).map((preset) => ({ value: preset.value, label: preset.label, manufacturer: preset.label.split(" ")[0], model: preset.label, series: "Communication preset" })),
  { value: "other", label: "Other / manual settings", manufacturer: "Other", model: "Manual", series: "Manual" },
];

const LEGACY_PANEL_LABELS: Record<string, string> = {
  "notifier-onyx": "Notifier ONYX Series", "notifier-inspire": "Notifier INSPIRE Series", "fci-e3-s3": "Gamewell-FCI E3 / S3", "est-3-4": "Edwards EST3 / EST4", "gamewell-e3": "Gamewell-FCI E3 Series", "gamewell-s3": "Gamewell-FCI S3 Series", "est4": "Edwards EST4", "other": "Other / bench source",
};

export function panelLabel(value: string) {
  return PANEL_OPTIONS.find((panel) => panel.value === value)?.label ?? LEGACY_PANEL_LABELS[value] ?? "Panel source";
}

export function guideForPanel(value: string) {
  return WIRING_GUIDES.find((guide) => guide.value === value);
}
