/** Own cancellation through completion before releasing locks and closing the port. */
export class SerialCleanup {
  reader: ReadableStreamDefaultReader<Uint8Array> | null = null;
  writer: WritableStreamDefaultWriter<Uint8Array> | null = null;
  private cancellation: Promise<void> | null = null;

  cancelRead(): Promise<void> {
    if (!this.reader) return Promise.resolve();
    return this.cancellation ??= this.reader.cancel().catch(() => {
      // A removed device or errored stream still needs its lock released.
    });
  }

  async releaseStreams(): Promise<void> {
    await this.cancelRead();
    // Abort pending output on intentional shutdown; never leave a writer lock behind.
    if (this.writer) {
      try { await this.writer.abort(); } catch { /* Already errored/removed. */ }
      finally { this.writer.releaseLock(); this.writer = null; }
    }
    if (this.reader) { this.reader.releaseLock(); this.reader = null; }
  }

  async close(port: {close(): Promise<void>}): Promise<void> {
    await this.releaseStreams();
    // Propagate failure so the owner retains the port and can retry closing it.
    await port.close();
  }
}
