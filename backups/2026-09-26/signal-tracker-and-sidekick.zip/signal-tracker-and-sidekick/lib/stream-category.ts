import { notifierCountSummary } from './notifier-count-summary';
import type { EventCategory } from './panelstream';
export const THEMED_STREAM_LABELS:Record<string,string> = {
 'status-change':'Status Change','separator':'','system-normal':'System Normal',
 'system-reset':'System Reset', acknowledged:'Acknowledged','signal-silence':'Signal Silence',
 'screen-print':'Screen Print','time-date':'Time and Date','event-counts':'Events Counts Display',
 'read-status':'Read Status','program-alter':'Program/Alter Status','multiple-events':'Multiple Event List',
 'printer-functions':'Printer Functions','history-display':'History Display','event-history':'Event History','node-label':'Node Label',
};
export type StreamCategory = EventCategory | 'status-change' | 'system-normal' | 'separator' | 'system-reset' | 'acknowledged' | 'screen-print' | 'time-date' | 'event-counts' | 'read-status' | 'program-alter' | 'multiple-events' | 'printer-functions' | 'history-display' | 'event-history' | 'node-label' | 'signal-silence';
const timestamp = /^(?:[=*\-]\s*)*\d{1,2}:\d{2}(?::\d{2})?\s*[AP]M?\s+(?:MON|TUE|WED|THU|FRI|SAT|SUN)\s+(?:[A-Z]{3}\s+\d{1,2},?\s+\d{4}|\d{1,2}\/\d{1,2}\/\d{2,4})(?:\s*[=*\-])*$/i;
const signalHeader = /^(?:TROUBLE|ALARM|FIRE\s+ALARM|TRACK\s+SUPERV|SUPERVISORY|SUPERV|SUPV|DISABLED|ACTIVE|CLR|CLEARED|RESTORED|SYSTEM|ACK|ACKED|INITIATED)\b/i;
const signalSilence = /^[*=\s-]*SIGNALS?\s+SILENC(?:E|ED)\b/i;
const panelFunctions:[RegExp,StreamCategory][] = [
 [signalSilence,'signal-silence'],
 [/^[* =-]*EVENT\s+HISTORY\b/i,'event-history'],
 [/^[* =-]*SCREEN\s+PRINT\b/i,'screen-print'],[/^TIME\s*(?:AND|&|\/)\s*DATE\b/i,'time-date'],
 [/^[*=\s-]*EVENTS?\s+COUNTS?\b/i,'event-counts'],[/^READ\s+STATUS\b/i,'read-status'],
 [/^PROGRAM\s*(?:\/|\s)\s*ALTER\s+STATUS\b/i,'program-alter'],[/^MULTIPLE\s+EVENT\s+LIST\b/i,'multiple-events'],
 [/^PRINTER\s+FUNCTIONS?\b/i,'printer-functions'],[/^HISTORY\s+DISPLAY\b/i,'history-display'],
];
// Stream labels are separate from active-condition queue bookkeeping.
export function streamCategory(event:{category:EventCategory;message:string}, previousMessage='', nextMessage=''):StreamCategory {
 const message=event.message.trim();
 if(/^CLR\s+TB\b/i.test(message) && /\bDISABL(?:E|ED)?\s+\d{1,2}:\d{2}(?::\d{2})?\s*[AP]M?\s+\d{5,6}\s+(?:\d+[DM]\d+|B\d+)\s*$/i.test(message))return 'other';
 if(/^STATUS\s+CHANGE\b/i.test(message))return 'status-change';
 if(/^DISABL(?:E|ED)?\b/i.test(message))return 'other';
 if(/^(?:TROUBL|CLR\s+TB)\b/i.test(message))return 'trouble';
 if(/\bSYSTEM\s+NORMAL\b/i.test(message) && !/^(?:TROUBLE|FIRE\s+ALARM|ALARM|SUPERVISORY|SUPERV|SUPV|DISABLED|ACTIVE|CLR|CLEARED|RESTORED)\b/i.test(message))return 'system-normal';
 if(/^=+$/.test(message))return 'separator';
 if(/^\d+\s+TBL\b/i.test(message))return 'trouble';
 if(signalSilence.test(message))return 'signal-silence';
 if(notifierCountSummary(message))return 'event-counts';
 if(timestamp.test(message))return 'time-date';
 if(!signalHeader.test(message) && !/\b(?:N\d+)?L\d+[DM]\d+\b/i.test(message)) {
  const nodeDetail=message.match(/^(.+?)\s{2,}(\d{1,2}:.*)$/);
  if(/^NODE\s+LABEL\s*:/i.test(message) || (nodeDetail && timestamp.test(nodeDetail[2])) || (event.category==='other' && timestamp.test(nextMessage.trim()) && !panelFunctions.some(([pattern])=>pattern.test(message))))return 'node-label';
 }
 const direct=panelFunctions.find(([pattern])=>pattern.test(message));
 if(direct)return direct[1];
 if(/^(?:SYSTEM\s+RESET\b|INITIATED\s+BY\s+N\s*\d+\b)/i.test(message))return 'system-reset';
 const acknowledgement=/^\s*(?:ACK|ACKED|ACKNOWLEDGED|ACKNOWLEDGE|ACKNOWLEDGEMENT|BLOCK ACKNOWLEDGE)\b/i;
 if(acknowledgement.test(message))return 'acknowledged';
 const detail=/\b\d{1,2}:\d{2}:\d{2}[AP]?\s+(?:MON|TUE|WED|THU|FRI|SAT|SUN)\b/i;
 if(detail.test(message) && !/^(?:TROUBLE|ALARM|FIRE ALARM|TRACK SUPERV|SUPERVISORY|SUPERV|SUPV|DISABLED|ACTIVE|CLR|CLEARED|RESTORED)\b/i.test(message)) {
  if(acknowledgement.test(previousMessage))return 'acknowledged';
  const previous=panelFunctions.find(([pattern])=>pattern.test(previousMessage.trim()));
  if(previous)return previous[1];
 }
 return event.category;
}

// Color acknowledgement records without changing labels, filters or queue semantics.
export function streamSignalColor(category:StreamCategory, message:string, previousMessage='', panelFamily=''):EventCategory | null {
 if(panelFamily==='notifier-n16' && category==='acknowledged' &&
   /^\s*(?:ACK|ACKED|ACKNOWLEDGED|ACKNOWLEDGE)\s+(?:FIRE\s+)?ALARM\b/i.test(message) )return 'alarm';
 if(panelFamily==='notifier-n16' && category==='acknowledged' &&
   /^\s*(?:ACK|ACKED|ACKNOWLEDGED|ACKNOWLEDGE)\s+(?:FIRE\s+)?ALARM\b/i.test(previousMessage) &&
   !/^\s*(?:ACK|ACKED|ACKNOWLEDGED|ACKNOWLEDGE)\b/i.test(message))return 'alarm';
 if(category in THEMED_STREAM_LABELS || (panelFamily==='notifier-n16' && category==='other'))return null;
 return category as EventCategory;
}
