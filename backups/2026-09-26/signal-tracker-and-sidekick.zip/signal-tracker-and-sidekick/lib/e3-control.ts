// Reported terminal bytes; independent source, not hardware validated.
export const E3_ACTIONS = {
  ackAlarm: { label: 'Acknowledge alarm', bytes: [0x41, 0x20, 0x31, 0x0d] },
  ackTrouble: { label: 'Acknowledge trouble', bytes: [0x41, 0x20, 0x30, 0x0d] },
  silence: { label: 'Silence panel', bytes: [0x53, 0x20, 0x30, 0x0d] },
  reset: { label: 'Reset panel', bytes: [0x52, 0x20, 0x0d] },
} as const;
// Read-only terminal query used to prove both serial directions. It does not
// acknowledge, silence, reset, enable or disable any panel function.
export const E3_FIRMWARE_QUERY = new Uint8Array([0x56, 0x0d]);
export type E3Action = keyof typeof E3_ACTIONS;
export const isE3 = (panel: string) => ['ili-mb-e3', 'ili95-mb-e3', 'ili-s-e3', 'gamewell-e3'].includes(panel);
export const isE3Action = (action: unknown): action is E3Action => typeof action === 'string' && Object.hasOwn(E3_ACTIONS, action);
export function commandBytes(action: E3Action, resetFormat: string) {
  if (action === 'reset' && !['hex', 'text'].includes(resetFormat)) throw new Error('Choose a reset test format on the laptop.');
  return new Uint8Array(action === 'reset' && resetFormat === 'text' ? [0x52, 0x0d] : E3_ACTIONS[action].bytes);
}
