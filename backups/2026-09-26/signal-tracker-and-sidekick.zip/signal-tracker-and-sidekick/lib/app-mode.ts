/** QR links, invitations and installed SideKick launches share this entry rule. */
export function isSidekickEntry(search:string) {
  const params=new URLSearchParams(search);
  return params.get('mode')==='companion' || Boolean(params.get('session'));
}
