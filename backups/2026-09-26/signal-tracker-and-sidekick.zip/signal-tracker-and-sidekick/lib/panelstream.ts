import { notifierCountSummary } from './notifier-count-summary';
import { isNotifierDetail, isSpecialZone, isNotifierPrintedTrouble } from "./notifier-format";
export const EVENT_CATEGORIES = [
  "alarm",
  "supervisory",
  "trouble",
  "other",
] as const;

export type EventCategory = (typeof EVENT_CATEGORIES)[number];

export type SerialEvent = {
  id: number;
  category: EventCategory;
  message: string;
  source: string;
  occurredAt: string;
};

export type QueueMutation =
  | { action: "activate"; pointKey: string }
  | { action: "clear"; pointKey: string }
  | { action: "reset-alarms" };

export const DEFAULT_COLORS: Record<EventCategory, string> = {
  alarm: "#ef4444",
  supervisory: "#3b82f6",
  trouble: "#facc15",
  other: "#f97316",
};

export const CATEGORY_LABELS: Record<EventCategory, string> = {
  alarm: "Alarm",
  supervisory: "Supervisory",
  trouble: "Trouble",
  other: "Other",
};

export function isEventCategory(value: unknown): value is EventCategory {
  return EVENT_CATEGORIES.includes(value as EventCategory);
}

// NFS2-640 prints re-enabled disabled points as CLR TB with DISABL status.
export function isDisabledPointRestoral(message:string) {
  return /^\s*CLR\s+TB\b/i.test(message) && /\bDISABL(?:E|ED)?\s+\d{1,2}:\d{2}(?::\d{2})?\s*[AP]M?\s+\d{5,6}\s+(?:\d+[DM]\d+|B\d+)\s*$/i.test(message);
}

export function classifySerialMessage(message: string): EventCategory {
  if (notifierCountSummary(message) || isNotifierDetail(message)) return "other";
  if (isDisabledPointRestoral(message)) return "other";
  if (/^\s*(?:TROUBL|CLR\s+TB)\b/i.test(message)) return "trouble";
  if (isNotifierPrintedTrouble(message)) return "trouble";
  const normalized = message.toUpperCase();
  if (/\b(?:DISABL(?:E|ED)?|RE[- ]?ENABL(?:E|ED)|ENABL(?:E|ED)|UN?BYPASS(?:ED)?|BYPASS(?:ED)?|DEISOLAT(?:E|ED)|ISOLAT(?:E|ED))\b/.test(normalized)) return "other";

  if (/\b(TROUBLE|TRBL|FAULT|FAILURE|GROUND\s+FAULT|OFFLINE|MISSING)\b/.test(normalized)) {
    return "trouble";
  }

  if (/\b(SUPERVISORY|SUPERV|SUPV|SPRINKLER\s+SUPV)\b/.test(normalized)) {
    return "supervisory";
  }

  if (/\b(ALARM|FIRE|EVACUATION|EVAC)\b/.test(normalized)) {
    return "alarm";
  }

  return "other";
}

const CLEAR_PATTERN = /\b(CLEAR(?:ED)?|RESTOR(?:E|ED|AL)|NORMAL|ENABL(?:E|ED)|UNBYPASS(?:ED)?|DEISOLAT(?:E|ED)|RE[- ]?ENABL(?:E|ED)|RETURN(?:ED)?\s+TO\s+NORMAL)\b/i;
// Only a received reset event releases alarm latches, never a normal/restoral line.
const RESET_PATTERN = /\b(?:SYSTEM\s+RESET|RESET\s+(?:COMPLETE|COMPLETED))\b/i;
const NON_EVENT_PATTERN = /\b(?:ACK(?:NOWLEDG(?:E|ED|EMENT))?|REQUEST(?:ED)?|FAILED|FAILURE|DENIED|IN\s+PROGRESS)\b/i;
const OTHER_QUEUE_PATTERN = /\b(DISABL(?:E|ED)?|BYPASS(?:ED)?|ISOLAT(?:E|ED)|NON[- ]?FIRE|ACTIVE\s+MONITOR)\b/i;
const STATUS_WORDS_PATTERN = /\b(FIRE\s+ALARM|ALARM|SUPERVISORY|SUPERV|SUPV|TROUBLE|TRBL|FAULT|FAILURE|GROUND\s+FAULT|OFFLINE|MISSING|CLEAR(?:ED)?|RESTOR(?:E|ED|AL)|NORMAL|RESET|RE[- ]?ENABL(?:E|ED)|ENABL(?:E|ED)|UNBYPASS(?:ED)?|DEISOLAT(?:E|ED)|RETURN(?:ED)?|TO|DISABL(?:E|ED)?|BYPASS(?:ED)?|ISOLAT(?:E|ED)|ACTIVE)\b/gi;

function extractPointKey(message: string) {
  const upper = message.toUpperCase().replace(/\b\d{1,2}:\d{2}(?::\d{2})?\b/g, " ").replace(/\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b/g, " ");
  const addressMatches = upper.match(
    /\b(?:NODE\s*\d{1,3}|(?:N\d{1,3}[- ]?)?L\d{1,3}[A-Z]?\d{1,4}|\d{1,3}[DM]\d{1,4}|[DMZB]\d{1,4}|\d{2,4}[-:]\d{2,4}(?:[-:]\d{1,4})?)\b/g,
  );

  if (addressMatches?.length) {
    return Array.from(new Set(addressMatches.map((value) => value.replace(/\s+/g, ""))))
      .slice(0, 3)
      .join("|");
  }

  return upper
    .replace(/\b\d{1,2}:\d{2}(?::\d{2})?\b/g, " ")
    .replace(/\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b/g, " ")
    .replace(STATUS_WORDS_PATTERN, " ")
    .replace(/[^A-Z0-9]+/g, " ")
    .trim()
    .slice(0, 160);
}

/**
 * Turns common panel event/restore text into the current queue state. The raw
 * event history is always preserved; this reducer only drives the bottom-bar
 * device counts.
 */
export function deriveQueueMutation(message: string, category: EventCategory): QueueMutation | null {
  if (notifierCountSummary(message) || isNotifierPrintedTrouble(message) || isNotifierDetail(message) || isSpecialZone(message)) return null;
  if (RESET_PATTERN.test(message)) return NON_EVENT_PATTERN.test(message) ? null : { action: "reset-alarms" };
  if (/\b(?:ACK|ACKED|ACKNOWLEDGED|ACKNOWLEDGEMENT)\b/i.test(message)) return null;

  // NFS2-640 trouble/restoral headers share one identity. Its printer
  // timestamp may change between activation and restoral, so omit that suffix.
  if (/^\s*(?:TROUBL|CLR\s+TB)\b/i.test(message)) {
    message = message.trim().replace(/^TROUBL\b/i, "TROUBLE")
      .replace(/^CLR\s+TB\b/i, "CLEARED TROUBLE")
      .replace(/\s+\d{1,2}:\d{2}(?::\d{2})?\s*[AP]M?\s+\d{6}(?:\s+(?:MON|TUE|WED|THU|FRI|SAT|SUN)\b)?/i, "");
  }
  const pointKey = extractPointKey(message);
  if (!pointKey) return null;
  if (CLEAR_PATTERN.test(message)) return category === "alarm" ? null : { action: "clear", pointKey };

  if (category === "other" && !OTHER_QUEUE_PATTERN.test(message)) return null;
  return { action: "activate", pointKey };
}

export function normalizeSessionCode(value: string) {
  return value.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 8);
}

export function normalizeMessage(value: string) {
  return value.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, "").trim().slice(0, 2000);
}
