// In the captured 3030 printer format these are device details, not transitions.
export function isNotifierDetail(message:string) {
  return /\b\d{1,2}:\d{2}:\d{2}[AP]?\s+(?:MON|TUE|WED|THU|FRI|SAT|SUN)\s+[A-Z]{3}\s+\d{1,2},?\s+\d{4}\b/i.test(message)
    && !/^(?:(?:CLR|CLEARED|RESTORED)\s+)?(?:TROUBLE|FIRE ALARM|ALARM|TRACK SUPERV|SUPERVISORY|SUPERV|SUPV|DISABLED)\b/i.test(message.trim());
}

export function usesNotifierPrinterParser(panelFamily:string) {
  return panelFamily === "notifier-nfs2-3030" || panelFamily === "notifier-n16";
}

export function isNotifierActiveEvent(message:string) {
  return /^(?:(?:CLR|CLEARED|RESTORED|ACK|ACKED|ACKNOWLEDGED)\s+)?ACTIVE\b/i.test(message.trim());
}

export function isSpecialZone(message:string) {
  return /\bSPECIAL\s+ZONE\b|\b(?:N\d{1,3})?ZF\d{1,4}\b/i.test(message);
}

// N16 General Zone records summarize member conditions; they are not an
// additional device in the panel's condition queue. Keep them in history.
export function isN16GeneralZone(message:string) {
  return /\bGENERAL\s+ZONE\b/i.test(message) && /\bN\d{1,3}Z\d{1,4}\b/i.test(message);
}

// Numbered rows and the list heading describe a printed snapshot, not transitions.
export function isNotifierPrintedTrouble(message:string) {
  return /^\s*\d+\s+TBL\b/i.test(message) || /^[=\s]*TROUBLE:\s*\d+\s+OF\s+\d+[=\s]*$/i.test(message);
}
