import { NextResponse } from 'next/server';
import { hasAccess } from './lib/site-access';

export async function middleware(request: Request) {
  const url = new URL(request.url);
  const path = url.pathname;
  if (path === '/unlock' || path.startsWith('/_next/') || path.startsWith('/assets/') || ['/sw.js','/manifest.webmanifest','/sidekick.webmanifest','/signal-tracker-logo.png','/sidekick-192.png','/sidekick-512.png','/favicon.ico'].includes(path)) return NextResponse.next();
  if (await hasAccess(request)) {
    const response = NextResponse.next();
    response.headers.set('Cache-Control','private, no-store');
    return response;
  }
  if (path.startsWith('/api/')) return Response.json({error:'Enter the coworker passcode to continue.'}, {status:401,headers:{'Cache-Control':'no-store'}});
  // The app shell displays the access gate; all data endpoints remain protected.
  const response = NextResponse.next();
  response.headers.set('Cache-Control','private, no-store');
  return response;
}
