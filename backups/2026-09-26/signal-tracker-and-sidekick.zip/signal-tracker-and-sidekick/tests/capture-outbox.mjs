import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import ts from 'typescript';
// A transactional IDB test adapter, shared across simulated page reloads.
let rows=[],nextId=1,fail=false;
const db={createObjectStore(){return {createIndex(){}};},transaction(){
 const draft=structuredClone(rows),tx={};const requests=[];
 tx.objectStore=()=>({
 add(value){const row={...structuredClone(value),id:nextId++};draft.push(row);const r={result:row.id};requests.push(r);return r;},
 delete(id){const i=draft.findIndex(r=>r.id===id);if(i>=0)draft.splice(i,1);return {result:undefined};},
 index(){return {getAll(code){return {result:structuredClone(draft.filter(r=>r.code===code))};}};},
 });
 setImmediate(()=>{if(fail){tx.error=Error('Quota exceeded');tx.onabort?.();}else{rows=draft;tx.oncomplete?.();}});return tx;
}};
globalThis.indexedDB={open(){const request={result:db};setImmediate(()=>request.onsuccess());return request;}};
const js=ts.transpileModule(readFileSync('lib/capture-outbox.ts','utf8'),{compilerOptions:{module:ts.ModuleKind.ESNext}}).outputText;
const url='data:text/javascript;base64,'+Buffer.from(js).toString('base64');
const store=await import(url);
const events=Array.from({length:237},(_,i)=>({message:`TROUBLE ${i}`,category:'trouble',source:'serial',occurredAt:'2026-09-26T06:00:00.000-07:00'}));
await store.saveCapture('SESSIONA',events);
assert.deepEqual((await store.pendingCapture('SESSIONA')).map(b=>b.events.length),[100,100,37]);
assert.equal(new Set(rows.map(b=>b.batchId)).size,3);
const reopened=await import(url+'#reopened');
assert.deepEqual((await reopened.pendingCapture('SESSIONA')).flatMap(b=>b.events),events);
await reopened.saveCapture('SESSIONB',[events[0]]);
assert.equal((await reopened.pendingCapture('SESSIONB')).length,1);
const first=(await reopened.pendingCapture('SESSIONA'))[0];await reopened.removeCapture(first.id);
assert.equal((await reopened.pendingCapture('SESSIONA')).flatMap(b=>b.events).length,137);
assert.equal((await reopened.pendingCapture('SESSIONB')).length,1);
fail=true;await assert.rejects(reopened.saveCapture('SESSIONA',events),/Quota/);fail=false;
assert.equal((await reopened.pendingCapture('SESSIONA')).flatMap(b=>b.events).length,137);
console.log('PASS: local capture batching, stable retry IDs, order, reload recovery, session isolation and storage failure retains prior data');
