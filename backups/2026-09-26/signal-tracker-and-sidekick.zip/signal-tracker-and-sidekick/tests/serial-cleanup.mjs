import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import ts from 'typescript';
const code=ts.transpileModule(readFileSync('lib/serial-cleanup.ts','utf8'),{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText;
const {SerialCleanup}=await import('data:text/javascript;base64,'+Buffer.from(code).toString('base64'));
let opened=false, closed=0;
for(let session=0;session<5;session++) {
 assert.equal(opened,false,'Previous session must fully release the same port before reopening');
 opened=true;
 let finishCancel, cancelCalls=0;
 const readable=new ReadableStream({cancel(){cancelCalls++;return new Promise(resolve=>{finishCancel=resolve;});}});
 const writable=new WritableStream();
 const cleanup=new SerialCleanup();cleanup.reader=readable.getReader();cleanup.writer=writable.getWriter();
 const pendingRead=cleanup.reader.read();
 const cancel=cleanup.cancelRead();
 assert.equal(cleanup.cancelRead(),cancel,'Disconnect and final cleanup share cancellation');
 assert.equal((await pendingRead).done,true);
 const port={async close(){assert.equal(readable.locked,false);assert.equal(writable.locked,false);opened=false;closed++;}};
 const finishing=cleanup.close(port);
 await Promise.resolve();
 assert.equal(opened,true,'Do not close while the driver cancellation is still pending');
 finishCancel();await finishing;assert.equal(cancelCalls,1);
}
assert.equal(closed,5);
// A failed OS close is visible to the caller and the same handle remains retryable.
let attempts=0;
const port={async close(){if(++attempts===1)throw new Error('Driver busy');}};
const cleanup=new SerialCleanup();
await assert.rejects(cleanup.close(port),/Driver busy/);
await cleanup.close(port);assert.equal(attempts,2);
// A USB disconnect/error still releases both stream locks.
const r=new ReadableStream({start(c){c.error(new Error('Device removed'));}});
const w=new WritableStream({abort(){throw new Error('Device removed');}});
const removed=new SerialCleanup();removed.reader=r.getReader();removed.writer=w.getWriter();
await removed.close({async close(){assert.equal(r.locked,false);assert.equal(w.locked,false);}});
console.log('PASS: five repeated reopen cycles, delayed cancellation, duplicate stop, reader/writer lock release, close failure/retry and removed-device cleanup');
