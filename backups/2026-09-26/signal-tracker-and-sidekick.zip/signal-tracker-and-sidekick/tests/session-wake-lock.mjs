import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import ts from 'typescript';
const source=ts.transpileModule(readFileSync('lib/session-wake-lock.ts','utf8'),{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText;
const {createSessionWakeLock}=await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));
function lock(){let listener;return {released:false,addEventListener:(_,fn)=>{listener=fn;},async release(){this.released=true;listener?.();}};}
let visible=true,status,calls=0,last;
const active=createSessionWakeLock({visible:()=>visible,onStatus:s=>status=s,request:async()=>{calls++;return last=lock();}});
await active.acquire();assert.equal(status,'active');await active.acquire();assert.equal(calls,1);
await last.release();assert.equal(status,'paused');visible=false;await active.acquire();assert.equal(calls,1);
visible=true;await active.acquire();assert.equal(calls,2);assert.equal(status,'active');active.stop();assert.equal(last.released,true);await active.acquire();assert.equal(calls,2);
let resolve;const delayed=createSessionWakeLock({visible:()=>true,onStatus:s=>status=s,request:()=>new Promise(r=>resolve=r)});
const pending=delayed.acquire();const finalLock=lock();delayed.stop();resolve(finalLock);await pending;assert.equal(finalLock.released,true);
const missing=createSessionWakeLock({visible:()=>true,onStatus:s=>status=s});await missing.acquire();assert.equal(status,'unavailable');missing.stop();
const denied=createSessionWakeLock({visible:()=>true,onStatus:s=>status=s,request:async()=>{throw Error('Denied');}});await denied.acquire();assert.equal(status,'unavailable');denied.stop();
console.log('PASS: wake lock acquisition, duplicate prevention, release status, visibility return, session cleanup, late resolution, unsupported and denied requests');
