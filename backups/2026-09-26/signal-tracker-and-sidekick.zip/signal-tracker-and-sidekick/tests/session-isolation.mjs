import { DatabaseSync } from 'node:sqlite';
import { readFileSync, readdirSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { createRequire } from 'node:module';
import vm from 'node:vm';
import ts from 'typescript';
import assert from 'node:assert/strict';
import { drizzle } from 'drizzle-orm/d1';
const nativeRequire=createRequire(import.meta.url), sqlite=new DatabaseSync(':memory:');
for(const f of readdirSync('drizzle').filter(f=>f.endsWith('.sql')).sort())sqlite.exec(readFileSync(`drizzle/${f}`,'utf8'));
let batchTail=Promise.resolve();
const adapter={prepare(sql){const bound=args=>({
 async first(){return sqlite.prepare(sql).get(...args)},
 async all(){return {results:sqlite.prepare(sql).all(...args),success:true,meta:{}}},
 async raw(){const s=sqlite.prepare(sql);s.setReturnArrays(true);return s.all(...args)},
 async run(){return sqlite.prepare(sql).run(...args)},
 bind(...values){return bound(values)},
});return bound([])},batch(statements){const run=batchTail.catch(()=>{}).then(async()=>{sqlite.exec('BEGIN');try{const results=[];for(const s of statements)results.push(await s.all());sqlite.exec('COMMIT');return results;}catch(error){sqlite.exec('ROLLBACK');throw error;}});batchTail=run;return run;}};
const cache=new Map();let orm;
function load(file){file=resolve(file);if(cache.has(file))return cache.get(file);const exports={};cache.set(file,exports);
const js=ts.transpileModule(readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
const require=id=>id.endsWith('/db')?{getRawDb:()=>adapter,getDb:()=>orm}:id.startsWith('.')?load(resolve(dirname(file),id+'.ts')):nativeRequire(id);
vm.runInNewContext(js,{exports,require,crypto,TextEncoder,Uint8Array,Response,URL,Date,Object,console});return exports;}
orm=drizzle(adapter,{schema:load('db/schema.ts')});
const helpers=load('lib/server-session.ts');const original=helpers.createSessionCode;
// Force a collision in the simultaneous batch; the database must choose distinct codes.
let calls=0;helpers.createSessionCode=()=>++calls<=2?'SAMECODE':original();
const create=load('app/api/sessions/route.ts');
const results=await Promise.all(Array.from({length:24},(_,i)=>create.POST(new Request('https://test/api/sessions',{method:'POST',body:JSON.stringify({name:`Panel ${i}`,panelFamily:'ili-mb-e3'})}))));
assert(results.every(r=>r.status===201));const sessions=await Promise.all(results.map(r=>r.json()));assert.equal(new Set(sessions.map(s=>s.session.code)).size,24);
const events=load('app/api/sessions/[code]/events/route.ts'),feed=load('app/api/sessions/[code]/route.ts'),clear=load('app/api/sessions/[code]/clear/route.ts'),delivery=load('app/api/sessions/[code]/delivery/route.ts');
const ctx=code=>({params:Promise.resolve({code})});
const post=(url,body,token)=>new Request(url,{method:'POST',headers:{'x-publisher-token':token||''},body:JSON.stringify(body)});
const a=sessions[0],b=sessions[1];
const published=await Promise.all([a,b].map((s,i)=>events.POST(post('https://test/events',{events:[{message:`FIRE ALARM L01D001 Panel ${i}`} ]},s.publisherToken),ctx(s.session.code))));
assert(published.every(r=>r.status===201));
for(const [i,s] of [a,b].entries()){const data=await (await feed.GET(new Request('https://test/feed'),ctx(s.session.code))).json();assert.equal(data.events.length,1);assert(data.events[0].message.endsWith(`Panel ${i}`));assert.equal(data.counts.alarm,1);}
assert.equal((await events.POST(post('https://test/events',{events:[{message:'TROUBLE L01D099'}]},a.publisherToken),ctx(b.session.code))).status,403);
assert.equal((await clear.POST(post('https://test/clear',{},a.publisherToken),ctx(b.session.code))).status,403);
assert.equal((await clear.POST(post('https://test/clear',{},a.publisherToken),ctx(a.session.code))).status,200);
assert.equal((await (await feed.GET(new Request('https://test/feed'),ctx(b.session.code))).json()).events.length,1);
await delivery.POST(post('https://test/delivery',{role:'capture',probe:'probe-A'},a.publisherToken),ctx(a.session.code));
const wrongReceipt=await (await delivery.POST(post('https://test/delivery',{role:'companion',probe:'probe-A',clientId:'receiver-123456789',eventId:99999}),ctx(b.session.code))).json();assert.equal(wrongReceipt.delivered,false);
helpers.createSessionCode=()=> 'SAMECODE';assert.equal((await create.POST(post('https://test/create',{panelFamily:'ili-mb-e3'}))).status,503);
console.log('PASS: 24 concurrent sessions, forced collisions, unique codes, isolated events/counts, cross-session write/clear rejection, independent delivery receipts, bounded collision failure');
const manifest=load('app/sidekick.webmanifest/route.ts');
const installed=await manifest.GET(new Request('https://test/sidekick.webmanifest?session=ABCDEFGH')).json();
assert.equal(installed.name,'SideKick');assert.equal(installed.start_url,'/?mode=companion&session=ABCDEFGH');
assert.equal((await manifest.GET(new Request('https://test/sidekick.webmanifest')).json()).start_url,'/?mode=companion&pair=manual');
console.log('PASS: SideKick install identity and paired/manual launch URLs');

const untouched=sessions[2];
const health=async(s,probe)=> (await delivery.POST(post('https://test/delivery',{role:'capture',probe},s.publisherToken),ctx(s.session.code))).json();
assert.equal((await health(untouched,'new-probe')).phonePaired,false);
await health(a,'indicator-probe');
await delivery.POST(post('https://test/delivery',{role:'companion',probe:'indicator-probe',clientId:'indicator-phone-123',eventId:0}),ctx(a.session.code));
let indicator=await health(a,'indicator-probe');assert.equal(indicator.phonePaired,true);assert.equal(indicator.delivered,true);
sqlite.prepare('UPDATE delivery_receipts SET received_at=0 WHERE session_code=?').run(a.session.code);
indicator=await health(a,'indicator-probe');assert.equal(indicator.phonePaired,true);assert.equal(indicator.delivered,false);
console.log('PASS: phone status hidden before pairing, green after receipt, red when stale');

const paging=sessions[3];
sqlite.exec('BEGIN');
for(let i=0;i<5002;i++)sqlite.prepare('INSERT INTO serial_events(session_code,category,message,source) VALUES (?,?,?,?)').run(paging.session.code,'trouble','Report row '+i,'serial');
sqlite.exec('COMMIT');
const firstPage=(await (await feed.GET(new Request('https://test/feed?order=asc&since=0&limit=5000'),ctx(paging.session.code))).json()).events;
assert.equal(firstPage.length,5000);assert.equal(firstPage[0].message,'Report row 0');
const secondPage=(await (await feed.GET(new Request('https://test/feed?order=asc&since='+firstPage.at(-1).id+'&limit=5000'),ctx(paging.session.code))).json()).events;
assert.equal(secondPage.length,2);assert.equal(secondPage.at(-1).message,'Report row 5001');
console.log('PASS: complete reports paginate beyond 5,000 signals without gaps');
const recordedTime='2026-09-20T09:12:13.123-07:00';
const timestamped=await events.POST(post('https://test/events',{events:[{message:'TROUBLE L01D099 test laptop time',occurredAt:recordedTime}]},paging.publisherToken),ctx(paging.session.code));
assert.equal(timestamped.status,201);assert.equal((await timestamped.json()).events[0].occurredAt,recordedTime);
assert.equal(sqlite.prepare('SELECT COUNT(*) AS n FROM serial_events WHERE session_code=?').get(paging.session.code).n,5003);
console.log('PASS: publisher clock is stored unchanged and long sessions retain every signal');

const end=load('app/api/sessions/[code]/end/route.ts');
assert.equal((await end.POST(post('https://test/end',{},a.publisherToken),ctx(b.session.code))).status,403);
assert.equal((await end.POST(post('https://test/end',{}),ctx(b.session.code))).status,403);
assert.equal((await end.POST(post('https://test/end',{},b.publisherToken),ctx(b.session.code))).status,200);
assert.equal((await end.POST(post('https://test/end',{},b.publisherToken),ctx(b.session.code))).status,200);
const endedFeed=await (await feed.GET(new Request('https://test/feed'),ctx(b.session.code))).json();
assert.equal(endedFeed.session.isLive,false);assert.equal(endedFeed.events.length,1);
assert.equal((await events.POST(post('https://test/events',{events:[{message:'FIRE ALARM L01D002 after end'}]},b.publisherToken),ctx(b.session.code))).status,409);
assert.equal((await clear.POST(post('https://test/clear',{},b.publisherToken),ctx(b.session.code))).status,409);
assert.equal((await (await feed.GET(new Request('https://test/feed'),ctx(a.session.code))).json()).session.isLive,true);
console.log('PASS: end requires the publisher token, is idempotent, retains exportable events, blocks new logging and clearing, and leaves other sessions live');

const q=sessions[4];
async function signals(...messages){const r=await events.POST(post('https://test/events',{events:messages.map(message=>({message}))},q.publisherToken),ctx(q.session.code));assert.equal(r.status,201);return (await r.json()).counts;}
assert.deepEqual(await signals('FIRE ALARM L01D001','TROUBLE L01D001','SUPERVISORY L01M002','DISABLED L01M003'),{alarm:1,trouble:1,supervisory:1,other:1});
assert.deepEqual(await signals('FIRE ALARM RESTORED L01D001','TROUBLE RESTORED L01D001'),{alarm:1,trouble:0,supervisory:1,other:1});
assert.deepEqual(await signals('SUPERVISORY RESTORED L01M002','ENABLED L01M003'),{alarm:1,trouble:0,supervisory:0,other:0});
assert.deepEqual(await signals('TROUBLE L01D004','TROUBLE L01D004','DISABLED L01M005','ALARM ACKNOWLEDGED L01D099','SYSTEM RESET FAILED'),{alarm:1,trouble:1,supervisory:0,other:1});
assert.deepEqual(await signals('SYSTEM NORMAL'),{alarm:1,trouble:1,supervisory:0,other:1});
await clear.POST(post('https://test/clear',{},q.publisherToken),ctx(q.session.code));
assert.equal((await (await feed.GET(new Request('https://test/feed'),ctx(q.session.code))).json()).counts.alarm,1);
assert.deepEqual(await signals('RESET COMPLETE'),{alarm:0,trouble:1,supervisory:0,other:1});
assert.deepEqual(await signals('TROUBLE RESTORED L01D004','RE-ENABLED L01M005'),{alarm:0,trouble:0,supervisory:0,other:0});
const manual=await events.POST(post('https://test/events',{events:[{message:'FIRE ALARM L01D999',source:'manual'}]},q.publisherToken),ctx(q.session.code));assert.equal((await manual.json()).counts.alarm,0);
console.log('PASS: category isolation, alarm latching, tracking restorals, re-enable, duplicate suppression, reset failure, reset preserves trouble/disabled, history clear preserves queues, manual samples excluded');

const notifier=sessions[5];
sqlite.prepare('UPDATE monitor_sessions SET panel_family=? WHERE code=?').run('notifier-nfs2-3030',notifier.session.code);
const actual3030=JSON.parse(readFileSync('tests/fixtures/notifier-3030-nine-troubles.json','utf8'));
// Mimic serial packets split between the header and device-detail lines.
for(const row of actual3030){const response=await events.POST(post('https://test/events',{events:[row]},notifier.publisherToken),ctx(notifier.session.code));assert.equal(response.status,201);}
const notifierFeed=async()=> (await (await feed.GET(new Request('https://test/feed'),ctx(notifier.session.code))).json());
assert.deepEqual((await notifierFeed()).counts,{alarm:0,supervisory:0,trouble:9,other:0});
await events.POST(post('https://test/events',{events:[{message:'CLEARED TROUBLE                          Waterflow'},{message:'Zone Z001            Z001   ALARM TRACK  06:10:00A TUE SEP 22, 2026     L01M001'}]},notifier.publisherToken),ctx(notifier.session.code));
assert.deepEqual((await notifierFeed()).counts,{alarm:0,supervisory:0,trouble:8,other:0});
await events.POST(post('https://test/events',{events:[{message:'FIRE ALARM                              Waterflow'},{message:'Zone Z001            Z001   ALARM TRACK  06:11:00A TUE SEP 22, 2026     L01M001'}]},notifier.publisherToken),ctx(notifier.session.code));
assert.equal((await notifierFeed()).counts.alarm,1);
await events.POST(post('https://test/events',{events:[{message:'CLEARED ALARM                           Waterflow'},{message:'Zone Z001            Z001   ALARM TRACK  06:12:00A TUE SEP 22, 2026     L01M001'}]},notifier.publisherToken),ctx(notifier.session.code));
assert.equal((await notifierFeed()).counts.alarm,1);
await events.POST(post('https://test/events',{events:[{message:'SYSTEM RESET'}]},notifier.publisherToken),ctx(notifier.session.code));
assert.deepEqual((await notifierFeed()).counts,{alarm:0,supervisory:0,trouble:8,other:0});
console.log('PASS: actual NFS2-3030 two-line capture = 0 alarms, 0 supervisory, 9 troubles; split packets, addressed restoral, real alarm latch and reset');

const {NotifierQueue}=load('lib/notifier-queue.ts');
const restored3030=JSON.parse(readFileSync('tests/fixtures/notifier-3030-restored.json','utf8'));
const replay=new NotifierQueue();
for(const row of restored3030)replay.push(row);
assert.equal(JSON.stringify(replay.counts()),JSON.stringify({alarm:0,supervisory:0,trouble:0,other:0}));
const ackQueue=new NotifierQueue();
for(const row of actual3030)ackQueue.push(row);
for(const row of restored3030.filter(row=>row.message.startsWith('ACKED')))ackQueue.push(row);
assert.equal(ackQueue.counts().trouble,9,'Acknowledgements neither add nor clear troubles');
const ackOnly=new NotifierQueue();
ackOnly.push({message:'ACKED TROUBLE                            SYSTEM INITIALIZATION',source:'serial'});
assert.equal(ackOnly.counts().trouble,0,'Acknowledgement alone cannot create a condition');
console.log('PASS: full actual NFS2-3030 activation/acknowledgement/restoral sequence returns every queue to zero; incomplete acknowledgement headers do not add or clear a condition');

const {notifierEventCategory}=load('lib/notifier-event-category.ts');
const trackDetail='Zone Z001            Z001   TRACK SUPERV 06:52:48A TUE SEP 22, 2026     L01M002';
assert.equal(notifierEventCategory(trackDetail,'SUPERVISORY Tamper Switch'),'supervisory');
assert.equal(notifierEventCategory(trackDetail,'TROUBLE NO ANSWER Tamper Switch'),'trouble');
assert.equal(notifierEventCategory(trackDetail,'CLEARED SUPERVISORY Tamper Switch'),'supervisory');
assert.equal(notifierEventCategory(trackDetail),'other','Device type alone is not an active supervisory');
const trackQueue=new NotifierQueue();
const pushTrack=header=>{trackQueue.push({message:header,source:'serial'});trackQueue.push({message:trackDetail,source:'serial'});};
pushTrack('SUPERVISORY Tamper Switch');assert.equal(trackQueue.counts().supervisory,1);
pushTrack('TROUBLE NO ANSWER Tamper Switch');assert.equal(trackQueue.counts().supervisory,0);assert.equal(trackQueue.counts().trouble,1);
pushTrack('CLEARED TROUBLE Tamper Switch');assert.equal(trackQueue.counts().supervisory,1);assert.equal(trackQueue.counts().trouble,0);
pushTrack('CLEARED SUPERVISORY Tamper Switch');assert.equal(trackQueue.counts().supervisory,0);
console.log('PASS: TRACK SUPERV inherits supervisory/trouble category, trouble takes display priority, tracking restorals clear only their matching condition');

const profilesApi=load('app/api/panel-profiles/route.ts');
sqlite.prepare('INSERT INTO panel_profiles(id,name,baud_rate,data_bits,parity,stop_bits,flow_mode,revision,verified,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?)').run('notifier-nfs2-3030','Test profile','9600','8','none','1','enqstx',1,1,new Date().toISOString());
const legacyProfile=(await (await profilesApi.GET()).json()).profiles.find(p=>p.id==='notifier-nfs2-3030');
assert.equal(legacyProfile.flowMode,'none');assert.equal(legacyProfile.verified,false);
const profileValidation=load('lib/panel-profiles.ts');
assert.equal(profileValidation.validProfile({...legacyProfile,flowMode:'enqstx'}),false);
assert.equal(profileValidation.validProfile({...legacyProfile,flowMode:'xonxoff'}),false);
sqlite.prepare("UPDATE panel_profiles SET flow_mode='xonxoff', verified=1 WHERE id='notifier-nfs2-3030'").run();
const retiredFlow=(await (await profilesApi.GET()).json()).profiles.find(p=>p.id==='notifier-nfs2-3030');
assert.equal(retiredFlow.flowMode,'none');assert.equal(retiredFlow.verified,false);
assert.equal(profileValidation.validProfile({...retiredFlow,flowMode:'none'}),true);
console.log('PASS: retired ENQ/STX profiles load as unverified None; new ENQ/STX settings rejected; retired software flow-control settings rejected');

const n16Capture=JSON.parse(readFileSync('tests/fixtures/notifier-n16-restored.json','utf8'));
const n16=sessions[6];
sqlite.prepare('UPDATE monitor_sessions SET panel_family=? WHERE code=?').run('notifier-n16',n16.session.code);
let lastN16;
for(const row of n16Capture){
 const response=await events.POST(post('https://test/events',{events:[row]},n16.publisherToken),ctx(n16.session.code));
 assert.equal(response.status,201);lastN16=await response.json();
 assert.equal(lastN16.counts.supervisory,0,'Trouble-only N16 stream must never create a supervisory');
 if(row.message.includes('Track Superv'))assert.equal(lastN16.events[0].category,'trouble');
}
assert.deepEqual(lastN16.counts,{alarm:0,supervisory:0,trouble:0,other:0});
const n16Feed=await (await feed.GET(new Request('https://test/feed'),ctx(n16.session.code))).json();
assert.deepEqual(n16Feed.counts,{alarm:0,supervisory:0,trouble:0,other:0});
assert(n16Feed.events.filter(e=>e.message.includes('Track Superv')).every(e=>e.category==='trouble'));
const n16TrueSuperv=new NotifierQueue();
for(const message of ['SUPERVISORY OPEN ME AT ONCE','1st Floor Z1 Track Superv 06:17:48A TUE SEP 22 2026 N1L1M3'])n16TrueSuperv.push({message,source:'serial'});
assert.equal(n16TrueSuperv.counts().supervisory,1);
for(const message of ['CLR SUPERVISORY OPEN ME AT ONCE','1st Floor Z1 Track Superv 06:18:08A TUE SEP 22 2026 N1L1M3'])n16TrueSuperv.push({message,source:'serial'});
assert.equal(n16TrueSuperv.counts().supervisory,0);
console.log('PASS: actual N16 trouble/restoral sequence stays free of false supervisory events and finishes at zero; CLR and node/zone/system addresses; true supervisory activation/restoral preserved');

const activeOnly=[
 'ACTIVE TROUBLE SPECIAL ZONE N1ZF1',
 'CLR ACTIVE TROUBLE SPECIAL ZONE N1ZF1',
 'ACTIVE SUPERVISORY MONITOR N1ZF12',
 'ACTIVE',
 'Special Zone 06:19:52A TUE SEP 22 2026 N1ZF12',
 'CLR ACTIVE',
 'Special Zone 06:19:56A TUE SEP 22 2026 N1ZF12',
];
for(const message of activeOnly){const r=await events.POST(post('https://test/events',{events:[{message}]},n16.publisherToken),ctx(n16.session.code));assert.equal(r.status,201);const data=await r.json();assert.deepEqual(data.counts,{alarm:0,supervisory:0,trouble:0,other:0});assert.equal(data.events[0].message,message);assert.equal(data.events[0].category,'other');}
const activeHistory=await (await feed.GET(new Request('https://test/feed'),ctx(n16.session.code))).json();
for(const message of activeOnly)assert(activeHistory.events.some(e=>e.message===message));
const keepTrouble=new NotifierQueue(true);
keepTrouble.push({message:'TROUBLE L01M003',source:'serial'});
keepTrouble.push({message:'CLR ACTIVE TROUBLE L01M003',source:'serial'});
assert.equal(keepTrouble.counts().trouble,1,'CLR ACTIVE must not restore a real trouble');
console.log('PASS: N16 ACTIVE/CLR ACTIVE retained in feed and report history, categorized Other, excluded from all queues without clearing real troubles');

const specialQueue=new NotifierQueue(true);
specialQueue.push({message:'TROUBLE',source:'serial'});
assert.equal(specialQueue.counts().trouble,0,'Do not count an unidentified header before its detail arrives');
specialQueue.push({message:'Special Zone 06:19:52A TUE SEP 22 2026 N1ZF1',source:'serial'});
assert.equal(specialQueue.counts().trouble,0);
for(const message of ['TROUBLE Special Zone N1ZF2','SUPERVISORY Special Zone N1ZF3','FIRE ALARM N1ZF4','DISABLED Special Zone N1ZF5','CLR TROUBLE Special Zone N1ZF2'])specialQueue.push({message,source:'serial'});
assert.equal(JSON.stringify(specialQueue.counts()),JSON.stringify({alarm:0,supervisory:0,trouble:0,other:0}));
const specialMessages=['TROUBLE','Special Zone 06:19:52A TUE SEP 22 2026 N1ZF1','CLR TROUBLE','Special Zone 06:19:53A TUE SEP 22 2026 N1ZF1'];
for(const message of specialMessages){const r=await events.POST(post('https://test/events',{events:[{message}]},n16.publisherToken),ctx(n16.session.code));const data=await r.json();assert.equal(r.status,201);assert.deepEqual(data.counts,{alarm:0,supervisory:0,trouble:0,other:0});assert.equal(data.events[0].message,message);}
const specialHistory=await (await feed.GET(new Request('https://test/feed'),ctx(n16.session.code))).json();
for(const message of specialMessages)assert(specialHistory.events.some(e=>e.message===message));
console.log('PASS: Special Zone transitions retained in history and excluded from all queues, including split header/detail packets');

// The first 12 records of the captured N16 fixture contain four device
// troubles plus a General Zone summary and a Special Zone activation.
const fourDeviceCapture=n16Capture.slice(0,12);
const fourDevices=new NotifierQueue(true);
for(const record of fourDeviceCapture)fourDevices.push(record);
assert.deepEqual(JSON.parse(JSON.stringify(fourDevices.counts())),{alarm:0,supervisory:0,trouble:4,other:0});
assert.deepEqual([...fourDevices.active.keys()].sort(),['trouble:N1L1D1','trouble:N1L1M1','trouble:N1L1M2','trouble:N1L1M3'].sort());
const countedN16=sessions[7];
sqlite.prepare('UPDATE monitor_sessions SET panel_family=? WHERE code=?').run('notifier-n16',countedN16.session.code);
const fourResponse=await events.POST(post('https://test/events',{events:fourDeviceCapture},countedN16.publisherToken),ctx(countedN16.session.code));
assert.equal(fourResponse.status,201);assert.equal((await fourResponse.json()).counts.trouble,4);
const countedFeed=await (await feed.GET(new Request('https://test/feed'),ctx(countedN16.session.code))).json();
assert.equal(countedFeed.counts.trouble,4);assert.equal(countedFeed.events.length,12);
assert(countedFeed.events.some(e=>e.message.startsWith('General Zone')));
for(const message of ['TROUBLE Node 1 - N16','SYSTEM INITIALIZATION System 06:18:09A TUE SEP 22 2026 N1T448'])fourDevices.push({message,source:'serial'});
assert.equal(fourDevices.counts().trouble,5,'Genuine system trouble still counts');
for(const message of ['CLR TROUBLE Node 1 - N16','SYSTEM INITIALIZATION System 06:19:53A TUE SEP 22 2026 N1T448'])fourDevices.push({message,source:'serial'});
assert.equal(fourDevices.counts().trouble,4);
console.log('PASS: N16 four device troubles count as four, General Zone stays logged without double-counting, real system trouble still counts and restores');

// Capture can begin with acknowledgements of conditions already on the panel.
const liveAckRows=JSON.parse(readFileSync('tests/fixtures/notifier-3030-acknowledged-five-troubles.json','utf8'));
const lateJoin=new NotifierQueue();
for(const row of liveAckRows)lateJoin.push(row);
assert.equal(lateJoin.counts().trouble,5,'Five typed ACKED TROUBLE records establish five existing system troubles');
for(const row of liveAckRows)lateJoin.push(row);
assert.equal(lateJoin.counts().trouble,5,'Replayed acknowledgements and reset do not duplicate or clear active troubles');
lateJoin.push({message:'CLEARED TROUBLE NCM COMM FAILURE',source:'serial'});
lateJoin.push({message:'Homie 12:12:29A THU JAN 01, 2015',source:'serial'});
assert.equal(lateJoin.counts().trouble,4,'Restoral removes the acknowledged system condition');
const acknowledgedDevice=new NotifierQueue();
const detail='Zone Z001 Z001 SMOKE(PHOTO) 12:12:29A THU JAN 01, 2015 L01D001';
for(const header of ['TROUBLE NO ANSWER Smoke','ACKED TROUBLE NO ANSWER Smoke','ACKED TROUBLE NO ANSWER Smoke']){acknowledgedDevice.push({message:header,source:'serial'});acknowledgedDevice.push({message:detail,source:'serial'});}
assert.equal(acknowledgedDevice.counts().trouble,1,'Device acknowledgements reuse the address key');
acknowledgedDevice.push({message:'CLEARED TROUBLE NO ANSWER Smoke',source:'serial'});acknowledgedDevice.push({message:detail,source:'serial'});
assert.equal(acknowledgedDevice.counts().trouble,0);
console.log('PASS: live five-trouble late-join replay, repeated acknowledgements, reset persistence, system/device restorals and deduplication');

const screenLines=['****SCREEN PRINT****','ACKNOWLEDGED TROUBLE','NCM COMM FAILURE','Homie','12:33:41A THU JAN 01, 2015','============= EVENT COUNTS =============','FIRE ALARMS:000 PREALARM:000 TROUBLE:005','SUPERVISORY:000 SECURITY:000 OTHER:000'];
const screenQueue=new NotifierQueue();
const addScreen=message=>screenQueue.push({message,source:'serial'});
for(const line of screenLines)addScreen(line);
assert.equal(screenQueue.counts().supervisory,0);assert.equal(screenQueue.counts().trouble,5);
for(const line of screenLines)addScreen(line);
assert.equal(screenQueue.counts().trouble,5,'Repeated screen print does not add a trouble');
const clonedScreen=screenQueue.clone();assert.equal(clonedScreen.counts().trouble,5);
for(const message of ['ACKED TROUBLE NO POWER SUPPLY INST','Homie 12:33:41A THU JAN 01, 2015'])addScreen(message);
assert.equal(screenQueue.counts().trouble,5,'Acknowledgement identifies an existing snapshot condition');
for(const message of ['CLEARED TROUBLE NO POWER SUPPLY INST','Homie 12:33:41A THU JAN 01, 2015'])addScreen(message);
assert.equal(screenQueue.counts().trouble,4);
for(let i=0;i<2;i++)for(const message of ['CLEARED TROUBLE BUZZER OFF-LINE','Homie 12:33:41A THU JAN 01, 2015'])addScreen(message);
assert.equal(screenQueue.counts().trouble,3,'Previously unseen restoral consumes one unknown snapshot condition only once');
for(const message of ['TROUBLE NEW CONDITION L01D099','Homie 12:33:41A THU JAN 01, 2015'])addScreen(message);
assert.equal(screenQueue.counts().trouble,4,'A new condition advances the snapshot');
addScreen('SYSTEM RESET');assert.equal(screenQueue.counts().trouble,4);
addScreen('FIRE ALARMS:000 PREALARM:000 TROUBLE:000');assert.equal(screenQueue.counts().trouble,0);
const {classifySerialMessage,deriveQueueMutation}=load('lib/panelstream.ts');
for(const message of screenLines.slice(-2)){assert.equal(classifySerialMessage(message),'other');assert.equal(deriveQueueMutation(message,'supervisory'),null);}
const summarySession=sessions[8];
sqlite.prepare('UPDATE monitor_sessions SET panel_family=? WHERE code=?').run('notifier-nfs2-3030',summarySession.session.code);
for(const message of screenLines){const response=await events.POST(post('https://test/events',{events:[{message,source:'serial'}]},summarySession.publisherToken),ctx(summarySession.session.code));assert.equal(response.status,201);}
const summaryFeed=await (await feed.GET(new Request('https://test/feed'),ctx(summarySession.session.code))).json();
assert.deepEqual(summaryFeed.counts,{alarm:0,supervisory:0,trouble:5,other:0});
console.log('PASS: exact screenshot replay = 0 supervisory / 5 troubles; repeated snapshots, cloned cache, ACK reconciliation, known/unknown restorals, new trouble, zero summary and API feed');
const listQueue=new NotifierQueue();
const printList=['======= TROUBLE: 0001 OF 0005 ========','2 TBL NO POWER SUPPLY INST','3 TBL BUZZER OFF-LINE','4 TBL NVRAM BATTERY TROUBLE','5 TBL LOOP 1-2 COMM FAILURE','================'];
for(const message of printList){listQueue.push({message,source:'serial'});assert.equal(deriveQueueMutation(message,classifySerialMessage(message)),null);}
assert.equal(listQueue.counts().trouble,0);
for(const message of printList.slice(1,5))assert.equal(classifySerialMessage(message),'trouble');
for(const separator of [':','=']) {
 const message=`ALARM${separator}0000 SUPERVISORY${separator}0000 TROUBLE${separator}0005`;
 assert.equal(classifySerialMessage(message),'other');assert.equal(notifierEventCategory(message),'other');
 listQueue.push({message,source:'serial'});
 assert.equal(listQueue.counts().alarm,0);assert.equal(listQueue.counts().supervisory,0);assert.equal(listQueue.counts().trouble,5);
 for(const message of printList)listQueue.push({message,source:'serial'});
 assert.equal(listQueue.counts().trouble,5);
}
console.log('PASS: numbered print-list troubles do not mutate queues; short ALARM zero snapshots report 0/0/5 without duplicate counts');
const n640Active='TROUBL IN SYSTEM Sys Initialization 09:20A 092526 Fri';
const n640Clear='CLR TB IN SYSTEM Sys Initialization 10:21P 092626 Sat';
for(const message of [n640Active,n640Clear])assert.equal(classifySerialMessage(message),'trouble');
assert.equal(deriveQueueMutation(n640Active,'trouble').action,'activate');
assert.equal(deriveQueueMutation(n640Clear,'trouble').action,'clear');
assert.equal(deriveQueueMutation(n640Active,'trouble').pointKey,deriveQueueMutation(n640Clear,'trouble').pointKey);
sqlite.prepare('UPDATE monitor_sessions SET panel_family=? WHERE code=?').run('notifier-nfs2-640',q.session.code);
assert.equal((await signals(n640Active)).trouble,1);
assert.equal((await signals('ACKNOWLEDGE 09:20A 092526 Fri')).trouble,1);
assert.equal((await signals(n640Clear)).trouble,0);
assert.equal((await signals(n640Clear)).trouble,0);
console.log('PASS: NFS2-640 abbreviated system troubles and restorals classify correctly, matching across timestamp changes; API queue goes 1 -> 0');
const strobeClear='CLR TB STROBE CKT RPS 1,2 AND 3 TRIP BLDGS A, E OPEN 09:29A 092526 B01';
const strobeActive=strobeClear.replace('CLR TB','TROUBL').replace('09:29A 092526','08:15P 092426');
for(const message of [strobeActive,strobeClear])assert.equal(classifySerialMessage(message),'trouble');
assert.equal(deriveQueueMutation(strobeClear,'trouble').action,'clear');
assert.equal(deriveQueueMutation(strobeActive,'trouble').pointKey,deriveQueueMutation(strobeClear,'trouble').pointKey);
assert.equal((await signals(strobeActive)).trouble,1);
assert.equal((await signals(strobeClear)).trouble,0);
assert.equal((await signals('TAMALPAIS VALLEY ELEMENTARY SYSTEM NORMAL 09:29A 092526 Fri')).other,0);
console.log('PASS: NFS2-640 strobe trouble/restoral shares B01 identity; restoral removes trouble and System Normal adds no Other');
const disabledMonitor='DISABL TROUBLE_MON RPS-3 TROUBLE RM 25/BLDG E DISABL 09:35A 092526 1M010';
assert.equal(classifySerialMessage(disabledMonitor),'other');
assert.equal(deriveQueueMutation(disabledMonitor,'other').action,'activate');
const disabledCounts=await signals(disabledMonitor);
assert.equal(disabledCounts.other,1);assert.equal(disabledCounts.trouble,0);
assert.equal((await signals(disabledMonitor)).other,1);
console.log('PASS: NFS2-640 DISABL TROUBLE_MON counts once in Other and never in Trouble');
const zoneDisable='DISABL SOFTWARE ZONE Silenceable:NO 10:21A 092526 Z50';
const moduleDisable='DISABL RELAY AC SHUTDOWN BUILDING A1 DISABL 10:21A 092526 1M011';
const moduleEnable='CLR TB RELAY AC SHUTDOWN BUILDING A1 DISABL 10:22A 092526 1M011';
assert.equal(classifySerialMessage(moduleEnable),'other');
assert.equal(deriveQueueMutation(moduleEnable,'other').action,'clear');
assert.equal(deriveQueueMutation(moduleEnable,'other').pointKey,'1M011');
assert.equal(deriveQueueMutation(moduleDisable,'other').pointKey,'1M011');
const baselineOther=(await signals('STATUS CHANGE 1=DIS/ENA POINT')).other;
assert.equal((await signals(zoneDisable,moduleDisable)).other,baselineOther+2);
assert.equal((await signals('ENABLE SOFTWARE ZONE Silenceable:NO 10:22A 092526 Z50')).other,baselineOther+1);
assert.equal((await signals(moduleEnable)).other,baselineOther);
assert.equal((await signals(moduleEnable)).other,baselineOther);
assert.equal(classifySerialMessage('CLR TB RELAY AC SHUTDOWN BUILDING A1 OPEN 10:22A 092526 1M011'),'trouble');
assert.equal(classifySerialMessage(moduleEnable.replace('092526','92526')),'other');
console.log('PASS: Z50 plus 1M011 disabled count +2; separate enable/restoral returns Other to baseline without clearing unrelated points; ordinary CLR TB remains Trouble');
const nacDescriptions=['STROBE CKT RPS 1,2 AND 3 TRIP BLDGS A, E','STROBE CKT RPS 4 TRIP BUILDING K','STROBE CKT RPS 5 TRIP BUILDING D','STROBE CKT SPARE'];
const nacRestorals=nacDescriptions.map((label,i)=>`CLR TB ${label} DISABL 10:31A 092526 B0${i+1}`);
const nacBaseline=(await signals('STATUS CHANGE 1=DIS/ENA POINT')).other;
await signals('DISABL SOFTWARE ZONE Silenceable:NO 10:30A 092526 Z99');
assert.equal((await signals(...nacRestorals.map(m=>m.replace('CLR TB','DISABL')))).other,nacBaseline+5);
assert.equal((await signals('ENABLE SOFTWARE ZONE Silenceable:NO 10:31A 092526 Z99')).other,nacBaseline+4);
for(const [i,message] of nacRestorals.entries()){
 assert.equal(classifySerialMessage(message),'other');
 assert.equal((await signals(message)).other,nacBaseline+3-i);
}
assert.equal((await signals(...nacRestorals)).other,nacBaseline);
assert.equal(classifySerialMessage(nacRestorals[0].replace('DISABL','OPEN')),'trouble');
console.log('PASS: Z99 and B01-B04 disable/enable sequence counts 5 -> 4 -> 3 -> 2 -> 1 -> baseline; duplicate restorals do not decrement unrelated Other points');

// Lost acknowledgements must not duplicate saved events or repeat queue mutations.
const resilient=sessions[20];
const batch={batchId:'retry-batch-123456789',events:[{message:'TROUBLE L01D321 Durable capture',occurredAt:'2026-09-26T06:00:00.000-07:00'}]};
assert.equal((await events.POST(post('https://test/events',batch,resilient.publisherToken),ctx(resilient.session.code))).status,201);
assert.equal((await events.POST(post('https://test/events',batch,resilient.publisherToken),ctx(resilient.session.code))).status,200);
const resilientFeed=await (await feed.GET(new Request('https://test/feed'),ctx(resilient.session.code))).json();
assert.equal(resilientFeed.events.length,1);assert.equal(resilientFeed.counts.trouble,1);
assert.equal(resilientFeed.events[0].occurredAt,batch.events[0].occurredAt);
assert.equal((await events.POST(post('https://test/events',{...batch,events:[{message:'different'}]},resilient.publisherToken),ctx(resilient.session.code))).status,409);
assert.equal((await events.POST(post('https://test/events',{events:Array.from({length:101},()=>({message:'TROUBLE oversize'}))},resilient.publisherToken),ctx(resilient.session.code))).status,400);
sqlite.exec("CREATE TRIGGER simulate_capture_failure BEFORE INSERT ON serial_events WHEN NEW.message='TROUBLE force atomic rollback' BEGIN SELECT RAISE(ABORT,'simulated disk failure'); END;");
const rollback={batchId:'rollback-batch-123456',events:[{message:'TROUBLE L01D322 before failure'},{message:'TROUBLE force atomic rollback'}]};
assert.equal((await events.POST(post('https://test/events',rollback,resilient.publisherToken),ctx(resilient.session.code))).status,500);
assert.equal(sqlite.prepare('SELECT COUNT(*) AS n FROM capture_batches WHERE id=?').get(resilient.session.code+':'+rollback.batchId).n,0);
assert.equal(sqlite.prepare('SELECT COUNT(*) AS n FROM serial_events WHERE session_code=?').get(resilient.session.code).n,1);
sqlite.exec('DROP TRIGGER simulate_capture_failure');
assert.equal((await events.POST(post('https://test/events',rollback,resilient.publisherToken),ctx(resilient.session.code))).status,201);
console.log('PASS: durable batch retry, unchanged timestamps, conflict rejection, oversize rejection, atomic rollback and recovery');

const provenance=sessions[21];sqlite.prepare('UPDATE monitor_sessions SET panel_family=? WHERE code=?').run('notifier-n16',provenance.session.code);
await events.POST(post('https://test/events',{events:[{message:'ALARM:0000 SUPERVISORY:0000 TROUBLE:0005'}]},provenance.publisherToken),ctx(provenance.session.code));
const sourceFeed=await (await feed.GET(new Request('https://test/feed'),ctx(provenance.session.code))).json();
assert.deepEqual(sourceFeed.queueSources.sort(),['alarm','supervisory','trouble']);assert.equal(sourceFeed.counts.trouble,5);
await delivery.POST(post('https://test/delivery',{role:'capture',probe:'health-detail',panelConnected:true,lastPanelAt:'2026-09-26T13:00:00.000Z',pendingUploads:7},provenance.publisherToken),ctx(provenance.session.code));
const phoneHealth=await (await delivery.POST(post('https://test/delivery',{role:'companion',probe:'health-detail',clientId:'health-phone-123456',eventId:999999}),ctx(provenance.session.code))).json();
assert.equal(phoneHealth.captureStatus.panelConnected,true);assert.equal(phoneHealth.captureStatus.pendingUploads,7);
console.log('PASS: panel count provenance and remote laptop capture status');
