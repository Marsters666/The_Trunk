import {readFileSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {createRequire} from 'node:module';
import vm from 'node:vm';
import ts from 'typescript';
import assert from 'node:assert/strict';
const native=createRequire(import.meta.url);
function load(file){const exports={};const require=id=>id.startsWith('@/')?load(resolve(id.slice(2)+'.ts')):id.startsWith('.')?load(resolve(dirname(file),id+'.ts')):native(id);const js=ts.transpileModule(readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;vm.runInNewContext(js,{exports,require,File,Blob,Date,console,URL,Uint8Array,ArrayBuffer});return exports;}
const {createSignalExport,selectReportEvents}=load(resolve('lib/signal-export.ts'));
const events=[['alarm','2026-09-20 16:00:00'],['trouble','2026-09-20T16:00:30Z'],['supervisory','2026-09-20T16:00:30Z'],['alarm','2026-09-20T16:01:00Z']].map(([category,occurredAt],i)=>({id:i+1,category,occurredAt,message:'Test signal '+i,source:'serial'}));
const base={events,filter:'all',reportName:'Building One Test',sessionName:'Panel One',sessionCode:'ABCDEFGH',panelLabel:'Gamewell FCI E3',categories:['alarm','trouble'],from:'2026-09-20T09:00',to:'2026-09-20T09:00'};
assert.deepEqual(Array.from(selectReportEvents(base),r=>r.id),[1,2]);
const excel=await createSignalExport({...base,format:'xlsx'});assert.equal(excel.name,'Building-One-Test.xlsx');
const XLSX=native('xlsx');const workbook=XLSX.read(await excel.arrayBuffer(),{type:'array'});assert.equal(XLSX.utils.sheet_to_json(workbook.Sheets.Signals).length,2);
const pdf=await createSignalExport({...base,format:'pdf'});assert.equal(pdf.name,'Building-One-Test.pdf');assert((await pdf.text()).startsWith('%PDF-'));
assert.equal(selectReportEvents({...base,from:'',to:''}).length,3);
console.log('PASS: Excel/PDF generation, chosen filename, multiple types, UTC/local boundaries, inclusive end minute, unlimited range');
