import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import ts from 'typescript';
async function load(path){const code=ts.transpileModule(readFileSync(path,'utf8'),{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText;return import('data:text/javascript;base64,'+Buffer.from(code).toString('base64'));}
const {SerialReuse}=await load('lib/serial-reuse.ts');
const {SerialCleanup}=await load('lib/serial-cleanup.ts');
class Adapter {
 opens=0;closes=0;flushes=0;stream=null;controller=null;online=false;
 async open(){if(this.opens)throw new Error('Driver refuses reopen until USB reconnect');this.opens++;this.online=true;}
 get readable(){if(!this.online)return null;return this.stream??=new ReadableStream({start:c=>{this.controller=c;},cancel:()=>{this.flushes++;this.stream=null;}});}
 send(text){this.readable;this.controller.enqueue(new TextEncoder().encode(text));}
 async close(){if(this.stream?.locked)throw new Error('Locked');this.online=false;this.closes++;}
}
const adapter=new Adapter();const reuse=new SerialReuse();await adapter.open();
for(let session=0;session<5;session++) {
 if(session){assert.equal(await reuse.take(adapter,'9600,8,1,none'),true);}
 const cleanup=new SerialCleanup();cleanup.reader=adapter.readable.getReader();
 adapter.send(`session-${session}`);
 assert.equal(new TextDecoder().decode((await cleanup.reader.read()).value),`session-${session}`,'Only current-session bytes enter report');
 const pending=cleanup.reader.read();const stopped=cleanup.releaseStreams();assert.equal((await pending).done,true);await stopped;
 reuse.retain(adapter,'9600,8,1,none');
 adapter.send('BETWEEN SESSIONS — MUST BE DISCARDED');
}
assert.equal(adapter.opens,1);assert.equal(adapter.closes,0);
await reuse.release();assert.equal(adapter.closes,1);
const different=new Adapter();await different.open();reuse.retain(different,'9600');
assert.equal(await reuse.take(different,'19200'),false);assert.equal(different.closes,1);
const old=new Adapter();await old.open();reuse.retain(old,'9600');
assert.equal(await reuse.take(new Adapter(),'9600'),false);assert.equal(old.closes,1);
let tries=0;reuse.retain({readable:null,async close(){if(++tries===1)throw new Error('busy');}},'x');
await assert.rejects(reuse.release(),/busy/);await reuse.release();assert.equal(tries,2);
console.log('PASS: five sessions on one OS handle with a reopen-failing adapter; inactive bytes flushed; settings/port changes close old handle; explicit release and failure retry');
