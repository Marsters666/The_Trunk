import assert from 'node:assert/strict';
import vm from 'node:vm';
import ts from 'typescript';
import {readFileSync} from 'node:fs';
const source=readFileSync('app/panelstream-dashboard.tsx','utf8');
const start=source.indexOf('  const flushCapture = useCallback');
const fragment=source.slice(start,source.indexOf('  useEffect(()=>{',start))+'\nglobalThis.flush=flushCapture;';
const batches=[{id:1,batchId:'first-batch',code:'ABCDEFGH',events:[{message:'one'}]},{id:2,batchId:'second-batch',code:'ABCDEFGH',events:[{message:'two'}]}];
const sent=[];let fail=true,invalid=true,removed=0,loaded=0;
const ctx={session:{code:'ABCDEFGH'},publisherToken:'publisher',mode:'capture',useCallback:fn=>fn,flushRef:{current:null},feedGenerationRef:{current:1},lastIdRef:{current:0},publishFailedRef:{current:false},navigator:{onLine:false},AbortSignal,
 pendingCapture:async()=>structuredClone(batches),removeCapture:async id=>{assert.equal(batches[0].id,id);batches.shift();removed++;},
 setPendingUploads(){},setUploadIssue(){},setDeliveryConfirmed(){},setLastSyncAt(){},loadSession:async()=>{loaded++;},
 fetch:async(_url,options)=>{const body=JSON.parse(options.body);sent.push(body.batchId);if(fail){fail=false;throw Error('Response lost after server saved data');}return {ok:true,json:async()=>invalid?(invalid=false,{}):{accepted:true,batchId:body.batchId}};},
};
vm.createContext(ctx);vm.runInContext(ts.transpileModule(fragment,{compilerOptions:{target:ts.ScriptTarget.ES2022}}).outputText,ctx);
await ctx.flush();assert.equal(sent.length,0);assert.equal(batches.length,2);
ctx.navigator.onLine=true;await ctx.flush();assert.equal(batches.length,2,'Network failure must retain local capture');
await ctx.flush();assert.equal(batches.length,2,'Malformed acknowledgement must retain local capture');
await ctx.flush();assert.equal(batches.length,0);assert.equal(removed,2);assert.equal(loaded,2);assert.deepEqual(sent,['first-batch','first-batch','first-batch','second-batch']);
assert.equal(ctx.publishFailedRef.current,false);
console.log('PASS: offline capture retained, lost response retried with same ID, malformed acknowledgement rejected, batches drain in order');
