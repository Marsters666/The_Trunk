import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import ts from 'typescript';
const source=ts.transpileModule(readFileSync('lib/sidekick-sounds.ts','utf8'),{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText;
const {SIDEKICK_SOUNDS,DEFAULT_ALERT_SOUNDS,readAlertSounds,scheduleAlertSound,loadAlertSound,eventSoundKey,ALERT_SOUND_KEYS}=await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));
assert.equal(SIDEKICK_SOUNDS.length,8);
assert.equal(new Set(SIDEKICK_SOUNDS.map(s=>JSON.stringify([s.wave,s.notes]))).size,8);
assert.deepEqual(readAlertSounds(null),DEFAULT_ALERT_SOUNDS);
assert.deepEqual(readAlertSounds({alarm:'warble',supervisory:'invalid',trouble:'low-knock'}),{...DEFAULT_ALERT_SOUNDS,alarm:'warble',supervisory:DEFAULT_ALERT_SOUNDS.supervisory,trouble:'low-knock'});
for(const sound of SIDEKICK_SOUNDS) {
 const buffer={};let started=false,stopped=false;
 const context={destination:{},createBufferSource(){return {buffer:null,connect(){},disconnect(){},start(){started=true;assert.equal(this.buffer,buffer);},stop(){stopped=true;}};}};
 const stop=scheduleAlertSound(context,sound.id,buffer);assert.ok(started);stop();assert.ok(stopped);
}
let fetches=0;
const originalFetch=globalThis.fetch;
globalThis.fetch=async url=>{assert.match(url,/\.wav\?v=/);fetches++;return {ok:true,arrayBuffer:async()=>new ArrayBuffer(4)};};
const decoded={};const decodingContext={decodeAudioData:async()=>decoded};
assert.equal(await loadAlertSound(decodingContext,'two-tone'),decoded);
assert.equal(await loadAlertSound(decodingContext,'two-tone'),decoded);assert.equal(fetches,1);
globalThis.fetch=originalFetch;
console.log('PASS: eight distinct sounds, saved mapping validation, playback scheduling and immediate stop');

assert.equal(ALERT_SOUND_KEYS.length,8);
for(const category of ['alarm','supervisory','trouble','other']) {
 assert.equal(eventSoundKey({category,message:'RESTORED '+category+' L01D001'}),category+'-restoral');
 assert.equal(eventSoundKey({category,message:'CLR '+category+' L01D001'}),category+'-restoral');
 assert.equal(eventSoundKey({category,message:category+' L01D001'}),category);
}
assert.equal(readAlertSounds({'trouble-restoral':'frog'})['trouble-restoral'],'none');
console.log('PASS: all four signal/restoral routes, eight saved assignments and old settings migration');
assert.equal(readAlertSounds({alarm:'none','trouble-restoral':'none'}).alarm,'none');
assert.equal(readAlertSounds({alarm:'none','trouble-restoral':'none'})['trouble-restoral'],'none');
let created=false;
scheduleAlertSound({createOscillator(){created=true;}},'none')();
assert.equal(created,false,'None must not create audio nodes');
for(const sound of SIDEKICK_SOUNDS){
 const wav=readFileSync(`public/sounds/${sound.id}.wav`);
 assert.equal(wav.toString('ascii',0,4),'RIFF');assert.equal(wav.toString('ascii',8,12),'WAVE');
 assert.ok(wav.length>1000);let peak=0;for(let i=44;i+1<wav.length;i+=2)peak=Math.max(peak,Math.abs(wav.readInt16LE(i)));assert.ok(peak>1000,'Preview contains audible samples');
}
console.log('PASS: None persists and stays silent; all eight preview WAV files contain audio');
assert.equal(SIDEKICK_SOUNDS.find(s=>s.id==='eagle').name,'Birdy');
for(const id of ['frog','cat','train','car-horn']) {
 assert.ok(!SIDEKICK_SOUNDS.some(s=>s.id===id));
 assert.equal(readAlertSounds({alarm:id}).alarm,'none');
}
console.log('PASS: removed sounds migrate to None');
