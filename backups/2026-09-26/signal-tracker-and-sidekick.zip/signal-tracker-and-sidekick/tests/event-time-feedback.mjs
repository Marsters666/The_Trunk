import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import ts from 'typescript';
import assert from 'node:assert/strict';
function load(file){const exports={};vm.runInNewContext(ts.transpileModule(readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText,{exports,Date});return exports;}
const time=load('lib/event-time.ts');process.env.TZ='America/Los_Angeles';
const recorded=time.laptopTimestamp(new Date('2026-09-20T16:01:02.123Z'));
assert.equal(recorded,'2026-09-20T09:01:02.123-07:00');assert(time.validCapturedTime(recorded));
assert.equal(time.eventClock(recorded),'09/20/2026 09:01:02');
process.env.TZ='Asia/Tokyo';assert.equal(time.eventClock(recorded),'09/20/2026 09:01:02');
assert.equal(time.eventDate('2026-09-20 16:01:02').toISOString(),'2026-09-20T16:01:02.000Z');assert(!time.validCapturedTime('invalid'));
const feedback=load('lib/feedback.ts');const url=new URL(feedback.feedbackLink('Test & review','First line\nSecond line'));
assert.equal(url.pathname,'mike.marsters@gmail.com');assert.equal(url.searchParams.get('subject'),'Test & review');assert.equal(url.searchParams.get('body'),'First line\nSecond line');
console.log('PASS: laptop timestamp and offset preserved on a different phone timezone, legacy UTC normalized, feedback recipient and text encoded correctly');
