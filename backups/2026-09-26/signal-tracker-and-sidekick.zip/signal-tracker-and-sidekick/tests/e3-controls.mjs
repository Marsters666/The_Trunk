import { DatabaseSync } from 'node:sqlite';
import { readFileSync, readdirSync } from 'node:fs';
import vm from 'node:vm';
import ts from 'typescript';
import assert from 'node:assert/strict';
const db = new DatabaseSync(':memory:');
for (const file of readdirSync('drizzle').filter(f=>f.endsWith('.sql')).sort()) db.exec(readFileSync(`drizzle/${file}`,'utf8'));
const adapter = { prepare(sql) { return { bind(...args) { return {
  async first() { return db.prepare(sql).get(...args); },
  async all() { return { results: db.prepare(sql).all(...args) }; },
  async run() { return db.prepare(sql).run(...args); },
}; } }; } };
const loaded={};
function load(path){
 if(loaded[path])return loaded[path];
 const exports={};
 const js=ts.transpileModule(readFileSync(path,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
 const require=id=>id.endsWith('/db')?{getRawDb:()=>adapter}:load(`lib/${id.split('/').at(-1)}.ts`);
 vm.runInNewContext(js,{exports,require,crypto,TextEncoder,Uint8Array,Response,Date,Object,console});
 return loaded[path]=exports;
}
const helpers=load('lib/server-session.ts');
const controls=load('lib/e3-control.ts');
assert.deepEqual(Array.from(controls.E3_FIRMWARE_QUERY),[0x56,0x0d]);
const route=load('app/api/sessions/[code]/controls/route.ts');
const hash=await helpers.hashPublisherToken('publisher');
db.prepare('INSERT INTO monitor_sessions(code,name,panel_family,publisher_token_hash) VALUES (?,?,?,?)').run('TESTCODE','test','ili-mb-e3',hash);
const epoch=crypto.randomUUID(),key='0123456789abcdef';
async function call(body,publisher=false){const r=await route.POST(new Request('https://test/api',{method:'POST',headers:publisher?{'x-publisher-token':'publisher'}:{},body:JSON.stringify(body)}),{params:Promise.resolve({code:'TESTCODE'})});return {status:r.status,data:await r.json()};}
const host={op:'host',epoch,key,enabled:true,resetFormat:''};
assert.equal((await call(host)).status,403);
assert.equal((await call(host,true)).status,200);
assert.equal((await call({op:'request',key:'bad',id:crypto.randomUUID(),action:'silence'})).status,403);
assert.equal((await call({op:'request',key,id:crypto.randomUUID(),action:'reset'})).status,400);
const id=crypto.randomUUID();
assert.equal((await call({op:'request',key,id,action:'ackAlarm'})).status,200);
assert.equal((await call({op:'request',key,id,action:'ackAlarm'})).status,200);
assert.equal((await call(host,true)).data.commands.length,1);
assert.equal((await call(host,true)).data.commands.length,0);
assert.equal((await call({op:'result',epoch,id,status:'sent',result:'Unconfirmed'},true)).status,200);
assert.equal((await call({op:'status',key})).data.commands[0].status,'sent');
assert.equal((await call({...host,enabled:false},true)).status,200);
assert.equal((await call({op:'request',key,id:crypto.randomUUID(),action:'silence'})).status,409);
db.prepare("INSERT INTO e3_commands VALUES (?,?,?,?,?,'pending',?,?,?)").run(crypto.randomUUID(),'TESTCODE',epoch,'silence','',0,1,'');
assert.equal((await call(host,true)).data.commands.length,0);
assert.equal((await call({op:'status',key})).data.commands.find(c=>c.expires_at===1).status,'expired');
for(const action of ['ackAlarm','ackTrouble','silence','reset']){
 const bytes=Array.from(controls.commandBytes(action,'hex'));
 assert.equal(bytes.at(-1),13); assert.equal(bytes.filter(b=>b===13).length,1); assert(!bytes.includes(10));
}
assert.equal(Array.from(controls.commandBytes('reset','text')).join(','),'82,13');
assert.throws(()=>controls.commandBytes('reset',''));
console.log('PASS: migration, authorization, explicit reset format, deduplication, claim once, result reporting, disconnected rejection, expiry, exact single-CR bytes');
