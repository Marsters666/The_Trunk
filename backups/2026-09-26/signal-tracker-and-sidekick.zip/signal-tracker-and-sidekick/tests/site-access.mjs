import { DatabaseSync } from 'node:sqlite';
import { readFileSync, readdirSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { createRequire } from 'node:module';
import vm from 'node:vm';
import ts from 'typescript';
import assert from 'node:assert/strict';

const nativeRequire=createRequire(import.meta.url), sqlite=new DatabaseSync(':memory:');
for(const f of readdirSync('drizzle').filter(f=>f.endsWith('.sql')).sort())sqlite.exec(readFileSync(`drizzle/${f}`,'utf8'));
const adapter={prepare(sql){const bound=args=>({
 async first(){return sqlite.prepare(sql).get(...args)},
 async all(){return {results:sqlite.prepare(sql).all(...args),success:true,meta:{}}},
 async raw(){const s=sqlite.prepare(sql);s.setReturnArrays(true);return s.all(...args)},
 async run(){return sqlite.prepare(sql).run(...args)},
 bind(...values){return bound(values)},
});return bound([])},async batch(statements){return Promise.all(statements.map(s=>s.all()))}};
const env={COWORKER_PASSCODE:'test-only',ACCESS_SIGNING_KEY:crypto.randomUUID()};
const cache=new Map();
function load(file){file=resolve(file);if(cache.has(file))return cache.get(file);const exports={};cache.set(file,exports);
const js=ts.transpileModule(readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
const require=id=>id==='cloudflare:workers'?{env}:id==='next/server'?{NextResponse:{next:()=>new Response(null,{status:200}),redirect:(u,s)=>new Response(null,{status:s,headers:{location:String(u)}})}}:id.endsWith('/db')?{getRawDb:()=>adapter}:id.startsWith('.')?load(resolve(dirname(file),id+'.ts')):nativeRequire(id);
vm.runInNewContext(js,{exports,require,crypto,TextEncoder,Uint8Array,Response,URL,URLSearchParams,Date,Object,console});return exports;}
const access=load('lib/site-access.ts'),unlock=load('app/unlock/route.ts'),gate=load('middleware.ts');
const target='/?mode=companion&session=ABCDEFGH';
const post=(passcode,ip='one',origin='https://test')=>new Request('https://test/unlock',{method:'POST',headers:{origin,'cf-connecting-ip':ip},body:new URLSearchParams({passcode,returnTo:target})});
assert.equal((await gate.middleware(new Request('https://test/api/sessions/ABCDEFGH'))).status,401);
const redirect=await gate.middleware(new Request('https://test'+target));
assert.equal(redirect.status,200);
assert.equal((await unlock.POST(post('wrong'))).status,401);
assert.equal((await unlock.POST(post(env.COWORKER_PASSCODE,'two','https://evil.test'))).status,403);
const valid=await unlock.POST(post(env.COWORKER_PASSCODE));assert.equal(valid.status,303);assert.equal(new URL(valid.headers.get('location'),'https://test').searchParams.get('returnTo'),target);
const cookie=valid.headers.get('set-cookie');assert(cookie.includes('HttpOnly; Secure; SameSite=None; Partitioned'));
const authed=new Request('https://test/api/sessions',{headers:{cookie}});assert(await access.hasAccess(authed));assert.equal((await gate.middleware(authed)).status,200);
assert.equal(await access.hasAccess(new Request('https://test',{headers:{cookie:cookie.replace(/access=./,'access=9')}})),false);
for(let i=0;i<20;i++)assert.equal((await unlock.POST(post('wrong','limited'))).status,401);
assert.equal((await unlock.POST(post(env.COWORKER_PASSCODE,'limited'))).status,429);
for(const u of ['https://evil.test','//evil.test','/\\\\evil.test','/unlock'])assert.equal(access.safeReturn(u),'/');
env.COWORKER_PASSCODE='changed';assert.equal(await access.hasAccess(authed),false);
delete env.ACCESS_SIGNING_KEY;assert.equal(await access.hasAccess(authed),false);
assert.equal((await unlock.POST(post('changed','new'))).status,503);
console.log('PASS: server gate, wrong code, secure cookie, QR return, forged cookie, rate limit, same-origin form, safe redirects, secret rotation and fail-closed configuration');

const jsonPost = code=>new Request('https://test/unlock',{method:'POST',headers:{origin:'https://test','content-type':'application/json','cf-connecting-ip':'json-test'},body:JSON.stringify({passcode:code})});
env.COWORKER_PASSCODE='test-only';env.ACCESS_SIGNING_KEY=crypto.randomUUID();
assert.equal((await unlock.POST(jsonPost('wrong'))).status,401);
const result=await unlock.POST(jsonPost('test-only'));assert.equal(result.status,200);const {token}=await result.json();
const bearerRequest=new Request('https://test/api/access',{headers:{Authorization:'Bearer '+token}});
assert.equal(await access.hasAccess(bearerRequest),true);assert.equal((await gate.middleware(bearerRequest)).status,200);
assert.equal((await load('app/api/access/route.ts').GET(bearerRequest)).status,200);
assert.equal((await load('app/api/access/route.ts').GET(new Request('https://test/api/access'))).status,401);
assert.equal((await unlock.GET(new Request('https://test/unlock?returnTo='+encodeURIComponent(target)))).headers.get('location'),target);
console.log('PASS: cookie-free JSON unlock, bearer verification, API protection and preserved QR destination');
