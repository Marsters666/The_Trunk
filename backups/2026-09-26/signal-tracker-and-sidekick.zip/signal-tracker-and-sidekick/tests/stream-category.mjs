import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import ts from 'typescript';
const summaryCode=ts.transpileModule(readFileSync('lib/notifier-count-summary.ts','utf8'),{compilerOptions:{module:ts.ModuleKind.ESNext}}).outputText;
const summaryUrl='data:text/javascript;base64,'+Buffer.from(summaryCode).toString('base64');
const code=ts.transpileModule(readFileSync('lib/stream-category.ts','utf8'),{compilerOptions:{module:ts.ModuleKind.ESNext}}).outputText;
const {streamCategory,streamSignalColor}=await import('data:text/javascript;base64,'+Buffer.from(code.replace("'./notifier-count-summary'",JSON.stringify(summaryUrl))).toString('base64'));
for(const message of ['SYSTEM RESET','SYSTEM RESET 06:21P Tue 09/22/26','INITIATED BY     N001 12:12:49A THU JAN 01, 2015','  initiated by N40'])assert.equal(streamCategory({category:'other',message}),'system-reset');
for(const [category,message] of [['trouble','TROUBLE SYSTEM RESET SWITCH'],['other','Other event'],['alarm','FIRE ALARM']])assert.equal(streamCategory({category,message}),category);
console.log('PASS: reset and initiator lines have their own stream category; ordinary signals retain their categories');
assert.equal(streamCategory({category:'trouble',message:'ACKED TROUBLE NCM COMM FAILURE'}),'acknowledged');
assert.equal(streamCategory({category:'alarm',message:'ACK FIRE ALARM L01D001'}),'acknowledged');
assert.equal(streamCategory({category:'trouble',message:'Homie 12:12:29A THU JAN 01, 2015'},'ACKED TROUBLE NCM COMM FAILURE'),'acknowledged');
assert.equal(streamCategory({category:'trouble',message:'TROUBLE L01D002 12:12:29A THU JAN 01, 2015'},'ACKED TROUBLE NCM COMM FAILURE'),'trouble');
console.log('PASS: acknowledgement headers/details have independent stream classification; subsequent new troubles remain troubles');
for(const [message,expected] of [['Screen Print','screen-print'],['Time and Date','time-date'],['Events Counts Display','event-counts'],['Read Status','read-status'],['Program/Alter Status','program-alter'],['Multiple Event List','multiple-events'],['Printer Functions','printer-functions'],['History Display','history-display']]){
 assert.equal(streamCategory({category:'other',message}),expected);
 assert.equal(streamCategory({category:'other',message:'Homie 12:12:29A THU JAN 01, 2015'},message),expected);
 assert.equal(streamCategory({category:'trouble',message:'TROUBLE '+message}),'trouble');
}
console.log('PASS: eight panel-function labels and follow-up detail lines; actual trouble headers remain troubles');

for(const message of ['12:33:41A THU JAN 01, 2015','====== 01:03:49A THU JAN 01, 2015======='])assert.equal(streamCategory({category:'other',message}),'time-date');
assert.equal(streamCategory({category:'other',message:'******EVENT HISTORY********'}),'event-history');
assert.equal(streamCategory({category:'other',message:'Homie'},'SCREEN PRINT','12:33:41A THU JAN 01, 2015'),'node-label');
assert.equal(streamCategory({category:'trouble',message:'Homie                                    12:32:52A THU JAN 01, 2015'}),'node-label');
assert.equal(streamCategory({category:'alarm',message:'FIRE ALARM L01D001   12:32:52A THU JAN 01, 2015'}),'alarm');
assert.equal(streamCategory({category:'other',message:'Unknown message'}),'other');
console.log('PASS: raw time/date, decorated history and node labels use dedicated categories');

for(const message of ['****SCREEN PRINT****','****** SCREEN PRINT ******','  ****screen print****  ']) {
 assert.equal(streamCategory({category:'other',message}),'screen-print');
 assert.equal(streamCategory({category:'other',message},'', '12:33:41A THU JAN 01, 2015'),'screen-print');
 assert.equal(streamCategory({category:'other',message:'Homie 12:33:41A THU JAN 01, 2015'},message),'screen-print');
}
assert.equal(streamCategory({category:'trouble',message:'TROUBLE ****SCREEN PRINT****'}),'trouble');
console.log('PASS: starred Screen Print headers and following details use the theme category');

for(const message of ['============= EVENT COUNTS =============','FIRE ALARMS:000 PREALARM:000 TROUBLE:005','SUPERVISORY:000 SECURITY:000 OTHER:000'])assert.equal(streamCategory({category:'supervisory',message}),'event-counts');
console.log('PASS: panel count rows and heading use the theme accent');

for(const message of ['SIGNAL SILENCE','Signal Silenced','SIGNALS SILENCED','**** SIGNAL SILENCE ****','SIGNAL SILENCE    12:33:41A THU JAN 01, 2015']) {
 assert.equal(streamCategory({category:'other',message},'', '12:33:41A THU JAN 01, 2015'),'signal-silence');
}
assert.equal(streamCategory({category:'other',message:'Homie 12:33:41A THU JAN 01, 2015'},'SIGNAL SILENCE'),'signal-silence');
assert.equal(streamCategory({category:'trouble',message:'TROUBLE SIGNAL SILENCE SWITCH'}),'trouble');
console.log('PASS: Signal Silence variants use their own themed category; actual switch troubles stay Trouble');
assert.equal(streamCategory({category:'alarm',message:'ALARM:0000 SUPERVISORY:0000 TROUBLE:0005'}),'event-counts');
assert.equal(streamCategory({category:'other',message:'================'}),'separator');
for(const message of ['2 TBL NO POWER SUPPLY INST','3 TBL BUZZER OFF-LINE'])assert.equal(streamCategory({category:'other',message}),'trouble');
for(const message of ['TROUBL IN SYSTEM Sys Initialization 09:20A 092526 Fri','CLR TB IN SYSTEM Sys Initialization 09:21A 092526 Fri'])assert.equal(streamCategory({category:'other',message}),'trouble');
assert.equal(streamCategory({category:'other',message:'CLR TB STROBE CKT RPS 1,2 AND 3 TRIP BLDGS A, E OPEN 09:29A 092526 B01'}),'trouble');
assert.equal(streamCategory({category:'other',message:'TAMALPAIS VALLEY ELEMENTARY SYSTEM NORMAL 09:29A 092526 Fri'}),'system-normal');
assert.equal(streamCategory({category:'other',message:'SYSTEM NORMAL'}),'system-normal');
assert.equal(streamCategory({category:'trouble',message:'TROUBLE SYSTEM NORMAL RELAY L01M002'}),'trouble');
assert.equal(streamCategory({category:'trouble',message:'DISABL TROUBLE_MON RPS-3 TROUBLE RM 25/BLDG E DISABL 09:35A 092526 1M010'}),'other');
assert.equal(streamCategory({category:'trouble',message:'CLR TB RELAY AC SHUTDOWN BUILDING A1 DISABL 10:21A 092526 1M011'}),'other');
for(const address of ['B01','B02','B03','B04'])assert.equal(streamCategory({category:'trouble',message:`CLR TB STROBE CKT SPARE DISABL 10:31A 092526 ${address}`}),'other');

const alarmAck='ACK FIRE ALARM YOU ARE ABOUT TO GET';
const alarmDetail='1st Floor Z1 Waterflow 05:21:06A SAT SEP 26 2026 N1L1M2';
for(const [message,previous,expected] of [[alarmAck,'','alarm'],[alarmDetail,alarmAck,'alarm'],['ACKNOWLEDGE 05:21:06A SAT SEP 26 2026',alarmAck,null],['ACK TROUBLE NCM COMM FAILURE','',null],[alarmDetail,'ACK TROUBLE NCM COMM FAILURE',null]]) {
 const category=streamCategory({category:'other',message},previous);
 assert.equal(category,'acknowledged');
 assert.equal(streamSignalColor(category,message,previous,'notifier-n16'),expected);
}
assert.equal(streamSignalColor('acknowledged',alarmAck,'','notifier-nfs2-3030'),null);
console.log('PASS: N16 acknowledged alarm header/detail use alarm color; standalone and trouble acknowledgements stay themed');
