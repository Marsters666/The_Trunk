"""Generate the uniform Signal Tracker RS-232 wiring library."""

from pathlib import Path
import html

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "public" / "wiring"
OUT.mkdir(parents=True, exist_ok=True)

BLACK = "#111111"
RED = "#ef4444"
GREEN = "#22c55e"
WIRES = [
    {"pin": 2, "signal": "PTX", "color": BLACK, "name": "BLACK"},
    {"pin": 3, "signal": "PRX", "color": RED, "name": "RED"},
    {"pin": 5, "signal": "REF", "color": GREEN, "name": "GREEN"},
]

PANELS = [
    ("notifier-n16", "Notifier N16", "Printer connection · TX / RX / CTS / REF", ["TX", "RX", "REF"], "CTS is not used in this three-wire connection."),
    ("notifier-nfw-100", "Notifier NFW-100", "TB8 · serial printer / computer connection", ["TX", "RCV", "GRND"], "DTR is not used in this three-wire connection."),
    ("notifier-nfw2-100", "Notifier NFW2-100", "TB8 · serial printer / computer connection", ["TX", "RCV", "GRND"], "DTR is not used in this three-wire connection."),
    ("notifier-nfs-320", "Notifier NFS-320", "TB12 · PRN-series printer connection", ["TB12 PTX", "TB12 PRX", "TB12 REF"], "Use the first PTX, PRX and REF terminals shown in the panel manual."),
    ("notifier-nfs2-640", "Notifier NFS2-640", "TB12 · PRN-series printer connection", ["TB12 PTX", "TB12 PRX", "TB12 REF"], "Use the first PTX, PRX and REF terminals shown in the panel manual."),
    ("notifier-nfs2-3030", "Notifier NFS2-3030", "TB5 · PRN-series printer connection", ["TB5 PTX", "TB5 PRX", "TB5 REF"], "CTX, CTS/CRX and the second REF terminal are not used."),
    ("notifier-nca-2", "Notifier NCA-2", "TB5 · PRN-series printer connection", ["TB5 PTX", "TB5 PRX", "TB5 REF"], "CTX, CTS/CRX and the second REF terminal are not used."),
    ("notifier-afp-100", "Notifier AFP-100", "TB7 · printer / computer interface", ["TB7 TX", "TB7 RCV", "TB7 GRND"], "Use the TX, RCV and GRND terminals at the printer interface."),
    ("notifier-afp-200", "Notifier AFP-200", "TB4 · EIA-232 printer interface", ["TB4-1 TX", "TB4-3 RX", "TB4-2 REF"], "The optional pin 4-to-6 upload/download jumper is not part of this monitor cable."),
    ("notifier-afp-400", "Notifier AFP-400", "CPU-400 TB1 · EIA-232 printer interface", ["TB1-1 TX", "TB1-2 RX", "TB1-3 REF"], "This DB-9 mapping uses the terminal roles from the supplied PRN-4 reference."),
    ("ili-mb-e3", "Gamewell-FCI ILI-MB-E3", "TB6 · RS-232 download or printer port", ["TB6-2 TxD", "TB6-4 RxD", "TB6-1 GND"], "TB6-3 supervision is not used."),
    ("ili95-mb-e3", "Gamewell-FCI ILI95-MB-E3", "TB6 · RS-232 download or printer port", ["TB6-4 TxD", "TB6-2 RxD", "TB6-1 GND"], "This board revision reverses the TB6-2 and TB6-4 TX/RX roles."),
    ("ili-s-e3", "Gamewell-FCI ILI-S-E3", "TB6 · RS-232 download or printer port", ["TB6-2 TxD", "TB6-4 RxD", "TB6-1 GND"], "TB6-3 supervision is not used."),
    ("est3", "Edwards / EST3", "CPU · TB2 port 2", ["TB2 TX2", "TB2 RX2", "TB2 COM2"], "Confirm that port 2 is programmed for the required event output."),
    ("est-io64", "Edwards / EST iO64", "SA-232 card", ["SA-232 TXD", "SA-232 RXD", "SA-232 GND"], "RTS is not used in this three-wire connection."),
]


def esc(value):
    return html.escape(str(value), quote=True)


def txt(x, y, value, size=17, color="#dceaf3", anchor="start", weight=400):
    return f'<text x="{x}" y="{y}" fill="{color}" font-size="{size}" text-anchor="{anchor}" font-weight="{weight}">{esc(value)}</text>'


def line_path(path, color, width=5, halo=False):
    parts = []
    if halo:
        parts.append(f'<path d="{path}" fill="none" stroke="#f4f7f8" stroke-width="{width + 5}" stroke-linecap="round" stroke-linejoin="round"/>')
    parts.append(f'<path d="{path}" fill="none" stroke="{color}" stroke-width="{width}" stroke-linecap="round" stroke-linejoin="round"/>')
    return "".join(parts)


for panel_id, title, port, terminals, note in PANELS:
    svg = [
        '<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="900" viewBox="0 0 1000 900">',
        '<rect width="1000" height="900" rx="22" fill="#101b23"/>',
        '<g font-family="Arial,Helvetica,sans-serif">',
        txt(40, 48, f"{title} · RS-232 wiring", 27, weight=700),
        txt(40, 78, port, 16, "#a8bccb"),
        '<rect x="40" y="112" width="385" height="330" rx="14" fill="#172a36" stroke="#3e5969" stroke-width="2"/>',
        txt(66, 148, "FIRE ALARM PANEL", 14, "#8fd4f7", weight=700),
        txt(66, 178, "RS-232 TERMINALS", 21, weight=700),
        '<rect x="88" y="224" width="290" height="132" rx="8" fill="#d9e1e6" stroke="#7895a8" stroke-width="3"/>',
    ]

    terminal_y = [250, 290, 330]
    for index, (terminal, wire) in enumerate(zip(terminals, WIRES)):
        y = terminal_y[index]
        svg.extend([
            f'<circle cx="340" cy="{y}" r="15" fill="#243845" stroke="#607d8e" stroke-width="3"/>',
            f'<path d="M331 {y-7} L349 {y+7}" stroke="#dbe8ee" stroke-width="3"/>',
            txt(110, y + 6, terminal, 17, "#101b23", weight=700),
            txt(66, 398 + index * 22, f'{wire["name"]}: {terminal}', 15, "#f4f7f8" if wire["name"] == "BLACK" else wire["color"], weight=700),
        ])

    svg.extend([
        txt(575, 130, "DB-9 FEMALE CONNECTOR", 20, weight=700),
        txt(575, 158, "REAR / WIRING SIDE", 15, "#8fd4f7", weight=700),
        '<path d="M555 215 H884 Q903 215 898 234 L881 350 Q878 368 861 368 H578 Q561 368 558 350 L541 234 Q537 215 555 215 Z" fill="#233946" stroke="#a6c2d2" stroke-width="3"/>',
    ])

    pin_xy = {1: (835, 265), 2: (775, 265), 3: (715, 265), 4: (655, 265), 5: (595, 265), 6: (805, 325), 7: (745, 325), 8: (685, 325), 9: (625, 325)}
    for pin in range(1, 10):
        x, y = pin_xy[pin]
        wire = next((candidate for candidate in WIRES if candidate["pin"] == pin), None)
        stroke = wire["color"] if wire else "#89a2b1"
        if pin == 2:
            stroke = "#f4f7f8"
        svg.extend([
            f'<circle cx="{x}" cy="{y}" r="18" fill="#0f1b22" stroke="{stroke}" stroke-width="3"/>',
            txt(x, y + 6, pin, 16, stroke, "middle", 700),
        ])

    starts = [(340, 250), (340, 290), (340, 330)]
    lanes = [475, 500, 525]
    for (sx, sy), lane, wire in zip(starts, lanes, WIRES):
        px, py = pin_xy[wire["pin"]]
        path = f"M {sx} {sy} H 455 V {lane} H {px} V {py}"
        svg.append(line_path(path, wire["color"], 6, wire["pin"] == 2))
        label_color = "#f4f7f8" if wire["pin"] == 2 else wire["color"]
        svg.append(txt(480, lane - 8, f'{wire["name"]} · PIN {wire["pin"]} {wire["signal"]}', 14, label_color, weight=700))

    svg.extend([
        '<path d="M40 575 H960" stroke="#344957" stroke-width="2"/>',
        txt(40, 614, "DB-9 SIDE PROFILE", 20, weight=700),
        txt(40, 642, "Schematic · not to scale", 14, "#a8bccb"),
        txt(92, 680, "Panel cable", 14, "#a8bccb"),
        txt(350, 680, "Rear solder cups", 14, "#a8bccb"),
        txt(625, 680, "Female sockets", 14, "#a8bccb"),
        txt(830, 680, "Male adapter", 14, "#a8bccb"),
        '<rect x="480" y="702" width="150" height="78" rx="5" fill="#304756" stroke="#abc2d0" stroke-width="2"/>',
        '<rect x="630" y="695" width="14" height="92" fill="#829cab"/>',
        '<rect x="825" y="702" width="118" height="78" rx="5" fill="#304756" stroke="#abc2d0" stroke-width="2"/>',
    ])
    for index, wire in enumerate(WIRES):
        y = 720 + index * 22
        svg.append(line_path(f"M92 {y} H510", wire["color"], 5, wire["pin"] == 2))
        svg.append(f'<path d="M510 {y} H630" stroke="#e3c776" stroke-width="7"/><path d="M517 {y} H630" stroke="#101b23" stroke-width="3"/>')
        svg.append(f'<path d="M775 {y} H875" stroke="#e3c776" stroke-width="4"/>')
    svg.extend([
        txt(710, 812, "Mating direction ←", 14, "#a8bccb", "middle"),
        txt(40, 842, note, 15, "#ffd397"),
        txt(40, 869, "Color standard: Black = pin 2 PTX · Red = pin 3 PRX · Green = pin 5 REF", 16, "#dceaf3", weight=700),
        '</g></svg>',
    ])
    (OUT / f"{panel_id}-db9.svg").write_text("".join(svg), encoding="utf-8")

print(f"Generated {len(PANELS)} uniform DB-9 wiring diagrams")
