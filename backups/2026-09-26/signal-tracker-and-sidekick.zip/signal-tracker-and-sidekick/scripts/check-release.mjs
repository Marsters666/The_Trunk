import {spawnSync} from 'node:child_process';
const checks=['session-isolation','stream-category','sidekick-reconnect','sidekick-sounds','capture-outbox','capture-retry','serial-cleanup','serial-reuse','report-order'];
for(const check of checks){
 const result=spawnSync(process.execPath,[`tests/${check}.mjs`],{stdio:'inherit'});
 if(result.status!==0)process.exit(result.status??1);
}
const types=spawnSync(process.execPath,['node_modules/typescript/bin/tsc','--noEmit'],{stdio:'inherit'});
process.exit(types.status??1);
