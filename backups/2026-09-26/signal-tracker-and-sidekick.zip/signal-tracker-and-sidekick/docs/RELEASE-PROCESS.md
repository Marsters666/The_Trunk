# Signal Tracker beta release process

User requirement, effective September 22, 2026: every published change must preserve the complete source, detailed revision notes, a plain-language summary, and matching notes visible in Signal Tracker until the production release.

1. Add a new entry at the top of `lib/revisions.json`. Use a unique dated revision ID. Include the scope, summary, every material change, and accurate verification limitations. Do not rewrite earlier notes except to correct documented errors.
2. The Revisions dialog imports this same file. Build code and notes together; do not maintain a separate manual copy of the website notes.
3. Run `node scripts/check-release.mjs` before every publication; this replays captured NFS2-3030 and N16 fixtures, NFS2-640 screenshot sequences, and capture/reconnect/audio regressions. Then build. Commit all intended code and notes through the Sites workflow and retain its exact source SHA. Save and deploy that same source state.
4. Archive the full source and notes to the user's GitHub repository once its URL and access are provided. Verify the GitHub commit before reporting success. Never claim a Sites Git push is a GitHub push.
5. Keep the deployed website, source snapshot, and revision ID in agreement. If GitHub synchronization is unavailable, explicitly report it as incomplete.

## Current GitHub status

Designated repository: https://github.com/Marsters666/The_Trunk.git. Rechecked September 26, 2026: the connector can read this public repository but reports push permission false. GitHub backup remains incomplete until write access is granted. Do not claim a successful backup or try to bypass permissions.

## Historical notes

Entries 2026.09.22.01–15 were reconstructed from existing Git commits. Their source SHAs are recorded. These notes describe implementation changes, not independent validation on a physical panel. Earlier work remains in Git history; the in-app dated log begins September 22, 2026 as requested.
