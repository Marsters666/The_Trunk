# Signal Tracker project instructions

For every beta publication, follow `docs/RELEASE-PROCESS.md`.
Update `lib/revisions.json` with a new summary and detailed change list in the same source revision as the code. The website reads this file directly. Preserve earlier entries.
The user requires a complete GitHub source and revision-note backup for each publication. Read the documented GitHub status, use only the user-designated repository, and verify synchronization. If access is unavailable, clearly report the incomplete backup rather than claiming success.
Preserve monitoring, serial handling, queue counting, pairing and report behavior unless the user requests a functional change. Never claim physical-panel verification based solely on automated tests.
