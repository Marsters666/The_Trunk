declare namespace Cloudflare {
  interface Env {
    DB?: D1Database;
    COWORKER_PASSCODE?: string;
    ACCESS_SIGNING_KEY?: string;
    BUCKET?: R2Bucket;
  }
}
