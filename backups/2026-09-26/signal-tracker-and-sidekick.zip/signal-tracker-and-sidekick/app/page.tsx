import { AccessGate } from "./access-gate";
import { PanelStreamDashboard } from "./panelstream-dashboard";

export default function Home() {
  return <AccessGate><PanelStreamDashboard /></AccessGate>;
}
