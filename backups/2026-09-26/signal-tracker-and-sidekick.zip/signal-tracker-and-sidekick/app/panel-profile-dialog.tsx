'use client';
import {useState} from 'react';
import {Dialog,DialogContent,DialogHeader,DialogTitle,DialogDescription,DialogFooter} from '@/components/ui/dialog';
import {Input} from '@/components/ui/input';
import {Label} from '@/components/ui/label';
import {Button} from '@/components/ui/button';
import {Select,SelectTrigger,SelectValue,SelectContent,SelectItem} from '@/components/ui/select';
import {type PanelProfile,validProfile} from '@/lib/panel-profiles';
export function PanelProfileDialog({initial,onClose,onSaved}:{initial:Partial<PanelProfile>;onClose:()=>void;onSaved:(p:PanelProfile)=>void}) {
 const [form,setForm]=useState({name:initial.name??'',baudRate:initial.baudRate??'',dataBits:initial.dataBits??'8',parity:initial.parity??'none',stopBits:initial.stopBits??'1',flowMode:initial.flowMode??'none'});
 const [busy,setBusy]=useState(false),[error,setError]=useState('');
 async function save(e:React.FormEvent) {
  e.preventDefault(); if(!validProfile(form)){setError('Enter the panel name and a valid baud rate from 50 to 4,000,000.');return;}
  setBusy(true);setError('');
  try { const r=await fetch('/api/panel-profiles',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({...form,id:initial.id,expectedRevision:initial.revision??0})});const data=await r.json() as {error?:string;profile:PanelProfile};if(!r.ok)throw Error(data.error);onSaved(data.profile); }
  catch(e){setError(e instanceof Error?e.message:'Unable to save profile.');}finally{setBusy(false);}
 }
 return <Dialog open onOpenChange={v=>{if(!v&&!busy)onClose();}}><DialogContent className="signal-dialog"><DialogHeader><DialogTitle>{initial.id?'Edit panel settings':'Add a panel'}</DialogTitle><DialogDescription>Save a named RS-232 profile on the website. New or edited settings need user verification before displaying a green check.</DialogDescription></DialogHeader>
 <form onSubmit={save} className="panel-profile-form">
 <Label htmlFor="profile-name">Panel manufacturer and model</Label><Input id="profile-name" required maxLength={100} value={form.name} onChange={e=>setForm({...form,name:e.target.value})} disabled={busy}/>
 <Label htmlFor="profile-baud">Baud rate</Label><Input id="profile-baud" type="number" min={50} max={4000000} step={1} required value={form.baudRate} onChange={e=>setForm({...form,baudRate:e.target.value})} disabled={busy}/>
 <Label>Data bits</Label><Select value={form.dataBits} onValueChange={v=>setForm({...form,dataBits:v as '7'|'8'})} disabled={busy}><SelectTrigger aria-label="Data bits"><SelectValue/></SelectTrigger><SelectContent>{['7','8'].map(v=><SelectItem key={v} value={v}>{v}</SelectItem>)}</SelectContent></Select>
 <Label>Parity</Label><Select value={form.parity} onValueChange={v=>setForm({...form,parity:v as 'none'|'even'|'odd'})} disabled={busy}><SelectTrigger aria-label="Parity"><SelectValue/></SelectTrigger><SelectContent>{['none','even','odd'].map(v=><SelectItem key={v} value={v}>{v}</SelectItem>)}</SelectContent></Select>
 <Label>Stop bits</Label><Select value={form.stopBits} onValueChange={v=>setForm({...form,stopBits:v as '1'|'2'})} disabled={busy}><SelectTrigger aria-label="Stop bits"><SelectValue/></SelectTrigger><SelectContent>{['1','2'].map(v=><SelectItem key={v} value={v}>{v}</SelectItem>)}</SelectContent></Select>
 {error?<p role="alert" className="profile-error">{error}</p>:null}
 <DialogFooter><Button type="button" variant="outline" onClick={onClose} disabled={busy}>Cancel</Button><Button type="submit" disabled={busy}>{busy?'Saving…':'Save to website'}</Button></DialogFooter>
 </form></DialogContent></Dialog>;
}
