'use client';
import { isSidekickEntry } from '@/lib/app-mode';
import { useEffect, useRef, useState } from 'react';
const STORAGE_KEY = 'signal-tracker-access-v2';

export function AccessGate({children}:{children:React.ReactNode}) {
  const [acknowledged,setAcknowledged]=useState(false);
  const [gatewayOff,setGatewayOff]=useState(false);
  const [ready,setReady]=useState(false);
  const [checking,setChecking]=useState(true);
  const [busy,setBusy]=useState(false);
  const [error,setError]=useState('');
  const [sidekick,setSidekick]=useState(false);
  const tokenRef=useRef('');
  const fetchRef=useRef<typeof fetch | null>(null);
  useEffect(()=>{
    setSidekick(isSidekickEntry(location.search));
    const original=window.fetch.bind(window);fetchRef.current=original;
    let active=true;
    try { tokenRef.current=localStorage.getItem(STORAGE_KEY)||''; } catch {}
    window.fetch=async(input,init)=>{
      const url=new URL(typeof input==='string'?input:input instanceof URL?input.href:input.url,location.href);
      if(url.origin!==location.origin || !url.pathname.startsWith('/api/')) return original(input,init);
      const headers=new Headers(input instanceof Request?input.headers:undefined);
      new Headers(init?.headers).forEach((value,key)=>headers.set(key,value));
      if(tokenRef.current) headers.set('Authorization','Bearer '+tokenRef.current);
      const response=await original(input,{...init,headers});
      if(response.status===401 && active){setReady(false);setError('Your access expired. Enter the passcode again.');}
      return response;
    };
    void window.fetch('/api/access',{cache:'no-store',signal:AbortSignal.timeout(15000)}).then(r=>{if(active){setReady(r.ok);setError('');}}).catch(()=>{if(active)setError('Unable to connect. Check your internet connection and try again.');}).finally(()=>{if(active)setChecking(false);});
    return ()=>{active=false;window.fetch=original;};
  },[]);
  async function submit(event:React.FormEvent<HTMLFormElement>){
    event.preventDefault();setBusy(true);setError('');
    const form=event.currentTarget;
    try {
      const passcode=String(new FormData(form).get('passcode')||'').trim();
      const response=await fetchRef.current!('/unlock',{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json'},body:JSON.stringify({passcode}),signal:AbortSignal.timeout(15000)});
      const data=await response.json().catch(()=>({error:'The access service could not respond. Please try again.'})) as {error?:string;token?:string};
      if(!response.ok) throw new Error(data.error||'Unable to unlock. Please try again.');
      if(typeof data.token!=='string' || !data.token) throw new Error('No access confirmation was received. Please try again.');
      tokenRef.current=data.token;
      try {localStorage.setItem(STORAGE_KEY,data.token);}catch{}
      const verified=await window.fetch('/api/access',{cache:'no-store',signal:AbortSignal.timeout(15000)});
      if(!verified.ok)throw new Error('Access could not be verified. Please try again.');
      form.reset();setAcknowledged(false);setGatewayOff(false);setReady(true);
    }catch(e){setError(e instanceof Error?e.message:'Unable to unlock. Please try again.');}
    finally{setBusy(false);}
  }
  if(ready && !sidekick && !acknowledged)return <main className="access-screen"><section className="access-card gateway-notice"><div className="access-brand"><img src="/signal-tracker-logo.png" alt="" width="48" height="48"/><span>Rising Sun Projects</span></div><p className="notice-kicker">PRE-CONNECTION REQUIREMENT</p><h1>Notifier Gateway must be turned off</h1><p>Before proceeding to Signal Tracker on this laptop, confirm that the Notifier Gateway is turned off for this monitoring session.</p><p className="access-note">Complete this step in accordance with your site’s approved testing procedures. Signal Tracker cannot verify the Gateway’s state.</p><label className="gateway-check"><input type="checkbox" checked={gatewayOff} onChange={e=>setGatewayOff(e.target.checked)}/>I confirm the Notifier Gateway is turned off.</label><button disabled={!gatewayOff} onClick={()=>setAcknowledged(true)}>Continue to {sidekick?'SideKick':'Signal Tracker'}</button></section></main>;
  if(ready)return <>{children}</>;
  return <main className="access-screen"><section className="access-card"><div className="access-brand"><img src="/signal-tracker-logo.png" alt="" width="48" height="48"/><span>{sidekick?'SideKick':'Signal Tracker'}</span></div><h1>Coworker access</h1><p>Enter your team’s passcode to continue.</p>{checking?<p role="status">Checking access…</p>:<form onSubmit={submit}><label htmlFor="coworker-passcode">Passcode</label><input id="coworker-passcode" name="passcode" type="password" inputMode="numeric" autoComplete="current-password" required maxLength={64} autoFocus disabled={busy}/><button type="submit" disabled={busy}>{busy?'Opening…':'Continue'}</button></form>}{error&&<p className="access-error" role="alert">{error}</p>}<p className="access-note">Access lasts 30 days on this browser. Your session pairing code is separate.</p></section></main>;
}
