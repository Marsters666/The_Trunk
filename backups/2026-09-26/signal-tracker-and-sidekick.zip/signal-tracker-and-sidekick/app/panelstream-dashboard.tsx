"use client";
import { saveCapture, pendingCapture, removeCapture } from "@/lib/capture-outbox";

import { SerialReuse } from "@/lib/serial-reuse";
import { SerialCleanup } from "@/lib/serial-cleanup";
import { streamCategory, streamSignalColor, THEMED_STREAM_LABELS } from "@/lib/stream-category";
import { cloneElement } from "react";
import { ALERT_CATEGORIES, eventSoundKey, SIDEKICK_SOUNDS, DEFAULT_ALERT_SOUNDS, readAlertSounds, scheduleAlertSound, loadAlertSound, ALERT_AUDIO_REVISION, type AlertSoundKey, type AlertSounds, type SoundId } from "@/lib/sidekick-sounds";
import { KeepAwake } from "./keep-awake";
import { RevisionHistory } from "./revision-history";
import { AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogTitle, AlertDialogDescription, AlertDialogFooter, AlertDialogCancel, AlertDialogAction } from "@/components/ui/alert-dialog";
import { ExistingReport } from "./existing-report";
import { useAppearance, type Palette as AppearancePalette } from "./appearance";
import { Instructions, FeedbackDialog } from './help-and-feedback';
import { eventClock, laptopTimestamp } from '@/lib/event-time';
import { ReportOptions, defaultReport, validateReport, type ReportSettings } from './report-settings';
type ReportFolder = {name:string;getFileHandle:(name:string,options:{create:boolean})=>Promise<{createWritable:()=>Promise<{write:(data:Blob)=>Promise<void>;close:()=>Promise<void>}>}>};

import { SidekickSetup } from "./sidekick-setup";
import { randomId } from "@/lib/random-id";

import { E3Controls } from "./e3-controls";
import { E3_FIRMWARE_QUERY, isE3 } from "@/lib/e3-control";

import {
  Maximize,
  Minimize,
  Printer,
  BookOpen,
  MessageSquare,
  Bell,
  BellOff,
  Cable,
  Check,
  ChevronDown,
  ChevronRight,
  Download,
  ExternalLink,
  FileText,
  Laptop,
  LoaderCircle,
  Mail,
  Menu,
  MonitorSmartphone,
  Palette,
  Play,
  Radio,
  RefreshCw,
  RotateCcw,
  Send,
  Settings2,
  Share2,
  ShieldAlert,
  Smartphone,
  Square,
  TerminalSquare,
  Unplug,
  Wifi,
  WifiOff,
  X,
} from "lucide-react";
import Image from "next/image";
import { FormEvent, Fragment, useCallback, useEffect, useMemo, useRef, useState } from "react";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuCheckboxItem,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  CATEGORY_LABELS,
  classifySerialMessage,
  DEFAULT_COLORS,
  EVENT_CATEGORIES,
  EventCategory,
  normalizeSessionCode,
  SerialEvent,
} from "@/lib/panelstream";
import {
  createSignalExport,
  downloadFile,
} from "@/lib/signal-export";
import { guideForPanel, PANEL_OPTIONS, panelLabel, WIRING_GUIDES } from "@/lib/wiring-guides";

import { COMM_PRESETS, FONT_CHOICES, inspectSerialBytes } from "@/lib/communication-presets";

import { PanelProfileDialog } from "./panel-profile-dialog";
import { type PanelProfile } from "@/lib/panel-profiles";

type MonitorSession = {
  code: string;
  name: string;
  panelFamily: string;
  isLive: boolean;
  createdAt: string;
  updatedAt?: string;
};

type Counts = Record<EventCategory, number>;
type SignalColors = Record<EventCategory, string>;
type ConnectionState = "idle" | "connecting" | "connected" | "unavailable";
type RefreshMode = "auto" | "manual";

type SerialOptions = {
  baudRate: number;
  dataBits: 7 | 8;
  stopBits: 1 | 2;
  parity: "none" | "even" | "odd";
  flowControl: "none" | "hardware";
  bufferSize?: number;
};

type SerialPortLike = {
  readable: ReadableStream<Uint8Array> | null;
  writable: WritableStream<Uint8Array> | null;
  open(options: SerialOptions): Promise<void>;
  close(): Promise<void>;
};

type SerialNavigator = Navigator & {
  serial?: { requestPort(): Promise<SerialPortLike> };
};

type InstallPromptEvent = Event & {
  prompt(): Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
};

const EMPTY_COUNTS: Counts = { alarm: 0, supervisory: 0, trouble: 0, other: 0 };

const SAMPLE_EVENTS: SerialEvent[] = [
  { id: -4, category: "other", message: "SYSTEM NORMAL — NODE 01", source: "sample", occurredAt: "2000-01-01T08:00:04" },
  { id: -3, category: "alarm", message: "FIRE ALARM  L01D020  EAST LOBBY SMOKE", source: "sample", occurredAt: "2000-01-01T08:00:28" },
  { id: -2, category: "supervisory", message: "SUPERVISORY  L01M006  SPRINKLER VALVE TAMPER", source: "sample", occurredAt: "2000-01-01T08:00:57" },
  { id: -1, category: "trouble", message: "TROUBLE  NODE 01  AC POWER LOSS", source: "sample", occurredAt: "2000-01-01T08:01:21" },
];



function mergeEvents(current: SerialEvent[], incoming: SerialEvent[]) {
  const byId = new Map<number, SerialEvent>();
  for (const item of current) byId.set(item.id, item);
  for (const item of incoming) byId.set(item.id, item);
  return Array.from(byId.values()).sort((a, b) => a.id - b.id).slice(-1000);
}

function alpha(hex: string, opacity: number) {
  const clean = hex.replace("#", "");
  if (!/^[0-9a-f]{6}$/i.test(clean)) return `rgba(255,255,255,${opacity})`;
  const value = Number.parseInt(clean, 16);
  return `rgba(${(value >> 16) & 255}, ${(value >> 8) & 255}, ${value & 255}, ${opacity})`;
}

function contrastText(hex: string) {
  const clean = hex.replace("#", "");
  if (!/^[0-9a-f]{6}$/i.test(clean)) return "#ffffff";
  const value = Number.parseInt(clean, 16);
  const red = (value >> 16) & 255;
  const green = (value >> 8) & 255;
  const blue = value & 255;
  return (red * 299 + green * 587 + blue * 114) / 1000 > 155 ? "#101417" : "#ffffff";
}

export function PanelStreamDashboard() {
  const [profiles, setProfiles] = useState<PanelProfile[]>([]);
  const [profilesReady, setProfilesReady] = useState(false);
  const screenRef = useRef<HTMLElement>(null);
  const fullscreenButtonRef = useRef<HTMLButtonElement>(null);
  const [streamFullscreen, setStreamFullscreen] = useState(false);
  const [revisionOpen, setRevisionOpen] = useState(false);
  const [verifiedEdit, setVerifiedEdit] = useState<(() => void) | null>(null);
  const [profileDraft, setProfileDraft] = useState<Partial<PanelProfile> | null>(null);
  const [profileBusy, setProfileBusy] = useState(false);
  const connectionRevisionRef = useRef(0);
  const [textOpen, setTextOpen] = useState(false);
  const [textStyle, setTextStyle] = useState({ font: "mono", size: 16, bold: false });
  const [textReady, setTextReady] = useState(false);
  const [commPreset, setCommPreset] = useState("notifier-nfs2-3030");
  const [flowMode, setFlowMode] = useState<"none">("none");
  const [receiveQuality, setReceiveQuality] = useState("Not connected");
  const [canSaveSettings, setCanSaveSettings] = useState(false);
  const serialStopRef = useRef(false);
  const serialBusyRef = useRef(false);
  const retainSerialRef = useRef(false);
  const serialReuseRef = useRef(new SerialReuse<SerialPortLike>());
  const [serialHeld, setSerialHeld] = useState(false);
  const serialCleanupRef = useRef<SerialCleanup | null>(null);
  const serialRxBytesRef = useRef(0);
  const e3ProbeTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const commandWriterRef = useRef<WritableStreamDefaultWriter<Uint8Array> | null>(null);
  const [deliveryConfirmed, setDeliveryConfirmed] = useState(false);
  const [phonePaired, setPhonePaired] = useState(false);
  const [serialVerified, setSerialVerified] = useState(false);
  const [printOpen,setPrintOpen]=useState(false);
  const [reportSource,setReportSource]=useState("session");
  const [instructionsOpen,setInstructionsOpen]=useState(false);
  const [feedbackOpen,setFeedbackOpen]=useState(false);
  const [phoneSetup, setPhoneSetup] = useState(false);
  const [closedE3Panel, setClosedE3Panel] = useState("");
  const [ending, setEnding] = useState(false);
  const [endOptionsOpen,setEndOptionsOpen]=useState(false);
  const [finalOrder,setFinalOrder]=useState<"time"|"device">("time");
  const [finalSaved, setFinalSaved] = useState(false);
  const endingRef = useRef(false);
  const serialDoneRef = useRef<Promise<void>>(Promise.resolve());
  const pendingWritesRef = useRef(new Set<Promise<void>>());
  const feedGenerationRef = useRef(0);
  const clearedThroughRef = useRef(0);
  const [mode, setMode] = useState<"capture" | "companion">("capture");
  const [session, setSession] = useState<MonitorSession | null>(null);
  const [publisherToken, setPublisherToken] = useState("");
  const [events, setEvents] = useState<SerialEvent[]>([]);
  const [counts, setCounts] = useState<Counts>(EMPTY_COUNTS);
  const [preferencesReady,setPreferencesReady]=useState(false);
  const [colorsReady,setColorsReady]=useState(false);
  const [colors, setColors] = useState<SignalColors>(DEFAULT_COLORS);
  const [panelFunctionsVisible,setPanelFunctionsVisible]=useState(true);
  const [ackVisible,setAckVisible]=useState(true);
  const [resetVisible,setResetVisible]=useState(true);
  const [visible, setVisible] = useState<Record<EventCategory, boolean>>({ alarm: true, supervisory: true, trouble: true, other: true });
  const [panelFamily, setPanelFamily] = useState("notifier-nfs2-3030");
  const [joinCode, setJoinCode] = useState("");
  const [baudRate, setBaudRate] = useState("9600");
  const [dataBits, setDataBits] = useState<"7" | "8">("8");
  const [parity, setParity] = useState<"none" | "even" | "odd">("none");
  const [stopBits, setStopBits] = useState<"1" | "2">("1");
  const [connection, setConnection] = useState<ConnectionState>("idle");
  const [statusText, setStatusText] = useState("Ready to configure");
  const [isBusy, setIsBusy] = useState(false);
  const [manualMessage, setManualMessage] = useState("");
  const [reviewingHistory, setReviewingHistory] = useState(false);
  const followStreamRef = useRef(true);
  const [error, setError] = useState("");
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [wiringOpen, setWiringOpen] = useState(false);
  const [wiringSelection, setWiringSelection] = useState("notifier-nfs2-3030");
  const [shareOpen, setShareOpen] = useState(false);
  const [recipientEmail, setRecipientEmail] = useState("");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [refreshMode, setRefreshMode] = useState<RefreshMode>("auto");
  const [refreshing, setRefreshing] = useState(false);
  const [beepEnabled, setBeepEnabled] = useState(false);
  const [audibleAlert, setAudibleAlert] = useState(false);
  const [alertSounds, setAlertSounds] = useState<AlertSounds>(DEFAULT_ALERT_SOUNDS);
  const pendingAlertsRef = useRef<AlertSoundKey[]>([]);
  const stopSoundRef = useRef<(() => void) | null>(null);
  const audioGenerationRef = useRef(0);
  useEffect(() => {
    try { setAlertSounds(readAlertSounds(JSON.parse(localStorage.getItem("sidekick-alert-sounds") ?? "null"))); } catch { /* Use defaults. */ }
  }, []);
  function changeAlertSound(category: AlertSoundKey, sound: SoundId) {
    const next = {...alertSounds, [category]: sound};
    setAlertSounds(next);
    try { localStorage.setItem("sidekick-alert-sounds", JSON.stringify(next)); } catch { /* Applies for this visit. */ }
  }
  const [report,setReport]=useState<ReportSettings>(defaultReport);
  const folderRef=useRef<ReportFolder|null>(null);
  const [folderName,setFolderName]=useState('');
  const [reportStatus,setReportStatus]=useState('');
  const saveRunning=useRef(false);
  const autoSaveRef=useRef<()=>Promise<void>>(async()=>{});
  const [exportBusy, setExportBusy] = useState(false);
  const [installPrompt, setInstallPrompt] = useState<InstallPromptEvent | null>(null);
  const terminalRef = useRef<HTMLDivElement>(null);
  const portRef = useRef<SerialPortLike | null>(null);
  const readerRef = useRef<ReadableStreamDefaultReader<Uint8Array> | null>(null);
  const lastIdRef = useRef(0);
  const publishFailedRef = useRef(false);
  const hasLoadedRef = useRef(false);
  const beepEnabledRef = useRef(false);
  const audioContextRef = useRef<AudioContext | null>(null);

  const [pendingUploads,setPendingUploads]=useState(0);
  const [uploadIssue,setUploadIssue]=useState("");
  const flushRef=useRef<Promise<void>|null>(null);
  const [lastPanelAt,setLastPanelAt]=useState("");
  const [remoteCapture,setRemoteCapture]=useState<{panelConnected:boolean;lastPanelAt:string;pendingUploads:number}|null>(null);
  const captureHealthRef=useRef({panelConnected:false,lastPanelAt:'',pendingUploads:0});
  captureHealthRef.current={panelConnected:connection==='connected',lastPanelAt,pendingUploads};
  const [lastSyncAt,setLastSyncAt]=useState("");
  const [networkOnline,setNetworkOnline]=useState(true);
  const feedCatchingRef=useRef(false);
  const [feedState,setFeedState]=useState<'connecting'|'current'|'catching-up'|'reconnecting'>('connecting');
  const [,setQueueSources]=useState<string[]>([]);
  const [audioReady,setAudioReady]=useState(false);
  const activeCode = session?.code ?? "";
  useEffect(()=>{
    const update=()=>{setNetworkOnline(navigator.onLine);if(!navigator.onLine){setDeliveryConfirmed(false);setFeedState('reconnecting');}};
    update();window.addEventListener('online',update);window.addEventListener('offline',update);
    return()=>{window.removeEventListener('online',update);window.removeEventListener('offline',update);};
  },[]);
  const joiningRef = useRef(false);
  const controlsPanel = mode === "capture" ? (session ? commPreset : panelFamily) : session?.panelFamily ?? "";
  const e3PanelKey = `${activeCode}:${controlsPanel}`;
  useEffect(() => { setClosedE3Panel(""); }, [e3PanelKey]);
  useEffect(() => { endingRef.current = false; setEnding(false); setFinalSaved(Boolean(activeCode && window.sessionStorage.getItem("signal-tracker-final-saved") === activeCode)); }, [activeCode]);
  useEffect(() => {
    const manifest = document.querySelector<HTMLLinkElement>('link[rel="manifest"]');
    if (manifest) manifest.href = mode === "companion" ? `/sidekick.webmanifest${activeCode ? `?session=${activeCode}` : ""}` : "/manifest.webmanifest";
    document.title = (mode === "companion" ? "SideKick" : "Signal Tracker") + " · Beta Version";
    const title = document.querySelector<HTMLMetaElement>('meta[name="apple-mobile-web-app-title"]');
    if (title) title.content = mode === "companion" ? "SideKick" : "Signal Tracker";
  }, [mode, activeCode]);

  const storedProfile = profiles.find(p => p.id === commPreset);
  const matchesStored = storedProfile && storedProfile.baudRate === baudRate && storedProfile.dataBits === dataBits && storedProfile.parity === parity && storedProfile.stopBits === stopBits && storedProfile.flowMode === flowMode;
  const settingsSaved = Boolean(matchesStored && storedProfile.verified);
  const profileOptions = [...PANEL_OPTIONS.filter(p => p.value !== "other").map(p => ({value:p.value,label:profiles.find(saved=>saved.id===p.value)?.name ?? p.label,verified:profiles.find(saved=>saved.id===p.value)?.verified??false})), ...profiles.filter(p=>!PANEL_OPTIONS.some(o=>o.value===p.id)).map(p=>({value:p.id,label:p.name,verified:p.verified})), {value:"other",label:"Other / manual settings",verified:false}];
  const displayProfileName = (value: string) => profiles.find(p=>p.id===value)?.name ?? panelLabel(value);
  async function loadProfiles() {
    try { const r=await fetch("/api/panel-profiles",{cache:"no-store"});const data=await r.json() as {error?:string;profiles:PanelProfile[]};if(!r.ok)throw Error(data.error);setProfiles(data.profiles);setProfilesReady(true);
      if(session && connection === "idle") {const current=data.profiles.find((p:PanelProfile)=>p.id===commPreset);if(current){setBaudRate(current.baudRate);setDataBits(current.dataBits);setParity(current.parity);setStopBits(current.stopBits);setFlowMode(current.flowMode);}} }
    catch(e){setError(e instanceof Error?e.message:"Unable to load panel profiles.");}
  }
  useEffect(() => { void loadProfiles(); }, []);
  function applyCommPreset(value: string, _restore = false) {
    if(value === "manual" || value === "other") { setProfileDraft({}); return; }
    setCommPreset(value); setCanSaveSettings(false);
    const saved=profiles.find(p=>p.id===value);
    const preset=COMM_PRESETS.find(p=>p.value===value);
    setBaudRate(saved?.baudRate ?? (isE3(value)?"9600":preset?.baud.length===1?String(preset.baud[0]):""));
    setDataBits(saved?.dataBits ?? String(preset?.bits??8) as "7"|"8"); setParity(saved?.parity??preset?.parity??"none");setStopBits(saved?.stopBits??"1");setFlowMode(saved?.flowMode??preset?.flow??"none");
  }
  useEffect(() => { if(session?.code && profilesReady) applyCommPreset(session.panelFamily); }, [session?.code,profilesReady]);
  useEffect(() => { setCanSaveSettings(false); }, [baudRate,dataBits,parity,stopBits,flowMode]);
  function openProfileEditor(id:string, confirmed = false) {
    if (!confirmed && profiles.find(p=>p.id===id)?.verified) { setVerifiedEdit(() => () => openProfileEditor(id,true)); return; }
    if(id === "other") {setProfileDraft({});return;}
    const saved=profiles.find(p=>p.id===id);
    const preset=COMM_PRESETS.find(p=>p.value===id);
    setProfileDraft(saved ?? {id,name:displayProfileName(id),revision:0,baudRate:isE3(id)?"9600":preset?.baud.length===1?String(preset.baud[0]):"",dataBits:String(preset?.bits??8) as "7"|"8",parity:preset?.parity??"none",stopBits:"1",flowMode:preset?.flow??"none"});
  }
  function changeConnectionSetting(apply:()=>void) {
    if(settingsSaved) setVerifiedEdit(()=>apply); else apply();
  }
  function acceptProfile(profile:PanelProfile) {
    setProfiles(current=>[...current.filter(p=>p.id!==profile.id),profile]);setProfileDraft(null);
    if(!session)setPanelFamily(profile.id);
    setCommPreset(profile.id);setBaudRate(profile.baudRate);setDataBits(profile.dataBits);setParity(profile.parity);setStopBits(profile.stopBits);setFlowMode(profile.flowMode);setCanSaveSettings(false);
  }
  async function saveCommSettings(verify = false) {
    if(commPreset === "manual" || commPreset === "other") {setProfileDraft({baudRate,dataBits,parity,stopBits,flowMode});return;}
    setProfileBusy(true);
    try {
      const r=await fetch("/api/panel-profiles",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({id:commPreset,name:displayProfileName(commPreset),baudRate,dataBits,parity,stopBits,flowMode,expectedRevision:verify?connectionRevisionRef.current:storedProfile?.revision??0,confirmVerified:verify})});
      const data=await r.json() as {error?:string;profile:PanelProfile};if(!r.ok)throw Error(data.error);
      setProfiles(current=>[...current.filter(p=>p.id!==data.profile.id),data.profile]);connectionRevisionRef.current=data.profile.revision;
    }catch(e){setError(e instanceof Error?e.message:"Unable to save settings.");}finally{setProfileBusy(false);}
  }
  useEffect(() => {
    try { const saved = JSON.parse(localStorage.getItem("signal-tracker-text") ?? "null"); if (saved && FONT_CHOICES.some(f => f.value === saved.font) && [12,14,16,18,20,24,28,32].includes(saved.size) && typeof saved.bold === "boolean") setTextStyle(saved); } catch { /* Use readable defaults. */ }
    setTextReady(true);
  }, []);
  useEffect(() => { if (textReady) { try { localStorage.setItem("signal-tracker-text", JSON.stringify(textStyle)); } catch { /* Display settings still apply for this visit. */ } } }, [textStyle, textReady]);
  const displayedEvents = useMemo(() => {
    const source = session ? events : SAMPLE_EVENTS;
    return source.map((event,index)=>{const category=streamCategory(event,source[index-1]?.message,source[index+1]?.message);return {...event,streamCategory:category,signalColor:streamSignalColor(category,event.message,source[index-1]?.message,session?.panelFamily)};}).filter(event=>event.streamCategory === "system-reset" ? resetVisible : event.streamCategory === "acknowledged" ? ackVisible : event.streamCategory in THEMED_STREAM_LABELS ? panelFunctionsVisible : visible[event.streamCategory as EventCategory]);
  }, [events, session, visible, resetVisible, ackVisible, panelFunctionsVisible]);

  const previewAudioRef=useRef<HTMLAudioElement|null>(null);
  const previewGenerationRef=useRef(0);
  const previewSound=useCallback(async(sound:SoundId)=>{
    const generation=++previewGenerationRef.current;
    previewAudioRef.current?.pause();
    if(sound==='none')return;
    const audio=previewAudioRef.current ?? new Audio();
    previewAudioRef.current=audio;
    audio.src=`/sounds/${sound}.wav?v=${ALERT_AUDIO_REVISION}`;
    audio.volume=1;
    try { await audio.play(); }
    catch { if(generation===previewGenerationRef.current)setError('Sound preview could not play. Check phone media volume, then tap Preview again.'); }
  },[]);
  useEffect(()=>()=>{previewGenerationRef.current++;previewAudioRef.current?.pause();},[]);
  const prepareAudio=useCallback(async()=>{
    try {
      const Constructor=window.AudioContext ?? (window as typeof window & {webkitAudioContext?:typeof AudioContext}).webkitAudioContext;
      if(!Constructor)throw new Error('Audio is unavailable');
      const context=audioContextRef.current && audioContextRef.current.state!=='closed'?audioContextRef.current:new Constructor();
      audioContextRef.current=context;
      setAudioReady(false);
      const resumed=context.state==='running'?Promise.resolve():context.resume();
      await Promise.all([resumed,...[...new Set(Object.values(alertSounds))].filter(id=>id!=='none').map(id=>loadAlertSound(context,id))]);
      setAudioReady(context.state==='running');
      context.onstatechange=()=>setAudioReady(context.state==='running');
    }catch{setAudioReady(false);}
  },[alertSounds]);
  useEffect(()=>{
    if(mode!=='companion'||!beepEnabled){setAudioReady(false);return;}
    void prepareAudio();
    const prepare=()=>void prepareAudio();
    window.addEventListener('pointerdown',prepare,{once:true});
    return()=>window.removeEventListener('pointerdown',prepare);
  },[mode,beepEnabled,prepareAudio]);
  const playBeep = useCallback(async (sound: SoundId = 'two-tone') => {
    if(sound === "none") return;
    const generation = ++audioGenerationRef.current;
    stopSoundRef.current?.();
    try {
      const AudioContextConstructor = window.AudioContext ?? (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AudioContextConstructor) throw new Error("Audio is unavailable in this browser.");
      const context = !audioContextRef.current || audioContextRef.current.state === "closed" ? new AudioContextConstructor() : audioContextRef.current;
      audioContextRef.current = context;
      if (context.state !== "running") await context.resume();
      const buffer = await loadAlertSound(context, sound);
      if (generation !== audioGenerationRef.current) return;
      stopSoundRef.current = scheduleAlertSound(context, sound, buffer);
    } catch { setError("Audio could not start. Tap Preview to test sound, and check your phone volume."); }
  }, []);
  useEffect(() => () => { audioGenerationRef.current++; stopSoundRef.current?.(); void audioContextRef.current?.close(); }, []);

  useEffect(() => {
    if ("serviceWorker" in navigator) void navigator.serviceWorker.register("/sw.js").catch(() => undefined);
    const onInstallPrompt = (event: Event) => {
      event.preventDefault();
      setInstallPrompt(event as InstallPromptEvent);
    };
    window.addEventListener("beforeinstallprompt", onInstallPrompt);
    const timer = window.setTimeout(() => {
      try {
      const saved = window.localStorage.getItem("signal-tracker-colors") ?? window.localStorage.getItem("panelstream-colors");
      if (saved) {
        try {
          setColors({ ...DEFAULT_COLORS, ...(JSON.parse(saved) as Partial<SignalColors>) });
        } catch {
          window.localStorage.removeItem("signal-tracker-colors");
        }
      }
      } catch { /* Browser storage may be unavailable. */ }
      setColorsReady(true);
      const url = new URL(window.location.href);
      let savedPair = "";
      try { savedPair = localStorage.getItem("sidekick-paired-session") ?? ""; } catch {}
      const requestedCode = normalizeSessionCode(url.searchParams.get("session") || (url.searchParams.get("mode") !== "capture" ? savedPair : ""));
      if (url.searchParams.get("mode") === "companion" || requestedCode) {
        setMode("companion");
        setJoinCode(requestedCode);
      }
    }, 0);
    return () => {
      window.clearTimeout(timer);
      window.removeEventListener("beforeinstallprompt", onInstallPrompt);
    };
  }, []);

  useEffect(() => {
    const stopCapture = () => {
      retainSerialRef.current = false;
      serialStopRef.current = true;
      void serialReuseRef.current.release().catch(() => {});
      commandWriterRef.current = null;
      void serialCleanupRef.current?.cancelRead();
    };
    window.addEventListener("pagehide", stopCapture);
    return () => { window.removeEventListener("pagehide", stopCapture); stopCapture(); };
  }, []);

  useEffect(() => {
    if(colorsReady)try { window.localStorage.setItem("signal-tracker-colors", JSON.stringify(colors)); } catch {}
  }, [colors,colorsReady]);

  useEffect(()=>{
    try {
      const saved=JSON.parse(localStorage.getItem('signal-tracker-preferences') ?? 'null');
      if(saved && typeof saved==='object') {
        if(typeof saved.beepEnabled==='boolean'){setBeepEnabled(saved.beepEnabled);beepEnabledRef.current=saved.beepEnabled;}
        if(saved.refreshMode==='auto' || saved.refreshMode==='manual')setRefreshMode(saved.refreshMode);
        if(typeof saved.ackVisible==='boolean')setAckVisible(saved.ackVisible);
        if(typeof saved.resetVisible==='boolean')setResetVisible(saved.resetVisible);
        if(typeof saved.panelFunctionsVisible==='boolean')setPanelFunctionsVisible(saved.panelFunctionsVisible);
        if(saved.visible)setVisible(current=>Object.fromEntries(EVENT_CATEGORIES.map(category=>[category,typeof saved.visible[category]==='boolean'?saved.visible[category]:current[category]])) as Record<EventCategory,boolean>);
        const r=saved.report;
        if(r && typeof r==='object')setReport(current=>({...current,
          ...(r.format==='xlsx'||r.format==='pdf'?{format:r.format}:{}),
          ...(r.saving==='auto'||r.saving==='manual'?{saving:r.saving}:{}),
          ...(r.order==='time'||r.order==='device'?{order:r.order}:{}),
          ...(Array.isArray(r.categories)?{categories:r.categories.filter((c:EventCategory)=>EVENT_CATEGORIES.includes(c))}:{}),
        }));
      }
    } catch { /* Keep defaults when saved preferences are invalid. */ }
    setPreferencesReady(true);
  },[]);
  useEffect(()=>{
    if(!preferencesReady)return;
    try {localStorage.setItem('signal-tracker-preferences',JSON.stringify({beepEnabled,refreshMode,visible,ackVisible,resetVisible,panelFunctionsVisible,report:{format:report.format,saving:report.saving,order:report.order,categories:report.categories}}));}catch{}
  },[preferencesReady,beepEnabled,refreshMode,visible,ackVisible,resetVisible,panelFunctionsVisible,report.format,report.saving,report.order,report.categories]);
  useEffect(()=>{
    if(!beepEnabled || mode!=='companion')return;
    const unlock=()=>{
      const Constructor=window.AudioContext ?? (window as typeof window & {webkitAudioContext?:typeof AudioContext}).webkitAudioContext;
      if(!Constructor)return;
      try {const context=audioContextRef.current && audioContextRef.current.state!=='closed'?audioContextRef.current:new Constructor();audioContextRef.current=context;void context.resume().catch(()=>{});}catch{}
    };
    window.addEventListener('pointerdown',unlock);window.addEventListener('keydown',unlock);
    return ()=>{window.removeEventListener('pointerdown',unlock);window.removeEventListener('keydown',unlock);};
  },[beepEnabled,mode]);

  useEffect(() => {
    beepEnabledRef.current = beepEnabled;
  }, [beepEnabled]);

  useEffect(() => {
    if (!audibleAlert || !beepEnabled || mode !== "companion") {
      pendingAlertsRef.current = [];
      audioGenerationRef.current++;
      stopSoundRef.current?.();
      return;
    }
    let stopped = false;
    let timer: number | undefined;
    const playNext = async () => {
      const pending = pendingAlertsRef.current;
      if (!pending.length) { setAudibleAlert(false); return; }
      let category = pending.shift()!;
      while(alertSounds[category] === "none" && pending.length) category=pending.shift()!;
      if(alertSounds[category] === "none") {setAudibleAlert(false);return;}
      await playBeep(alertSounds[category]);
      if (!stopped) timer = window.setTimeout(() => void playNext(), 2600);
    };
    void playNext();
    return () => { stopped = true; window.clearTimeout(timer); audioGenerationRef.current++; stopSoundRef.current?.(); };
  }, [audibleAlert, beepEnabled, mode, alertSounds, playBeep]);

  useEffect(() => {
    if (followStreamRef.current && terminalRef.current) terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
  }, [displayedEvents]);

  useEffect(() => { followStreamRef.current = true; setReviewingHistory(false); }, [activeCode]);

  const loadSession = useCallback(async (code: string, since = 0, announce = false) => {
    const generation = feedGenerationRef.current;
    const response = await fetch(`/api/sessions/${encodeURIComponent(code)}?since=${since}`, { cache: "no-store", signal: AbortSignal.timeout(10000) });
    const payload = (await response.json()) as { error?: string; session?: MonitorSession; events?: SerialEvent[]; counts?: Counts; queueSources?: string[] };
    if (!response.ok || !payload.session) throw new Error(payload.error || "Unable to open that session.");
    if (generation !== feedGenerationRef.current) return payload.session;
    setSession(payload.session);
    setLastSyncAt(new Date().toISOString());
    if(payload.queueSources)setQueueSources(payload.queueSources);
    const incoming = payload.events ?? [];
    if (incoming.length) {
      const newSignals = incoming.filter(item => item.id > lastIdRef.current);
      lastIdRef.current = Math.max(lastIdRef.current, ...incoming.map((item) => item.id));
      setEvents((current) => mergeEvents(current, incoming).filter(item => item.id > clearedThroughRef.current));
      if (announce && hasLoadedRef.current && beepEnabledRef.current) {
        pendingAlertsRef.current.push(...newSignals.map(eventSoundKey));
        if (newSignals.length) setAudibleAlert(true);
      }
    }
    if (payload.counts) setCounts(payload.counts);
    hasLoadedRef.current = true;
    feedCatchingRef.current=since>0 && incoming.length>=500;
    setFeedState(feedCatchingRef.current?'catching-up':'current');
    return payload.session;
  }, []);

  useEffect(() => {
    const url = new URL(window.location.href);
    if (url.searchParams.get("session") || url.searchParams.get("mode") === "companion") return;
    try { if (localStorage.getItem("sidekick-paired-session") && url.searchParams.get("mode") !== "capture") return; } catch {}
    const timer = window.setTimeout(() => {
      const saved = window.localStorage.getItem("signal-tracker-publisher") ?? window.sessionStorage.getItem("signal-tracker-publisher");
      if (!saved) return;
      try {
        const restored = JSON.parse(saved) as { session?: MonitorSession; publisherToken?: string; report?: ReportSettings };
        if (!restored.session?.code || !restored.publisherToken) throw new Error("Invalid saved session");
        setMode("capture");
        setReport(restored.report ? {...defaultReport,...restored.report} : {...defaultReport,name:restored.session.name});
        if(restored.session.isLive && restored.report?.saving==='auto') setReportStatus('Automatic saving paused after reload. Choose a folder to resume automatic saving.');
        setSession(restored.session);
        setPublisherToken(restored.publisherToken);
        hasLoadedRef.current = false;
        void loadSession(restored.session.code, 0).catch(() => {
          setStatusText("Saved session restored — reconnecting…");
        });
      } catch {
        window.sessionStorage.removeItem("signal-tracker-publisher"); window.localStorage.removeItem("signal-tracker-publisher");

      }
    }, 0);
    return () => window.clearTimeout(timer);
  }, [loadSession]);

  useEffect(() => {
    if (!activeCode) return;
    const interval = 1200;
    let needsResume = mode === "companion";

    let stopped = false;
    let polling = false;
    const poll = async () => {
      if (polling || stopped || (mode === "companion" && (document.hidden || !navigator.onLine))) return;
      if (mode === "companion" && refreshMode === "manual" && !needsResume) return;
      polling = true;
      try {
        await loadSession(activeCode, lastIdRef.current, true);
        if (!stopped && mode === "companion") { needsResume = feedCatchingRef.current; setStatusText(refreshMode === "manual" ? "Manual refresh connected" : "Auto refresh connected"); }
      } catch (pollError) {
        if (!stopped) {
          setFeedState('reconnecting');
          setStatusText("Feed reconnecting…");
          console.error(pollError);
        }
      } finally { polling = false; }
    };
    const resume = () => { if (document.hidden) return; needsResume = true; void poll(); };
    const timer = window.setInterval(() => void poll(), interval);
    window.addEventListener("online", resume);
    window.addEventListener("pageshow", resume);
    window.addEventListener("focus", resume);
    document.addEventListener("visibilitychange", resume);
    void poll();
    return () => {
      stopped = true;
      window.clearInterval(timer);
      window.removeEventListener("online", resume);
      window.removeEventListener("pageshow", resume);
      window.removeEventListener("focus", resume);
      document.removeEventListener("visibilitychange", resume);
    };
  }, [activeCode, loadSession, mode, refreshMode]);

  // A successful server connection alone never proves laptop-to-phone delivery.
  useEffect(() => {
    setDeliveryConfirmed(false);
    setPhonePaired(false);
    if (!activeCode || (mode === "capture" && !publisherToken)) return;
    let stopped = false;
    let busy = false;
    let confirmedAt = 0;
    let probe = mode === "capture" ? randomId() : "";
    const clientId = randomId();
    const check = async () => {
      if (busy || stopped) return;
      if (!navigator.onLine || document.hidden) { confirmedAt = 0; setDeliveryConfirmed(false); return; }
      busy = true;
      try {
        const response = await fetch(`/api/sessions/${activeCode}/delivery`, {
          method: "POST", cache: "no-store", signal: AbortSignal.timeout(4000),
          headers: { "content-type": "application/json", ...(mode === "capture" ? { "x-publisher-token": publisherToken } : {}) },
          body: JSON.stringify({ role: mode, probe, clientId, eventId: lastIdRef.current, ...captureHealthRef.current }),
        });
        if (!response.ok) throw new Error("Delivery unconfirmed");
        const result = await response.json() as { delivered: boolean; phonePaired?: boolean; probe?: string; captureStatus?:{panelConnected:boolean;lastPanelAt:string;pendingUploads:number} };
        if (stopped || document.hidden || !navigator.onLine) return;
        if (mode === "companion") {probe = result.probe ?? "";if(result.captureStatus)setRemoteCapture(result.captureStatus);}
        const confirmed=result.delivered && (mode==='capture'?captureHealthRef.current.pendingUploads===0:!(result.captureStatus?.pendingUploads));
        confirmedAt = confirmed ? Date.now() : 0;
        setDeliveryConfirmed(confirmed);
        if (result.phonePaired || mode === "companion") setPhonePaired(true);
      } catch { if (!stopped) { confirmedAt = 0; setDeliveryConfirmed(false); } }
      finally { busy = false; }
    };
    const invalidate = () => { confirmedAt = 0; setDeliveryConfirmed(false); if (!document.hidden) void check(); };
    void check();
    const timer = window.setInterval(() => void check(), 3000);
    const expiry = window.setInterval(() => { if (Date.now() - confirmedAt > 6000) setDeliveryConfirmed(false); }, 1000);
    window.addEventListener("offline", invalidate);
    document.addEventListener("visibilitychange", invalidate);
    return () => { stopped = true; window.clearInterval(timer); window.clearInterval(expiry); window.removeEventListener("offline", invalidate); document.removeEventListener("visibilitychange", invalidate); };
  }, [activeCode, mode, publisherToken]);

  async function joinSession(codeOverride?: string) {
    const code = normalizeSessionCode(codeOverride ?? joinCode);
    if (code.length !== 8) {
      setError("Enter the pairing code shown on the laptop.");
      return;
    }
    if (joiningRef.current) return;
    joiningRef.current = true;
    setIsBusy(true);
    setError("");
    const attemptGeneration = ++feedGenerationRef.current;
    try {
      clearedThroughRef.current = 0;
      setEvents([]);
      setCounts(EMPTY_COUNTS);
      setFinalSaved(false);
      setAudibleAlert(false);
      lastIdRef.current = 0;
      hasLoadedRef.current = false;
      await loadSession(code, 0);
      if (attemptGeneration !== feedGenerationRef.current) return;
      try { localStorage.setItem("sidekick-paired-session", code); } catch {}
      setJoinCode(code);
      setMode("companion");
      setStatusText("Real-time feed connected");
      const url = new URL(window.location.href);
      url.searchParams.set("mode", "companion");
      url.searchParams.set("session", code);
      url.searchParams.delete("pair");
      window.history.replaceState({}, "", url);
    } catch (joinError) {
      if (attemptGeneration !== feedGenerationRef.current) return;
      setStatusText("Reconnecting to your paired feed…");
      setSession(null);
      setError(joinError instanceof Error ? joinError.message : "Unable to join that session.");
    } finally {
      joiningRef.current = false;
      setIsBusy(false);
    }
  }

  useEffect(() => {
    if (!joinCode || mode !== "companion" || session) return;
    const retry = () => { if (!document.hidden && navigator.onLine) void joinSession(joinCode); };
    const timer = window.setTimeout(retry, 0);
    const interval = window.setInterval(retry, 5000);
    window.addEventListener("online", retry);
    window.addEventListener("pageshow", retry);
    document.addEventListener("visibilitychange", retry);
    return () => {
      window.clearTimeout(timer);window.clearInterval(interval);
      window.removeEventListener("online", retry);window.removeEventListener("pageshow", retry);
      document.removeEventListener("visibilitychange", retry);
    };
    // Joining is serialized; failures retain the pairing target for automatic retry.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [joinCode, mode, Boolean(session)]);

  const createSession = async (event: FormEvent) => {
    event.preventDefault();
    if(session && mode==='capture' && (await pendingCapture(session.code)).length){setError('Upload saved captures before starting another session.');return;}
    setIsBusy(true);
    setError("");
    feedGenerationRef.current++;
    try {
      validateReport(report);
      if(report.saving==='auto' && !folderRef.current) await chooseReportFolder();
      const response = await fetch("/api/sessions", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ name: report.name.trim(), panelFamily }),
      });
      const payload = (await response.json()) as { error?: string; session?: MonitorSession; publisherToken?: string; report?: ReportSettings };
      if (!response.ok || !payload.session || !payload.publisherToken) throw new Error(payload.error || "Unable to start a session.");
      setSession(payload.session);
      setPublisherToken(payload.publisherToken);
      window.localStorage.setItem("signal-tracker-publisher", JSON.stringify({ session: payload.session, publisherToken: payload.publisherToken, report }));
      clearedThroughRef.current = 0;
      setEvents([]);
      setCounts(EMPTY_COUNTS);
      setFinalSaved(false);
      setAudibleAlert(false);
      lastIdRef.current = 0;
      hasLoadedRef.current = true;
      setStatusText("Session live — connect the serial port");
      window.setTimeout(() => guideTo(document.querySelector<HTMLElement>('[data-setup="serial"]')), 100);
    } catch (sessionError) {
      setError(sessionError instanceof Error ? sessionError.message : "Unable to start a session.");
    } finally {
      setIsBusy(false);
    }
  };

  const flushCapture = useCallback(async () => {
    if(!session || !publisherToken || mode!=="capture")return;
    if(flushRef.current)return flushRef.current;
    const code=session.code,generation=feedGenerationRef.current;
    const run=(async()=>{
      try {
        while(true) {
          const batches=await pendingCapture(code);
          if(generation!==feedGenerationRef.current)return;
          setPendingUploads(batches.reduce((sum,b)=>sum+b.events.length,0));
          if(!batches.length){publishFailedRef.current=false;setUploadIssue("");return;}
          publishFailedRef.current=true;setDeliveryConfirmed(false);
          if(!navigator.onLine){setUploadIssue("Offline — captures saved on this laptop");return;}
          const batch=batches[0];
          const response=await fetch(`/api/sessions/${code}/events`,{method:'POST',signal:AbortSignal.timeout(15000),headers:{'content-type':'application/json','x-publisher-token':publisherToken},body:JSON.stringify({batchId:batch.batchId,events:batch.events})});
          if(!response.ok)throw new Error(response.status===403?'Publisher authorization needs attention; saved captures are retained':response.status===409?'Session cannot accept saved captures; download the pending capture file':'Upload interrupted — saved captures will retry automatically');
          const receipt=await response.json() as {accepted?:boolean;batchId?:string};
          if(receipt.accepted!==true || receipt.batchId!==batch.batchId)throw new Error('Upload acknowledgement missing — saved captures retained for retry');
          await removeCapture(batch.id!);
          if(generation!==feedGenerationRef.current)return;
          setLastSyncAt(new Date().toISOString());
          // Read via the ordered feed; an upload response must not skip unseen events.
          await loadSession(code,lastIdRef.current);
        }
      }catch(error){publishFailedRef.current=true;setDeliveryConfirmed(false);setUploadIssue(error instanceof Error?error.message:'Saved captures awaiting upload');}
    })();
    flushRef.current=run;
    try {await run;}finally{flushRef.current=null;}
  },[session?.code,publisherToken,mode,loadSession]);
  useEffect(()=>{
    if(mode!=="capture" || !activeCode || !publisherToken)return;
    const retry=()=>void flushCapture();retry();
    const timer=window.setInterval(retry,5000);window.addEventListener('online',retry);
    return()=>{window.clearInterval(timer);window.removeEventListener('online',retry);};
  },[activeCode,publisherToken,mode,flushCapture]);
  const publishMessages = useCallback(async (messages: string[], source: "serial" | "manual" = "serial") => {
    if (!session || !publisherToken || !session.isLive) return;
    const prepared=messages.map(message=>message.trim()).filter(Boolean).map(message=>({message,category:classifySerialMessage(message),source,occurredAt:laptopTimestamp()}));
    if(!prepared.length)return;
    const task=saveCapture(session.code,prepared);
    pendingWritesRef.current.add(task);
    try {
      await task;
      setPendingUploads(value=>value+prepared.length);
      void flushCapture();
    } catch {
      throw new Error('Local capture storage failed. Capture stopped to avoid silently losing events. Free device storage and retry.');
    } finally {pendingWritesRef.current.delete(task);}
  },[session,publisherToken,flushCapture]);
  async function downloadPendingCapture() {
    if(!session)return;
    const batches=await pendingCapture(session.code);
    const blob=new Blob([JSON.stringify({session:session.code,batches},null,2)],{type:'application/json'});
    const url=URL.createObjectURL(blob),link=document.createElement('a');link.href=url;link.download=`Signal-Tracker-${session.code}-pending.json`;link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
  }

  async function connectSerial() {
    if (serialBusyRef.current || endingRef.current || session?.isLive === false) return;
    if (!session) { setError("Start a monitoring session first."); return; }
    if (!profilesReady) { setError("Load saved panel profiles before connecting."); return; }
    connectionRevisionRef.current = storedProfile?.revision ?? 0;
    if (!baudRate || !Number.isFinite(Number(baudRate)) || Number(baudRate) <= 0) { setError("Select the baud rate configured at the panel."); return; }
    const serial = (navigator as SerialNavigator).serial;
    if (!serial) { setConnection("unavailable"); setError("Direct serial capture requires desktop Chrome or Microsoft Edge over HTTPS."); return; }
    serialBusyRef.current = true;
    retainSerialRef.current = false;
    const settingsKey = JSON.stringify([baudRate, dataBits, stopBits, parity]);
    const cleanup = new SerialCleanup();
    serialCleanupRef.current = cleanup;
    setLastPanelAt("");
    setSerialVerified(false); setConnection("connecting"); setError(""); setCanSaveSettings(false); setReceiveQuality("Waiting for port selection"); serialStopRef.current = false; serialRxBytesRef.current = 0;
    let finishSerial!: () => void;
    serialDoneRef.current = new Promise<void>(resolve => { finishSerial = resolve; });
    let port: SerialPortLike | null = null;
    let reader: ReadableStreamDefaultReader<Uint8Array> | null = null;
    let writer: WritableStreamDefaultWriter<Uint8Array> | null = null;
    let opened = false;
    let qualityTimer: ReturnType<typeof setTimeout> | undefined;
    try {
      port = await serial.requestPort();
      if (serialStopRef.current) return;
      // A failed close must be retried, not forgotten before opening another handle.
      if (portRef.current) {
        await portRef.current.close();
        portRef.current = null;
      }
      if (serialStopRef.current) return;
      const reused = await serialReuseRef.current.take(port, settingsKey);
      setSerialHeld(false);
      if (!reused) await port.open({ baudRate: Number(baudRate), dataBits: Number(dataBits) as 7 | 8, stopBits: Number(stopBits) as 1 | 2, parity, flowControl: "none", bufferSize: 65536 });
      opened = true; portRef.current = port;
      if (!port.readable) throw new Error("The selected port did not provide a readable stream.");
      reader = port.readable.getReader(); readerRef.current = reader; cleanup.reader = reader;
      if (isE3(session.panelFamily)) {
        if (!port.writable) throw new Error("E3 controls require a writable serial port.");
        writer = port.writable.getWriter();
        commandWriterRef.current = writer; cleanup.writer = writer;
      }
      setConnection("connected"); setStatusText(`Serial open at ${baudRate} baud`); setReceiveQuality("Port open — waiting for panel data");
      let printable = 0, bad = 0, controls = 0;
      qualityTimer = setTimeout(() => { if (!printable && !bad) setReceiveQuality(isE3(session.panelFamily) ? "No E3 bytes received. Send the firmware query below; if it also gets no reply, check TB6 TX/RX/GND, the selected COM port, SW2-5 and the panel baud." : "No text received. A quiet panel is inconclusive; check its output, wiring and serial settings."); }, 15000);
      const decoder = new TextDecoder(); let buffer = "";
      const publish = publishMessages;
      while (!serialStopRef.current) {
        const { value, done } = await reader.read(); if (done) break;
        if (!value?.length) continue;
        serialRxBytesRef.current += value.length;
        setLastPanelAt(new Date().toISOString());
        if (e3ProbeTimerRef.current) { clearTimeout(e3ProbeTimerRef.current); e3ProbeTimerRef.current = null; }
        const q = inspectSerialBytes(value); printable += q.printable; bad += q.bad; controls += q.controls;
        const readable = printable >= 32 && bad / (printable + bad) < 0.02;
        setCanSaveSettings(readable);
        if (!readable) setSerialVerified(false);
        const byteCount = `${serialRxBytesRef.current.toLocaleString()} bytes received`;
        setReceiveQuality(bad / Math.max(1, printable + bad) >= 0.02 ? `Unexpected bytes — check baud, parity, data bits and output format · ${byteCount}` : readable ? `Readable text received — verify a complete panel event before saving · ${byteCount}` : controls && !printable ? `Control bytes received — no panel text yet · ${byteCount}` : `Receiving bytes — waiting for a longer sample · ${byteCount}`);
        buffer += decoder.decode(value, { stream: true }).replace(/[\x02\x03\x05\x06\x11\x13]/g, "");
        const chunks = buffer.split(/\r\n|\n|\r/); buffer = chunks.pop() ?? "";
        if (readable && chunks.some(line => line.trim().length > 0)) setSerialVerified(true);
        if (chunks.length) await publish(chunks);
        if (buffer.length > 65536) { await publish([buffer]); buffer = ""; }
      }
      if (buffer.trim()) await publish([buffer]);
    } catch (serialError) {
      const message = serialError instanceof Error ? serialError.message : "Serial connection failed.";
      retainSerialRef.current = false;
      if (!/cancel|chooser/i.test(message)) setError(`${message} ${!opened ? "The browser/operating system could not open this COM port. Close other Signal Tracker tabs and serial programs, then retry. This is not a panel-output or baud-rate error." : "Serial capture stopped. Check the adapter connection and retry."}`);
    } finally {
      clearTimeout(qualityTimer);
      if (e3ProbeTimerRef.current) { clearTimeout(e3ProbeTimerRef.current); e3ProbeTimerRef.current = null; }
      commandWriterRef.current = null;
      let closeFailed = false;
      try {
        if (opened && port) {
          if (retainSerialRef.current) {
            await cleanup.releaseStreams();
            serialReuseRef.current.retain(port, settingsKey);
            setSerialHeld(true);
          } else await cleanup.close(port);
          portRef.current = null;
        }
      } catch (closeError) {
        closeFailed = true;
        setError(`The serial port did not close cleanly: ${closeError instanceof Error ? closeError.message : "unknown error"}. Select the serial port again to retry releasing it. Close any other tab or program using this port.`);
      } finally {
        readerRef.current = null;
        serialCleanupRef.current = null;
        serialBusyRef.current = false;
        setSerialVerified(false); setConnection("idle");
        setStatusText(closeFailed ? "Serial release needs retry" : retainSerialRef.current ? "Logging stopped — serial port ready for reuse" : "Serial disconnected");
        setReceiveQuality(closeFailed ? "Port release failed — select the serial port to retry" : "Disconnected — ready to reconnect");
        setCanSaveSettings(false);
        finishSerial();
      }
    }
  }
  async function testE3SerialInput() {
    const writer = commandWriterRef.current;
    if (!session || !isE3(session.panelFamily) || !isE3(commPreset) || connection !== "connected" || !writer || serialStopRef.current) {
      setError("Connect the selected Gamewell-FCI E3 serial port before running the input test.");
      return;
    }
    const bytesBefore = serialRxBytesRef.current;
    setError("");
    setReceiveQuality("E3 firmware query sent (V + CR) — waiting for reply");
    try {
      await writer.write(E3_FIRMWARE_QUERY);
      if (e3ProbeTimerRef.current) clearTimeout(e3ProbeTimerRef.current);
      e3ProbeTimerRef.current = setTimeout(() => {
        e3ProbeTimerRef.current = null;
        if (serialRxBytesRef.current === bytesBefore) setReceiveQuality("No reply to E3 firmware query. Verify the adapter TX reaches panel RxD, panel TxD reaches adapter RX, GND is common, and the panel baud matches SW2-5/CAMWorks.");
      }, 5000);
    } catch (probeError) {
      setError(probeError instanceof Error ? `E3 test could not be sent: ${probeError.message}` : "E3 test could not be sent.");
    }
  }
  async function disconnectSerial(retainPort = false) {
    retainSerialRef.current = retainPort;
    serialStopRef.current = true;
    setSerialVerified(false);
    commandWriterRef.current = null;
    await serialCleanupRef.current?.cancelRead();
    await serialDoneRef.current;
    if (!retainPort) {
      try { await serialReuseRef.current.release(); setSerialHeld(false); }
      catch (error) { setError(`Unable to release the retained serial port: ${error instanceof Error ? error.message : "unknown error"}`); return false; }
    }
    if (portRef.current) {
      try { await portRef.current.close(); portRef.current = null; }
      catch (error) {
        setError(`Unable to release the serial port: ${error instanceof Error ? error.message : "unknown error"}. Retry ending the session or selecting the serial port to release it.`);
        return false;
      }
    }
    return true;
  }

  async function sendManualMessage(event: FormEvent) {
    event.preventDefault();
    if (!manualMessage.trim() || endingRef.current || !session?.isLive) return;
    setError("");
    try {
      await publishMessages([manualMessage], "manual");
      setManualMessage("");
    } catch (messageError) {
      setError(messageError instanceof Error ? messageError.message : "Test message failed.");
    }
  }

  function clearFeed() {
    if (!session) return;
    clearedThroughRef.current = lastIdRef.current;
    setEvents([]);
    followStreamRef.current = true;
    setReviewingHistory(false);
    setStatusText("Screen cleared — all signals retained for the session report");
  }

  function emailInvite(event: FormEvent) {
    event.preventDefault();
    const email = recipientEmail.trim();
    if (!/^\S+@\S+\.\S+$/.test(email)) {
      setError("Enter the email address for the person you want to invite.");
      return;
    }
    const subject = "Signal Tracker website invitation";
    const body = `You're invited to use the Signal Tracker website.\n\nOpen Signal Tracker:\n${window.location.origin}/\n\nA 4-digit code is required to log in. Please ask the coworker who invited you for the code.\n\nUse Chrome or Edge on your laptop for RS-232 capture. To pair SideKick on your phone, scan the QR code displayed in Step 3 of your laptop's active session.`;
    window.location.href = `mailto:${encodeURIComponent(email)}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  }

  async function installApp() {
    if (!installPrompt) return;
    await installPrompt.prompt();
    const choice = await installPrompt.userChoice;
    if (choice.outcome === "accepted") setInstallPrompt(null);
  }

  async function manualRefresh() {
    if (!session) return;
    setRefreshing(true);
    setError("");
    try {
      await loadSession(session.code, lastIdRef.current, true);
      setStatusText("Feed refreshed just now");
    } catch (refreshError) {
      setError(refreshError instanceof Error ? refreshError.message : "Unable to refresh the feed.");
    } finally {
      setRefreshing(false);
    }
  }

  async function handleBeepChange(checked: boolean) {
    beepEnabledRef.current = checked;
    setBeepEnabled(checked);
    if (checked) await playBeep(Object.values(alertSounds).find(sound=>sound!=="none") ?? "none");
    else setAudibleAlert(false);
  }

  async function chooseReportFolder(){
    const picker=(window as unknown as {showDirectoryPicker?: (o:{mode:string})=>Promise<ReportFolder>}).showDirectoryPicker;
    if(!picker)throw new Error('Automatic local saving requires desktop Chrome or Edge. Select manual saving on this browser.');
    const folder=await picker({mode:'readwrite'});folderRef.current=folder;setFolderName(folder.name);return folder;
  }
  async function fetchExportEvents() {
    if (!session) return [];
    if(mode==='capture' && (await pendingCapture(session.code)).length)throw new Error('Report paused: saved captures are still awaiting upload. Reconnect, or download the pending capture file.');
    const all:SerialEvent[]=[];let since=0;
    // Bound the export to the events present at its start; new traffic goes into the next save.
    let ceiling:number|undefined;
    const latestResponse=await fetch(`/api/sessions/${session.code}?since=0&limit=1`,{cache:'no-store'});
    if(!latestResponse.ok)throw new Error('Unable to prepare the report.');
    const latest=await latestResponse.json() as {events:SerialEvent[]};ceiling=latest.events[0]?.id??0;
    if(!ceiling)return all;
    while(since<ceiling){
      const response=await fetch(`/api/sessions/${session.code}?since=${since}&limit=5000&order=asc`,{cache:'no-store'});
      const payload=await response.json() as {error?:string;events?:SerialEvent[]};
      if(!response.ok)throw new Error(payload.error||'Unable to prepare the report.');
      const batch=(payload.events||[]).filter(e=>e.id<=ceiling!);if(!batch.length)break;
      all.push(...batch);since=batch[batch.length-1].id;
    }
    return all;
  }
  useEffect(()=>{
    if(session && publisherToken && mode==='capture') window.localStorage.setItem('signal-tracker-publisher',JSON.stringify({session,publisherToken,report}));
  },[session,publisherToken,report,mode]);
  autoSaveRef.current=async()=>{if(mode === "capture" && !endingRef.current && session?.isLive) await exportSignals('auto');};
  useEffect(()=>{
    if(mode !== 'capture' || endingRef.current || !session?.isLive ||report.saving!=='auto'||!folderName)return;
    void autoSaveRef.current();
    const timer=window.setInterval(()=>void autoSaveRef.current(),60000);
    return()=>window.clearInterval(timer);
  },[mode,session?.code,session?.isLive,report.saving,folderName]);

  async function exportSignals(delivery: "download" | "email" | "auto" | "print", complete = false, orderOverride?: "time" | "device") {
    if (mode !== "capture" || !session || saveRunning.current) return false;
    saveRunning.current=true;
    setExportBusy(true);
    setError("");
    let printWindow:Window|null=null;
    try {
      validateReport(complete ? {...report,categories:[...EVENT_CATEGORIES],from:"",to:""} : report);
      if(delivery==='print'){
        printWindow=window.open('','_blank');
        if(!printWindow)throw new Error('Allow pop-ups to open the printable PDF, or select PDF and Save locally.');
        printWindow.opener=null;
        printWindow.document.title='Preparing Signal Tracker report';
        printWindow.document.body.textContent='Preparing your report…';
      }
      const exportEvents = await fetchExportEvents();
      const file = await createSignalExport({ events: exportEvents, filter: "all", format: delivery==='print'?'pdf':report.format, reportName:report.name, order:orderOverride ?? report.order ?? "time", categories:complete ? [...EVENT_CATEGORIES] : report.categories,from:complete ? "" : report.from,to:complete ? "" : report.to, sessionCode: session.code, sessionName: session.name, panelLabel: displayProfileName(session.panelFamily) });
      if(delivery==='print' && printWindow){const url=URL.createObjectURL(file);printWindow.location.href=url;window.setTimeout(()=>URL.revokeObjectURL(url),120000);setReportStatus('Printable PDF opened. Use the PDF viewer’s Print command.');return true;}
      if(delivery==='auto'){
        if(!folderRef.current)throw new Error('Choose a local folder to resume automatic saving.');
        const handle=await folderRef.current.getFileHandle(file.name,{create:true});
        const writer=await handle.createWritable();await writer.write(file);await writer.close();
        setReportStatus(`Automatically saved ${file.name} at ${new Date().toLocaleTimeString()}`);return true;
      }
      if (delivery === "download") {
        downloadFile(file);
        setReportStatus(`Downloaded ${file.name} at ${new Date().toLocaleTimeString()}`);
        setStatusText(`${report.format === "xlsx" ? "Excel" : "PDF"} export saved`);
        return true;
      }
      const shareNavigator = navigator as Navigator & { canShare?: (data: ShareData) => boolean; share?: (data: ShareData) => Promise<void> };
      if (shareNavigator.share && shareNavigator.canShare?.({ files: [file] })) {
        await shareNavigator.share({ files: [file], title: `Signal Tracker — ${session.name}`, text: `Session report from ${session.code}.` });
      } else {
        downloadFile(file);
        const subject = `Signal Tracker export — ${session.name}`;
        const body = `The ${report.format === "xlsx" ? "Excel" : "PDF"} signal export has been downloaded as ${file.name}. Attach that file to this message before sending.`;
        window.location.href = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
      }
      return true;
    } catch (exportError) {
      printWindow?.close();
      if(delivery==='auto'){
        if(exportError instanceof Error && exportError.message.startsWith('Report paused:'))setReportStatus('Automatic saving paused while captures await upload; it will retry automatically.');
        else {setReport(r=>({...r,saving:'manual'}));setReportStatus('Automatic saving stopped because a save failed. Your signals remain in the session. Choose a folder and enable automatic saving to retry.');}
      }
      if (!(exportError instanceof DOMException && exportError.name === "AbortError")) setError(exportError instanceof Error ? exportError.message : "Unable to export the signals.");
      return false;
    } finally {
      saveRunning.current=false;
      setExportBusy(false);
    }
  }

  async function endSessionAndSave(order: "time" | "device") {
    if (!session || !publisherToken || endingRef.current) return;
    if (saveRunning.current) { setError("A report is saving. Wait for it to finish, then end the session."); return; }
    try { validateReport({...report,categories:[...EVENT_CATEGORIES],from:"",to:""}); }
    catch (error) { setError(error instanceof Error ? error.message : "Name your report first."); setReportSource("session"); setPrintOpen(true); return; }
    setEndOptionsOpen(false); setReport(current=>({...current,order}));
    endingRef.current = true; setEnding(true); setError(""); setClosedE3Panel(e3PanelKey);
    try {
      if (!await disconnectSerial(true)) throw new Error("The serial port is still open. Retry End Session to release it before saving.");
      await Promise.allSettled([...pendingWritesRef.current]);
      await flushCapture();
      if((await pendingCapture(session.code)).length)throw new Error('Captures are saved locally and still awaiting upload. Reconnect before ending the session; you can also download the pending capture file.');
      const response = await fetch(`/api/sessions/${session.code}/end`, { method:"POST", signal:AbortSignal.timeout(15000), headers:{"x-publisher-token":publisherToken} });
      if (!response.ok) { const data = await response.json() as {error?:string}; throw new Error(data.error || "Logging stopped locally. Unable to end the shared session; retry End Session."); }
      feedGenerationRef.current++;
      setSession(current => current ? {...current,isLive:false} : current);
      setAudibleAlert(false); setStatusText("Session ended — logging stopped");
      const saved = await exportSignals(report.saving === "auto" && folderRef.current ? "auto" : "download", true, order);
      setFinalSaved(saved);
      if (saved) {
        window.sessionStorage.setItem("signal-tracker-final-saved", session.code);
        setReport(current => ({...current, name:""}));
        setReportStatus("");
        setStatusText("Session ended and saved — ready for a new session");
      } else setReportStatus("Session ended. Report not saved — select Retry final save. Events remain available.");
    } catch (error) { setError(error instanceof Error ? error.message : "Unable to end and save the session. Retry when connected."); }
    finally { endingRef.current = false; setEnding(false); }
  }

  async function leaveSession() {
    if(saveRunning.current){setError('A report is being saved. Wait for it to finish before closing this view.');return false;}
    if(mode === "capture" && session?.isLive && report.saving==='auto' && folderRef.current && !await exportSignals('auto')) return false;
    if (!await disconnectSerial(true)) return false;
    await Promise.allSettled([...pendingWritesRef.current]);
    if(mode==='capture' && session){await flushCapture();if((await pendingCapture(session.code)).length){setError('Saved captures must upload before leaving. Download pending captures if needed.');return false;}}
    feedGenerationRef.current++;
    setSession(null);
    setPublisherToken("");
    window.sessionStorage.removeItem("signal-tracker-publisher"); window.localStorage.removeItem("signal-tracker-publisher");
    setReport(current=>({...current,name:'',from:'',to:''}));folderRef.current=null;setFolderName('');setReportStatus('');
    clearedThroughRef.current = 0;
    setEvents([]);
    setCounts(EMPTY_COUNTS);
    setAudibleAlert(false);
    lastIdRef.current = 0;
    hasLoadedRef.current = false;
    if (mode === "companion") {
      try { localStorage.removeItem("sidekick-paired-session"); } catch {}
      setJoinCode("");
    }
    setStatusText(mode === "capture" ? "Ready to configure" : "Enter a pairing code");
    const url = new URL(window.location.href);
    url.searchParams.delete("session");
    window.history.replaceState({}, "", url);
  }

  function openWiring(value: string) {
    setWiringSelection(value);
    setWiringOpen(true);
  }

  useEffect(() => {
    const context = (document as Document & { modelContext?: { registerTool?: (tool: { name: string; title: string; description: string; inputSchema: object; annotations: { readOnlyHint: boolean; untrustedContentHint: boolean }; execute: (input: unknown) => Promise<unknown> | unknown }, options?: { signal?: AbortSignal }) => void | Promise<void> } }).modelContext;
    if (!context?.registerTool) return;
    const lifecycle = new AbortController();
    void Promise.resolve(context.registerTool({
      name: "open_signal_tracker_sidekick",
      title: "Open Signal Tracker Sidekick",
      description: "Open a Signal Tracker Sidekick phone feed using its pairing code.",
      inputSchema: { type: "object", properties: { code: { type: "string", minLength: 6, maxLength: 8 } }, required: ["code"], additionalProperties: false },
      annotations: { readOnlyHint: true, untrustedContentHint: true },
      async execute(input) {
        const code = normalizeSessionCode((input as { code?: string })?.code ?? "");
        if (code.length !== 8) throw new Error("A valid pairing code is required.");
        setMode("companion");
        setJoinCode(code);
        await joinSession(code);
        return { code, status: "opened" };
      },
    }, { signal: lifecycle.signal })).catch(() => undefined);
    return () => lifecycle.abort();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const exitStreamFullscreen = useCallback(() => {
    setStreamFullscreen(false);
    if (document.fullscreenElement === screenRef.current) void document.exitFullscreen().catch(() => undefined);
    requestAnimationFrame(() => fullscreenButtonRef.current?.focus());
  }, []);
  async function enterStreamFullscreen() {
    if (!session?.isLive) return;
    setStreamFullscreen(true);
    try { await screenRef.current?.requestFullscreen?.(); } catch { /* Keep the expanded view if browser fullscreen is unavailable. */ }
  }
  useEffect(() => {
    if (!streamFullscreen) return;
    const onFullscreen = () => { if (!document.fullscreenElement) exitStreamFullscreen(); };
    const onKey = (event:KeyboardEvent) => { if(event.key === "Escape") exitStreamFullscreen(); };
    document.addEventListener("fullscreenchange", onFullscreen);
    document.addEventListener("keydown", onKey);
    return () => {document.removeEventListener("fullscreenchange", onFullscreen);document.removeEventListener("keydown", onKey);};
  }, [exitStreamFullscreen, streamFullscreen]);
  useEffect(() => { if (!session?.isLive && streamFullscreen) exitStreamFullscreen(); }, [session?.isLive, streamFullscreen, exitStreamFullscreen]);
  useEffect(() => {
    if (!streamFullscreen) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {document.body.style.overflow = previous;};
  }, [streamFullscreen]);

  const reportOptions=<ReportOptions compact value={report} onChange={setReport} folder={folderName} status={reportStatus} chooseFolder={()=>void chooseReportFolder().catch(e=>setError(e instanceof Error?e.message:'Folder selection failed.'))}/>;
  const connectionLabel = connection === "connected" ? "Serial connected" : connection === "connecting" ? "Waiting for port" : mode === "companion" && session ? refreshMode === "manual" ? "Manual refresh" : "Auto refresh" : statusText;

  return (
    <main ref={screenRef} className={`panel-app${streamFullscreen ? " stream-fullscreen" : ""}${session ? " is-paired" : ""}${mode === "companion" ? " is-sidekick" : ""}${sidebarOpen ? " phone-controls-open" : ""}`}>
      <header className="topbar">
        <div className="brand-lockup">
          <svg className="brand-mark" viewBox="0 0 256 256" role="img" aria-label="Signal Tracker logo">
            <defs><filter id="theme-logo" colorInterpolationFilters="sRGB">
              <feColorMatrix in="SourceGraphic" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  10 -10 0 0 0" result="accent-mask"/>
              <feFlood floodColor="var(--ui-accent)"/>
              <feComposite in2="accent-mask" operator="in"/>
              <feComposite in2="SourceGraphic" operator="over"/>
            </filter></defs>
            <image href="/signal-tracker-logo.png" width="256" height="256" filter="url(#theme-logo)"/>
          </svg>
          <div><div className="brand-name">{mode === "companion" ? "SideKick" : "Signal Tracker"}{mode==='companion' && session ? <span className={`tab-status-light phone-status ${deliveryConfirmed?'confirmed':'unconfirmed'}`} role="img" aria-label={deliveryConfirmed?'Signal delivery confirmed':'Signal delivery not confirmed'} title={deliveryConfirmed?'Green: latest signals received from the paired laptop.':'Red: latest signal delivery is not confirmed. Check the laptop, network and refresh settings.'}/> : null}</div><div className="brand-subtitle">RS-232 Event Monitor <span className="beta-badge">Beta Version</span></div></div>
        </div>
        <div className="topbar-status" aria-live="polite"><span>{connectionLabel}</span></div>
        <nav className="topbar-actions" aria-label="Application controls">
          <DropdownMenu>
            <DropdownMenuTrigger asChild><Button variant="ghost" size="sm" aria-label="Display Signal Filters" title="Display Signal Filters"><Settings2/><span className="hide-mobile">Signal Filters</span><ChevronDown className="menu-chevron"/></Button></DropdownMenuTrigger>
            <DropdownMenuContent align="start" style={{maxWidth:"calc(100vw - 24px)",maxHeight:"70vh",overflowY:"auto"}}>
              <DropdownMenuLabel>Display Signal Filters</DropdownMenuLabel>
              {EVENT_CATEGORIES.map(category=><DropdownMenuCheckboxItem key={category} checked={visible[category]} onCheckedChange={checked=>setVisible(current=>({...current,[category]:checked}))} onSelect={event=>event.preventDefault()}><span className="filter-swatch" style={{backgroundColor:colors[category]}}/>{CATEGORY_LABELS[category]}</DropdownMenuCheckboxItem>)}
              <DropdownMenuSeparator/>
              <DropdownMenuCheckboxItem checked={resetVisible} onCheckedChange={setResetVisible} onSelect={event=>event.preventDefault()}>System Reset</DropdownMenuCheckboxItem>
              <DropdownMenuCheckboxItem checked={ackVisible} onCheckedChange={setAckVisible} onSelect={event=>event.preventDefault()}>Acknowledged</DropdownMenuCheckboxItem>
              <DropdownMenuCheckboxItem checked={panelFunctionsVisible} onCheckedChange={setPanelFunctionsVisible} onSelect={event=>event.preventDefault()}>Panel functions, time/date &amp; node labels</DropdownMenuCheckboxItem>
            </DropdownMenuContent>
          </DropdownMenu>
          {mode === "capture" ? <Button variant="ghost" size="sm" onClick={()=>setPrintOpen(true)} title="Print Report — formats, signal types and time ranges" aria-label="Print Report"><Printer/><span className="hide-mobile">Print Report</span></Button> : null}
          <Button variant="ghost" size="sm" onClick={()=>setFeedbackOpen(true)} title="Comments and suggestions" aria-label="Comments and suggestions"><MessageSquare/><span className="hide-mobile">Feedback</span></Button>
          <Button variant="ghost" size="sm" onClick={()=>setRevisionOpen(true)} aria-label="Revision history" title="Revision history"><FileText/><span className="hide-mobile">Revisions</span></Button>
          <WiringMenu openGuide={openWiring} />
          {mode === "capture" ? <Button variant="ghost" size="sm" onClick={() => setShareOpen(true)}><Share2 /><span className="hide-mobile">Share</span></Button> : null}
          <Button variant="ghost" size="sm" onClick={() => setSettingsOpen(true)} aria-label="Colors" title="Customize signal colors"><Palette /><span className="hide-mobile">Colors</span></Button>
          <Button variant="ghost" size="icon-sm" className="mobile-menu-button" aria-label="Open controls" onClick={() => setSidebarOpen((current) => !current)}>{sidebarOpen ? <X /> : <Menu />}</Button>
        </nav>

      </header>

      <section className="mode-strip">
        <Tabs value={instructionsOpen ? "instructions" : mode === "companion" && sidebarOpen ? "controls" : "monitor"} onValueChange={value => { setInstructionsOpen(value === "instructions"); setSidebarOpen(value === "controls"); }} className="mode-tabs">
          <TabsList><TabsTrigger value="monitor">{mode === "companion" ? <Smartphone/> : <Laptop/>}{mode === "companion" ? "Live stream" : "Laptop capture"}{mode === "capture" ? <span className={`tab-status-light serial-status ${serialVerified && connection === "connected" ? "verified" : "inactive"}`} role="img" aria-label={serialVerified && connection === "connected" ? "RS-232 reception verified" : "RS-232 reception not verified"} title="Blue: readable RS-232 data received during this connection."/> : null}</TabsTrigger>{mode === "companion" && session ? <TabsTrigger value="controls" className="phone-controls-tab"><Settings2/>Controls</TabsTrigger> : null}<TabsTrigger value="instructions"><BookOpen/>Instructions</TabsTrigger></TabsList>
        </Tabs>
        {session ? <div className="session-chip"><span className="session-chip-label">Private session</span><strong>{session.code}</strong><span className="session-chip-divider" /><span>{session.name} · {displayProfileName(session.panelFamily)}</span></div> : <div className="mode-hint">{mode === "capture" ? "Start on the laptop physically connected to the panel" : "Use the private code shown on the paired laptop"}</div>}
      </section>

      {instructionsOpen?<Instructions onFeedback={()=>setFeedbackOpen(true)}/>:null}
      <div className="workspace-shell" hidden={instructionsOpen}>
        <section className="terminal-panel" aria-label="Serial event feed">
          <div className="terminal-toolbar">
            <div className="terminal-title"><TerminalSquare /><div><strong>Live event stream</strong><span>{session ? `${events.length} signal${events.length === 1 ? "" : "s"} on screen` : "Sample signals shown until monitoring begins"}</span></div></div>
            {mode === "capture" ? <CaptureQueue counts={session ? counts : EMPTY_COUNTS} colors={colors}/> : null}
            <div className="terminal-tools">
              {session?.isLive ? <Button ref={fullscreenButtonRef} className="fullscreen-toggle" variant="outline" size="sm" onClick={()=>streamFullscreen ? exitStreamFullscreen() : void enterStreamFullscreen()} title={streamFullscreen ? "Exit full screen (Esc)" : "Show only the event stream and queues"}>{streamFullscreen ? <Minimize/> : <Maximize/>}{streamFullscreen ? "Exit Full Screen · Esc" : "Full Screen"}</Button> : null}
              {mode === "capture" && session ? <Button className="end-save-button" size="sm" disabled={ending || exportBusy || connection === "connecting" || finalSaved} onClick={()=>{setFinalOrder(report.order ?? "time");setEndOptionsOpen(true);}} title="End this session and save all captured signals to the selected report file">{ending ? <LoaderCircle className="spin"/> : <Square/>}{ending ? "Ending & saving…" : session.isLive || finalSaved ? "End Session" : "Retry final save"}</Button> : null}
              <Button variant="ghost" size="sm" onClick={() => setTextOpen(true)}>Aa<span className="hide-mobile"> Text</span></Button>
              {reviewingHistory ? <Button className="jump-latest" variant="secondary" size="sm" onClick={() => { followStreamRef.current = true; setReviewingHistory(false); if (terminalRef.current) terminalRef.current.scrollTop = terminalRef.current.scrollHeight; }}>Jump to latest ↓</Button> : null}
              {mode === "companion" && audibleAlert ? <Button variant="destructive" size="sm" onClick={()=>setAudibleAlert(false)}><BellOff/>Silence beep</Button> : null}
              {mode === "companion" && session && refreshMode === "manual" ? <Button className="stream-refresh" variant="ghost" size="sm" onClick={() => void manualRefresh()} disabled={refreshing}>{refreshing ? <LoaderCircle className="spin" /> : <RefreshCw />} Refresh</Button> : null}
              {mode === "capture" && session ? <Button variant="ghost" size="sm" onClick={clearFeed} disabled={ending || events.length === 0} title="Clear displayed signals only. All signals remain available in the session report."><RotateCcw /> Clear Screen</Button> : null}
            </div>
          </div>

          {mode === "companion" && session && refreshMode === "manual" ? <div className="session-ended-notice" role="status">Manual Refresh — events and queue counts update when you tap Refresh. Laptop capture continues.</div> : null}
          {session && ((mode === 'capture' && (pendingUploads > 0 || uploadIssue)) || (mode === 'companion' && (remoteCapture?.pendingUploads || feedState !== 'current' || !networkOnline || !deliveryConfirmed || (beepEnabled && !audioReady)))) ? <div className="connection-health" aria-live="polite">
            {mode==='capture' && (pendingUploads>0 || uploadIssue) ? <div role="status">{pendingUploads} signals saved locally, awaiting upload. {uploadIssue}<Button variant="outline" size="sm" onClick={()=>void downloadPendingCapture().catch(()=>setError('Unable to download saved captures.'))}>Download pending captures</Button></div>:null}
            {mode==='companion' && remoteCapture?.pendingUploads ? <div role="status">Laptop has {remoteCapture.pendingUploads} signals awaiting upload.</div>:null}
            {mode==='companion' && (feedState!=='current'||!networkOnline||!deliveryConfirmed) ? <div className="feed-stale" role="status">{feedState==='catching-up'?'Catching up':feedState==='current' && networkOnline?'Delivery not confirmed':'Reconnecting'} — showing previously received data.</div>:null}
            {mode==='companion' && beepEnabled && !audioReady ? <span>Audio: {<Button variant="outline" size="sm" onClick={()=>void prepareAudio()}>Tap to enable audio</Button>}</span>:null}
          </div>:null}
          {mode === "capture" && session?.isLive ? <KeepAwake key={session.code}/> : null}
          {session && !session.isLive ? <div className="session-ended-notice" role="status">Session ended — logging has stopped. {finalSaved ? "Final report saved." : "Events remain available for viewing and saving."}</div> : null}
          <div ref={terminalRef} onScroll={event => { const el = event.currentTarget; const atBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 48; followStreamRef.current = atBottom; setReviewingHistory(!atBottom); }} tabIndex={0} aria-label="Event history; scroll to review earlier signals" className="terminal-window" role="log" aria-live="polite" style={{ "--capture-font": FONT_CHOICES.find(f => f.value === textStyle.font)?.family, "--capture-size": `${textStyle.size / 16}rem`, "--capture-weight": textStyle.bold ? 700 : 400 } as React.CSSProperties}>
            {!session ? <div className="sample-ribbon"><span>Sample feed</span><span>Start or join a session to replace these examples</span></div> : null}
            {displayedEvents.length ? displayedEvents.map((item) => (
              <article className={`event-line${(item.signalColor === null) ? " event-system-reset" : ""}`} key={item.id} style={(item.signalColor === null) ? undefined : { "--signal": colors[item.signalColor!], "--signal-soft": alpha(colors[item.signalColor!], 0.09) } as React.CSSProperties}>
                <time dateTime={item.occurredAt} title="Recorded on the laptop’s clock">{eventClock(item.occurredAt)}</time><span className="event-category">{THEMED_STREAM_LABELS[item.streamCategory] ?? CATEGORY_LABELS[item.streamCategory as EventCategory]}</span><code>{item.message}</code>{item.source === "manual" ? <span className="manual-tag">TEST</span> : null}
              </article>
            )) : <div className="empty-terminal"><Radio /><strong>No visible signals</strong><span>Turn on a signal filter or wait for the next panel message.</span></div>}
          </div>

          {mode === "capture" && session?.isLive && !ending ? <form className="manual-entry" onSubmit={sendManualMessage}><Input value={manualMessage} onChange={(event) => setManualMessage(event.target.value)} placeholder="Type or paste a test panel message" aria-label="Test panel message" /><Button type="submit" variant="secondary" disabled={!publisherToken || !manualMessage.trim()}><Send /> Send test</Button></form> : null}
        </section>

        <aside className={`control-rail ${sidebarOpen ? "is-open" : ""}`} aria-label="Monitoring controls">
          {serialHeld && mode === "capture" ? <section className="rail-card"><strong>Serial port ready for reuse</strong><p className="micro-copy">Logging is stopped. Start a session and select the same port to resume. Between-session data is discarded. Release the port before using it in another program.</p><Button variant="outline" size="sm" onClick={()=>void disconnectSerial()}>Release serial port</Button></section> : null}
      {isE3(controlsPanel) && session?.isLive !== false && !ending ? closedE3Panel === e3PanelKey ? <Button variant="outline" onClick={()=>setClosedE3Panel("")}>Open Gamewell-FCI E3 controls</Button> : <E3Controls onClose={()=>setClosedE3Panel(e3PanelKey)} key={`${e3PanelKey}:${mode}:${connection}`} code={session?.code ?? ""} panelName={displayProfileName(controlsPanel)} capture={mode === "capture"} connected={connection === "connected" && isE3(commPreset)} publisherToken={publisherToken} send={async bytes => {
        const writer = commandWriterRef.current;
        if (!writer || serialStopRef.current || !isE3(session?.panelFamily ?? "") || !isE3(commPreset)) throw new Error("E3 serial port disconnected");
        await writer.write(bytes);
      }} /> : null}
          {mode === "capture" ? session && !finalSaved ? (
            <CaptureControls panelName={displayProfileName(session.panelFamily)} configuration={<div className="communication-setup">
              <Label>Panel communication preset</Label><Select value={profileOptions.some(p=>p.value===commPreset) ? commPreset : "other"} onValueChange={v => applyCommPreset(v, true)} disabled={connection !== "idle"}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><VerifiedLegend/>{profileOptions.map(p => <SelectItem key={p.value} value={p.value}><span>{p.label}</span>{p.verified ? <Check className="verified-panel-check" aria-label="Communication settings verified" /> : null}</SelectItem>)}</SelectContent></Select>
              {isE3(commPreset) ? <div className="receive-quality"><p><strong>E3 terminal profile:</strong> 9600 · 8 data bits · no parity · 1 stop bit · no handshake. SW2-5 ON forces 115200; CAMWorks may define another baud.</p><Button variant="outline" size="sm" disabled={connection !== "connected"} onClick={() => void testE3SerialInput()}>Test E3 input (firmware query)</Button><p className="micro-copy">Sends read-only <code>V</code> + one carriage return. It does not acknowledge, silence or reset the panel. Testing phase — verify on authorized equipment.</p></div> : null}
              <p className="receive-quality" role="status">{receiveQuality}</p>
              <Button variant="outline" size="sm" disabled={connection !== "idle" || profileBusy} onClick={() => openProfileEditor(commPreset)}>Edit panel name and saved settings</Button>
              <Button variant="outline" size="sm" disabled={connection !== "idle" || profileBusy || !baudRate || Boolean(matchesStored)} onClick={() => void saveCommSettings(false)}>Save current settings to website</Button>
              <Button variant="outline" size="sm" disabled={!canSaveSettings || settingsSaved || profileBusy || connection !== "connected"} onClick={() => void saveCommSettings(true)}>{settingsSaved ? <><Check className="verified-panel-check" /> User-verified settings</> : "I confirm successful communication"}</Button>
            </div>} session={session} baudRate={baudRate} setBaudRate={v=>changeConnectionSetting(()=>setBaudRate(v))} dataBits={dataBits} setDataBits={v=>changeConnectionSetting(()=>setDataBits(v))} parity={parity} setParity={v=>changeConnectionSetting(()=>setParity(v))} stopBits={stopBits} setStopBits={v=>changeConnectionSetting(()=>setStopBits(v))} connection={connection} connectSerial={connectSerial} disconnectSerial={disconnectSerial} stopped={ending || !session.isLive} leaveSession={leaveSession} />
          ) : <StartSessionCard reportOptions={reportOptions} options={profileOptions} profilesReady={profilesReady} editProfile={() => openProfileEditor(panelFamily)} readyToStart={Boolean(report.name.trim()) && (report.saving === "manual" || Boolean(folderName))} panelFamily={panelFamily} setPanelFamily={v => {if(v === "other") setProfileDraft({}); else setPanelFamily(v);}} createSession={createSession} isBusy={isBusy} /> : session ? (
            <CompanionControls alertSounds={alertSounds} changeAlertSound={changeAlertSound} previewSound={previewSound} panelName={displayProfileName(session.panelFamily)} session={session} refreshMode={refreshMode} setRefreshMode={setRefreshMode} refreshing={refreshing} manualRefresh={manualRefresh} beepEnabled={beepEnabled} handleBeepChange={handleBeepChange} audibleAlert={audibleAlert} silence={() => setAudibleAlert(false)} leaveSession={leaveSession} />
          ) : <JoinSessionCard />}



          {mode === "capture" ? <details id="sidekick-step3" className="rail-card pairing-card sidekick-disclosure" open={phoneSetup} onToggle={event=>setPhoneSetup(event.currentTarget.open)}>
            <summary><span><span className="eyebrow">Step 3 · Optional</span><strong>SideKick Phone App</strong></span>{session && phonePaired ? <span className={`tab-status-light phone-status ${deliveryConfirmed ? "confirmed" : "unconfirmed"}`} role="img" aria-label={deliveryConfirmed ? "Paired phone delivery confirmed" : "Paired phone delivery not confirmed"} title={deliveryConfirmed ? "Green: paired SideKick recently received the latest signals." : "Red: paired SideKick delivery is not currently confirmed."}/> : null}<ChevronDown className="disclosure-chevron"/></summary>
            <SidekickSetup session={session} onCapture={() => setPhoneSetup(false)} compact/>
          </details> : null}

          {mode === "capture" && session && !finalSaved ? <section className="rail-card export-card"><h2>Session saving</h2>{reportOptions}<Button variant="outline" onClick={()=>setPrintOpen(true)}><Printer/>Print Report options</Button></section> : null}
          <div className="safety-note"><ShieldAlert /><p><strong>Supplemental tool only.</strong> Do not use Signal Tracker as a listed fire-alarm annunciator or a replacement for required monitoring.</p></div>
        </aside>
      </div>

      {error ? <div className="error-toast" role="alert"><ShieldAlert /><span>{error}</span><button aria-label="Dismiss error" onClick={() => setError("")}><X /></button></div> : null}
      {mode === "companion" ? <SignalCountBar companion counts={session ? counts : EMPTY_COUNTS} colors={colors} /> : null}
      <Dialog open={endOptionsOpen} onOpenChange={setEndOptionsOpen}><DialogContent className="signal-dialog"><DialogHeader><DialogTitle>End session and save</DialogTitle><DialogDescription>Choose how to arrange the final report. Logging continues until you press End &amp; Save.</DialogDescription></DialogHeader><Label>Final report order</Label><Select value={finalOrder} onValueChange={value=>setFinalOrder(value as "time"|"device")}><SelectTrigger><SelectValue/></SelectTrigger><SelectContent><SelectItem value="time">Time — oldest first</SelectItem><SelectItem value="device">Device — detectors, then modules</SelectItem></SelectContent></Select><p className="micro-copy">{finalOrder==='device'?'Detectors first, then modules, sorted by node, loop and address. Other signals follow; each device’s events stay in time order.':'All signals in chronological order.'}</p><DialogFooter><Button variant="outline" onClick={()=>setEndOptionsOpen(false)}>Cancel</Button><Button disabled={ending || exportBusy} onClick={()=>void endSessionAndSave(finalOrder)}>End &amp; Save</Button></DialogFooter></DialogContent></Dialog>
      <FeedbackDialog open={feedbackOpen} onOpenChange={setFeedbackOpen}/>
      <Dialog open={printOpen} onOpenChange={setPrintOpen}><DialogContent className="signal-dialog report-dialog"><DialogHeader><DialogTitle>Print or share a report</DialogTitle><DialogDescription>Use the current session or browse this device for an existing PDF or Excel report.</DialogDescription></DialogHeader>
        <Tabs value={reportSource} onValueChange={setReportSource}><TabsList className="report-source-tabs"><TabsTrigger value="session">Current session</TabsTrigger><TabsTrigger value="file">Existing report</TabsTrigger></TabsList></Tabs>
        {reportSource === "file" ? <ExistingReport/> : <>{error?<p role="alert" className="access-error">{error}</p>:null}<ReportOptions value={report} onChange={setReport} folder={folderName} status={reportStatus} chooseFolder={()=>void chooseReportFolder().catch(e=>setError(e instanceof Error?e.message:'Folder selection failed.'))}/>{!session?<p className="micro-copy">Start a monitoring session to save its signals, or select Existing report to browse your device.</p>:null}<div className="report-actions"><Button disabled={!session||exportBusy} onClick={()=>void exportSignals('download')}><Download/>Save locally</Button><Button disabled={!session||exportBusy} variant="outline" onClick={()=>void exportSignals('print')}><Printer/>Print / preview PDF</Button><Button disabled={!session||exportBusy} variant="outline" onClick={()=>void exportSignals('email')}><Mail/>Email report</Button></div></>}
      </DialogContent></Dialog>
      <RevisionHistory open={revisionOpen} onOpenChange={setRevisionOpen}/>
      <AlertDialog open={verifiedEdit !== null} onOpenChange={open=>{if(!open)setVerifiedEdit(null);}}><AlertDialogContent><AlertDialogHeader><AlertDialogTitle>Edit verified panel settings?</AlertDialogTitle><AlertDialogDescription>This panel’s connection settings have already been verified. Are you sure you want to edit them? Saving changes will require the connection to be verified again.</AlertDialogDescription></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel>Keep current settings</AlertDialogCancel><AlertDialogAction onClick={()=>{const apply=verifiedEdit;setVerifiedEdit(null);apply?.();}}>Edit settings</AlertDialogAction></AlertDialogFooter></AlertDialogContent></AlertDialog>
      {profileDraft ? <PanelProfileDialog initial={profileDraft} onClose={() => setProfileDraft(null)} onSaved={acceptProfile} /> : null}
      <WiringDialog open={wiringOpen} onOpenChange={setWiringOpen} selected={wiringSelection} setSelected={setWiringSelection} />
      <Dialog open={textOpen} onOpenChange={setTextOpen}><DialogContent className="signal-dialog"><DialogHeader><DialogTitle>Captured text appearance</DialogTitle><DialogDescription>Saved on this device for Signal Tracker and Sidekick. Available system fonts use a fallback when needed.</DialogDescription></DialogHeader>
        <Label>Font</Label><Select value={textStyle.font} onValueChange={font => setTextStyle(s => ({...s,font}))}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{FONT_CHOICES.map(f => <SelectItem key={f.value} value={f.value}>{f.label}</SelectItem>)}</SelectContent></Select>
        <Label>Font size</Label><Select value={String(textStyle.size)} onValueChange={size => setTextStyle(s => ({...s,size:Number(size)}))}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{[12,14,16,18,20,24,28,32].map(n => <SelectItem key={n} value={String(n)}>{n} px</SelectItem>)}</SelectContent></Select>
        <label className="compact-toggle"><Switch checked={textStyle.bold} onCheckedChange={bold => setTextStyle(s => ({...s,bold}))} />Bold text</label>
        <p className="font-preview" style={{fontFamily:FONT_CHOICES.find(f => f.value === textStyle.font)?.family,fontSize:`${textStyle.size / 16}rem`,fontWeight:textStyle.bold ? 700 : 400}}>FIRE ALARM · L01D020<br />East lobby smoke detector</p>
        <DialogFooter><Button variant="outline" onClick={() => setTextStyle({font:"mono",size:16,bold:false})}>Reset</Button><Button onClick={() => setTextOpen(false)}>Done</Button></DialogFooter>
      </DialogContent></Dialog>
      <ColorDialog open={settingsOpen} onOpenChange={setSettingsOpen} colors={colors} setColors={setColors} />
      <ShareDialog open={shareOpen} onOpenChange={setShareOpen} recipientEmail={recipientEmail} setRecipientEmail={setRecipientEmail} emailInvite={emailInvite} installPrompt={installPrompt} installApp={installApp} />
    </main>
  );
}

function WiringMenu({ openGuide }: { openGuide: (value: string) => void }) {
  const manufacturers = Array.from(new Set(WIRING_GUIDES.map((guide) => guide.manufacturer)));
  const [menuOpen, setMenuOpen] = useState(false);
  const pendingGuide = useRef<string | null>(null);
  return (
    <DropdownMenu open={menuOpen} onOpenChange={setMenuOpen}>
      <DropdownMenuTrigger asChild><Button variant="ghost" size="sm" aria-label="Panel wiring"><Cable /><span className="hide-mobile">Panel wiring</span><ChevronDown className="menu-chevron" /></Button></DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="wiring-menu" onCloseAutoFocus={event => {if (pendingGuide.current) {event.preventDefault(); const value = pendingGuide.current; pendingGuide.current = null; requestAnimationFrame(() => openGuide(value));}}}>
        {manufacturers.map((manufacturer, index) => <Fragment key={manufacturer}>{index ? <DropdownMenuSeparator /> : null}<DropdownMenuLabel>{manufacturer}</DropdownMenuLabel>{WIRING_GUIDES.filter((guide) => guide.manufacturer === manufacturer).map((guide) => <DropdownMenuItem key={guide.value} onSelect={() => {pendingGuide.current = guide.value; setMenuOpen(false);}}><span className="guide-status-dot supplied" /><span className="menu-model"><strong>{guide.model}</strong><small>{guide.series}</small></span></DropdownMenuItem>)}</Fragment>)}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

function guideTo(element: HTMLElement | null) {
  if (!element) return;
  element.focus({preventScroll:true});
  element.scrollIntoView({behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'center'});
}
function StartSessionCard({ reportOptions, options, profilesReady, editProfile, readyToStart, panelFamily, setPanelFamily, createSession, isBusy }: {
  reportOptions: React.ReactNode;
  options: Array<{value:string;label:string;verified:boolean}>;
  profilesReady:boolean; editProfile:()=>void;
  readyToStart: boolean;
  panelFamily: string;
  setPanelFamily: (value: string) => void;
  createSession: (event: FormEvent) => void;
  isBusy: boolean;
}) {
  const formRef=useRef<HTMLFormElement>(null);
  const advancePanel=useRef(false);
  const [step,setStep]=useState<'panel'|'name'|'folder'|'start'>('panel');
  const next=(target:'name'|'folder'|'start', focus=true, scroll=true)=>{
    const actual=target==='folder' && !formRef.current?.querySelector('[data-setup="folder"]')?'start':target;
    setStep(actual);
    requestAnimationFrame(()=>{const element=formRef.current?.querySelector<HTMLElement>(`[data-setup="${actual}"]`);if(focus)guideTo(element ?? null);else if(scroll) element?.scrollIntoView({behavior:window.matchMedia("(prefers-reduced-motion: reduce)").matches?"auto":"smooth",block:"center"});});
  };
  useEffect(()=>{if(readyToStart && step==='folder') next('start');},[readyToStart,step]);
  useEffect(()=>{guideTo(formRef.current?.querySelector<HTMLElement>('[data-setup="panel"]') ?? null);},[]);
  const finishName=(scroll=true)=>{
    const input=formRef.current?.querySelector<HTMLInputElement>('[data-setup="name"]');
    if(!input?.value.trim()){input?.focus();return;}
    next(readyToStart?'start':'folder',false,scroll);
  };
  return (
    <form ref={formRef} data-setup-step={step} className="rail-card session-card guided-session" onSubmit={event=>{if(step!=='start'){event.preventDefault();finishName();}else createSession(event);}} onKeyDown={event=>{if(event.key==='Enter' && (event.target as HTMLElement).dataset.setup==='name'){event.preventDefault();finishName();}}}>
      <div className="card-heading"><div><span className="eyebrow">Step 1</span><h2>Start monitoring</h2></div><Radio /></div>
      <p className="setup-progress" role="status">{step==='panel'?'1 of 3 · Select your panel':step==='name'?'2 of 3 · Name this session':step==='folder'?'3 of 3 · Choose a local folder':'Ready · Start your session'}</p>
      <div className="field-stack"><Label>Panel manufacturer and model</Label><Select value={panelFamily} onValueChange={value=>{setPanelFamily(value);advancePanel.current=value!=='other';}}><SelectTrigger data-setup="panel" className="w-full"><SelectValue><span>{options.find(p=>p.value===panelFamily)?.label ?? panelLabel(panelFamily)}</span>{options.find(p=>p.value===panelFamily)?.verified ? <Check className="verified-panel-check" aria-label="Communication settings verified" /> : null}</SelectValue></SelectTrigger><SelectContent onCloseAutoFocus={event=>{if(advancePanel.current){event.preventDefault();advancePanel.current=false;next('name');}}}><VerifiedLegend/>{options.map((panel) => <SelectItem key={panel.value} value={panel.value}><span>{panel.label}</span>{panel.verified ? <Check className="verified-panel-check" aria-label="Communication settings verified" /> : null}</SelectItem>)}</SelectContent></Select></div>
      <div className="setup-panel-actions"><Button type="button" variant="outline" size="sm" onClick={editProfile} disabled={!profilesReady}>Edit panel settings</Button><Button type="button" size="sm" onClick={()=>next('name')} disabled={!profilesReady}>Use this panel</Button></div>
      {cloneElement(reportOptions as React.ReactElement<{onNameComplete?:(scroll?:boolean)=>void}>, {onNameComplete:finishName})}
      <Button data-setup="start" type="submit" variant="outline" className={`primary-action${readyToStart ? " setup-next-action" : ""}`} onClick={()=>setStep('start')} disabled={isBusy || !profilesReady || !readyToStart}>{isBusy ? <LoaderCircle className="spin" /> : <Play />}Start Session</Button>
    </form>
  );
}

function JoinSessionCard() {
  return <section className="rail-card session-card companion-card"><div className="card-heading"><div><span className="eyebrow">SideKick</span><h2>Scan to join</h2></div><Smartphone/></div><p className="card-copy">On the laptop, start a Signal Tracker session and expand Step 3 · SideKick Phone App. Scan its QR code with your phone camera to open SideKick and pair automatically.</p></section>;
}

function CaptureControls({ panelName, configuration, session, baudRate, setBaudRate, dataBits, setDataBits, parity, setParity, stopBits, setStopBits, connection, connectSerial, disconnectSerial, stopped, leaveSession }: {
  panelName: string;
  configuration: React.ReactNode;
  session: MonitorSession;
  baudRate: string;
  setBaudRate: (value: string) => void;
  dataBits: "7" | "8";
  setDataBits: (value: "7" | "8") => void;
  parity: "none" | "even" | "odd";
  setParity: (value: "none" | "even" | "odd") => void;
  stopBits: "1" | "2";
  setStopBits: (value: "1" | "2") => void;
  connection: ConnectionState;
  connectSerial: () => Promise<void>;
  disconnectSerial: () => Promise<boolean>;
  stopped: boolean;
  leaveSession: () => void;
}) {
  return (
    <>
      <div className="rail-card session-complete"><span className="eyebrow">Step 1 complete</span><h2>Monitoring session started</h2><p>{session.name}</p></div>
      <div className="rail-card serial-card">
        <div className="card-heading"><div><span className="eyebrow">Step 2</span><h2>Serial connection</h2></div><Cable /></div>
        <div className="source-summary"><span>{panelName}</span><strong>{session.name}</strong></div>
        {configuration}
        <div className="serial-grid">
          <div className="field-stack"><Label>Baud</Label><Select value={baudRate} onValueChange={setBaudRate} disabled={connection !== "idle"}><SelectTrigger className="w-full"><SelectValue placeholder="Choose panel baud">{baudRate || undefined}</SelectValue></SelectTrigger><SelectContent>{Array.from(new Set([...(baudRate ? [baudRate] : []), "1200", "2400", "4800", "9600", "19200", "38400", "57600", "115200"])).map((value) => <SelectItem key={value} value={value}>{value}</SelectItem>)}</SelectContent></Select></div>
          <div className="field-stack"><Label>Data bits</Label><Select value={dataBits} onValueChange={(value) => setDataBits(value as "7" | "8")} disabled={connection !== "idle"}><SelectTrigger className="w-full"><SelectValue>{dataBits}</SelectValue></SelectTrigger><SelectContent><SelectItem value="8">8</SelectItem><SelectItem value="7">7</SelectItem></SelectContent></Select></div>
          <div className="field-stack"><Label>Parity</Label><Select value={parity} onValueChange={(value) => setParity(value as "none" | "even" | "odd")} disabled={connection !== "idle"}><SelectTrigger className="w-full"><SelectValue>{parity[0].toUpperCase() + parity.slice(1)}</SelectValue></SelectTrigger><SelectContent><SelectItem value="none">None</SelectItem><SelectItem value="even">Even</SelectItem><SelectItem value="odd">Odd</SelectItem></SelectContent></Select></div>
          <div className="field-stack"><Label>Stop bits</Label><Select value={stopBits} onValueChange={(value) => setStopBits(value as "1" | "2")} disabled={connection !== "idle"}><SelectTrigger className="w-full"><SelectValue>{stopBits}</SelectValue></SelectTrigger><SelectContent><SelectItem value="1">1</SelectItem><SelectItem value="2">2</SelectItem></SelectContent></Select></div>
        </div>
        {connection === "connected" ? <Button variant="destructive" className="primary-action" onClick={() => void disconnectSerial()}><Unplug /> Disconnect serial</Button> : <Button data-setup="serial" className="primary-action" onClick={() => void connectSerial()} disabled={stopped || connection === "connecting"}>{connection === "connecting" ? <LoaderCircle className="spin" /> : <Cable />}Select serial port</Button>}
        <p className="micro-copy">Desktop Chrome or Edge · isolated USB-to-RS-232 adapter · HTTPS required</p>
      </div>
      <Button variant="ghost" size="sm" className="end-session" onClick={leaveSession}><Square /> {session.isLive ? "Close this view" : "Start New Session"}</Button>
    </>
  );
}

function CompanionControls({ alertSounds, changeAlertSound, previewSound, panelName, session, refreshMode, setRefreshMode, refreshing, manualRefresh, beepEnabled, handleBeepChange, audibleAlert, silence, leaveSession }: {
  alertSounds: AlertSounds;
  changeAlertSound: (category: AlertSoundKey, sound: SoundId) => void;
  previewSound: (sound: SoundId) => Promise<void>;
  panelName:string;
  session: MonitorSession;
  refreshMode: RefreshMode;
  setRefreshMode: (value: RefreshMode) => void;
  refreshing: boolean;
  manualRefresh: () => Promise<void>;
  beepEnabled: boolean;
  handleBeepChange: (checked: boolean) => Promise<void>;
  audibleAlert: boolean;
  silence: () => void;
  leaveSession: () => void;
}) {
  return (
    <div className="rail-card companion-status-card">
      <div className="companion-summary"><div className="companion-live-icon"><Wifi /></div><div><span className="eyebrow">Connected Sidekick</span><h2>{session.name}</h2><p>{panelName} · Session {session.code}</p></div></div>
      <div className="companion-control-grid">
        <div className="field-stack"><Label>Feed refresh</Label><Select value={refreshMode} onValueChange={(value) => setRefreshMode(value as RefreshMode)}><SelectTrigger className="w-full"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="auto">Auto Refresh</SelectItem><SelectItem value="manual">Manual Refresh</SelectItem></SelectContent></Select></div>
        {refreshMode === "manual" ? <Button variant="secondary" onClick={() => void manualRefresh()} disabled={refreshing}>{refreshing ? <LoaderCircle className="spin" /> : <RefreshCw />}Refresh now</Button> : null}
      </div>
      <div className="beep-control">
        <label><span>{beepEnabled ? <Bell /> : <BellOff />}<span><strong>Audible alerts</strong><small>Sound once per new signal</small></span></span><Switch checked={beepEnabled} onCheckedChange={(checked) => void handleBeepChange(checked)} /></label>
        {beepEnabled ? <Button variant={audibleAlert ? "destructive" : "outline"} size="sm" onClick={silence} disabled={!audibleAlert}><BellOff />{audibleAlert ? "Silence beep" : "Beep is silent"}</Button> : null}
      </div>
      <div className="sidekick-alert-sounds">
        {ALERT_CATEGORIES.map(category => <fieldset className="sidekick-tone-group" key={category}><legend>{CATEGORY_LABELS[category]}</legend>{[category,`${category}-restoral` as AlertSoundKey].map(key=><div className="field-stack" key={key}><Label htmlFor={`sound-${key}`}>{key===category?'New signal':'Restoral'}</Label><div className="sidekick-sound-row"><Select value={alertSounds[key]} onValueChange={value=>changeAlertSound(key,value as SoundId)}><SelectTrigger id={`sound-${key}`} className="w-full"><SelectValue/></SelectTrigger><SelectContent><SelectItem value="none">None — silent</SelectItem>{SIDEKICK_SOUNDS.map(sound=><SelectItem key={sound.id} value={sound.id}>{sound.name}</SelectItem>)}</SelectContent></Select><Button variant="outline" size="sm" disabled={alertSounds[key] === "none"} onClick={()=>void previewSound(alertSounds[key])} aria-label={`Preview ${CATEGORY_LABELS[category]} ${key===category?'signal':'restoral'}`}>Preview</Button></div></div>)}</fieldset>)}
        <p className="micro-copy">Choose None for any signal or restoral you do not want to hear. Preview works even when Audible alerts is off. Saved on this device. Each new signal or recognized restoral plays its assigned tone once. Signals received together play in turn. The animal, whistle and horn sounds are synthesized effects. Keep SideKick open; phone sleep can pause sound and updates.</p>
      </div>
      <Button variant="ghost" size="sm" className="end-session" onClick={leaveSession}><WifiOff /> Leave paired feed</Button>
    </div>
  );
}

function CaptureQueue({counts,colors}:{counts:Counts;colors:SignalColors}) {
  return <section className="capture-queue layout-bar" aria-label="Observed panel queues">
    <div className="capture-queue-counts">{EVENT_CATEGORIES.map(category=><div key={category} className={`capture-queue-cell${counts[category]>0?' has-events':''}`} style={{'--signal':colors[category]} as React.CSSProperties} aria-label={`${CATEGORY_LABELS[category]}: ${counts[category]}`}><span className="capture-queue-dot"/><span className="capture-queue-label">{CATEGORY_LABELS[category]}</span><strong>{counts[category]}</strong></div>)}</div>
  </section>;
}

function SignalCountBar({ counts, colors, companion }: { counts: Counts; colors: SignalColors; companion:boolean }) {
  const [desktopMinimized,setMinimized]=useState(false);
  const minimized=companion || desktopMinimized;
  useEffect(()=>{if(companion)return;try{setMinimized(localStorage.getItem('signal-tracker-queues-minimized')==='true');}catch{}},[companion]);
  const toggle=()=>setMinimized(value=>{try{localStorage.setItem('signal-tracker-queues-minimized',String(!value));}catch{}return !value;});
  return (
    <aside className={`signal-count-bar queue-stack${companion?' queue-bar-companion':''}${minimized?' is-minimized':''}`} aria-label="Observed panel queues">
      {!companion && <Button variant="ghost" size="sm" className="queue-toggle" onClick={toggle} aria-expanded={!minimized} aria-controls="queue-counts">Queues {minimized?<Maximize/>:<Minimize/>}<span>{minimized?'Expand':'Minimize'}</span></Button>}
      <div id="queue-counts" className="queue-counts">
      {EVENT_CATEGORIES.map((category) => <div className={`count-cell ${counts[category] > 0 ? "has-events" : ""}`} key={category} style={{ "--signal": colors[category], "--signal-text": contrastText(colors[category]) } as React.CSSProperties} aria-label={`${counts[category]} observed ${CATEGORY_LABELS[category]} conditions`} title={`${CATEGORY_LABELS[category]}: ${counts[category]}`}><span className="count-dot" /><span className="count-label">{minimized ? ({alarm:'ALM',supervisory:'SUP',trouble:'TRB',other:'OTH'}[category]) : CATEGORY_LABELS[category].toUpperCase()}</span><strong>{counts[category]}</strong></div>)}
      </div>
    </aside>
  );
}

function ColorDialog({ open, onOpenChange, colors, setColors }: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  colors: SignalColors;
  setColors: React.Dispatch<React.SetStateAction<SignalColors>>;
}) {
  const { theme, setTheme, palette, setPalette } = useAppearance();
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="signal-dialog">
        <DialogHeader><DialogTitle>Colors &amp; appearance</DialogTitle><DialogDescription>Customize the event stream and active queue bar on this laptop or phone. Settings are saved in this browser.</DialogDescription></DialogHeader>
        <div className="appearance-setting"><Label htmlFor="appearance-palette">Theme</Label><Select value={palette} onValueChange={value=>setPalette(value as AppearancePalette)}><SelectTrigger id="appearance-palette"><SelectValue/></SelectTrigger><SelectContent><SelectItem value="graphite">Graphite</SelectItem><SelectItem value="ocean">Ocean</SelectItem><SelectItem value="forest">Forest</SelectItem><SelectItem value="crimson">Crimson</SelectItem></SelectContent></Select></div><div className="appearance-preview" aria-hidden="true"><span/><span/><span/><span/></div><div className="appearance-setting"><Label htmlFor="appearance-mode">Display mode</Label><Select value={theme} onValueChange={value => setTheme(value as "dark" | "light")}><SelectTrigger id="appearance-mode"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="dark">Dark mode</SelectItem><SelectItem value="light">Light mode</SelectItem></SelectContent></Select></div><div className="color-settings">{EVENT_CATEGORIES.map((category) => <label className="color-row" key={category}><span><i style={{ backgroundColor: colors[category] }} />{CATEGORY_LABELS[category]}</span><span className="color-value">{colors[category].toUpperCase()}</span><input type="color" value={colors[category]} onChange={(event) => setColors((current) => ({ ...current, [category]: event.target.value }))} aria-label={`${CATEGORY_LABELS[category]} color`} /></label>)}</div>
        <DialogFooter><Button variant="outline" onClick={() => setColors(DEFAULT_COLORS)}><RotateCcw /> Reset defaults</Button><Button onClick={() => onOpenChange(false)}>Done</Button></DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function WiringDialog({ open, onOpenChange, selected, setSelected }: {
  open: boolean; onOpenChange: (open: boolean) => void; selected: string; setSelected: (value: string) => void;
}) {
  const guide = guideForPanel(selected);
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="wiring-dialog source-wiring-dialog">
        <DialogHeader><DialogTitle>Panel wiring references</DialogTitle><DialogDescription>Professional three-wire DB-9 diagrams built from the supplied panel documentation.</DialogDescription></DialogHeader>
        <div className="wiring-selector"><Label>Manufacturer and model</Label><Select value={guide?.value ?? ""} onValueChange={setSelected}><SelectTrigger className="w-full"><SelectValue placeholder="Select a supplied reference" /></SelectTrigger><SelectContent position="popper" className="wiring-select-content">{WIRING_GUIDES.map(panel => <SelectItem key={panel.value} value={panel.value}>{panel.manufacturer} {panel.model}</SelectItem>)}</SelectContent></Select></div>
        {guide ? <section className="selected-guide">
          <div className="guide-heading"><div><span>{guide.manufacturer} · {guide.series}</span><h3>{guide.model}</h3></div><span className="verification-badge supplied">Manual verified</span></div>
          <div className="port-callout"><span>Panel connection</span><strong>{guide.port}</strong></div>
          <div className="source-table-wrap"><table className="source-terminal-table"><caption>{guide.model} terminal reference</caption><thead><tr>{guide.columns.map(column => <th key={column} scope="col">{column}</th>)}</tr></thead><tbody>{guide.rows.map((row, i) => <tr key={i}>{row.map((cell, j) => j === 0 ? <th scope="row" key={j}>{cell}</th> : <td key={j}>{j === 2 ? <span className={`wire-color wire-${cell.toLowerCase()}`}><i />{cell}</span> : cell}</td>)}</tr>)}</tbody></table></div>
          <figure className="source-figure db9-wire-figure"><figcaption><span className="eyebrow">Panel to computer adapter</span><strong>Uniform DB-9 wiring and side profile</strong></figcaption><p className="diagram-reading-note">Female cable connector shown from the rear/wiring side. Black is pin 2 PTX, red is pin 3 PRX, and green is pin 5 REF on every diagram.</p><div className="db9-diagram-scroll"><Image src={`/wiring/${guide.value}-db9.svg`} alt={`${guide.model}: black pin 2 PTX, red pin 3 PRX and green pin 5 REF wired from the panel to a DB-9 female connector, with side profile`} width={1000} height={900} unoptimized /></div><a href={`/wiring/${guide.value}-db9.svg`} target="_blank" rel="noreferrer">Open full-size wiring diagram <ExternalLink size={14} /></a></figure>
          <ul className="guide-notes source-notes">{guide.notes.map(note => <li key={note}>{note}</li>)}</ul>
        </section> : <p className="micro-copy">No supplied wiring reference is available for this panel yet. Select a documented model above.</p>}
        <DialogFooter><Button onClick={() => onOpenChange(false)}>Close references</Button></DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function ShareDialog({ open, onOpenChange, recipientEmail, setRecipientEmail, emailInvite, installPrompt, installApp }: {
  open:boolean; onOpenChange:(open:boolean)=>void; recipientEmail:string;
  setRecipientEmail:(value:string)=>void; emailInvite:(event:FormEvent)=>void;
  installPrompt:InstallPromptEvent|null; installApp:()=>Promise<void>;
}) {
 return <Dialog open={open} onOpenChange={onOpenChange}><DialogContent className="share-dialog">
 <DialogHeader><DialogTitle>Share Signal Tracker</DialogTitle><DialogDescription>Email the website link to a coworker. The invitation explains that a 4-digit login code is required; the code is not included.</DialogDescription></DialogHeader>
 <form onSubmit={emailInvite} className="share-form"><div className="field-stack"><Label htmlFor="invite-email">Recipient email</Label><Input id="invite-email" type="email" required value={recipientEmail} onChange={event=>setRecipientEmail(event.target.value)} autoComplete="email"/></div><Button type="submit" className="primary-action"><Mail/>Open email invitation</Button></form>
 <p className="micro-copy">Review the invitation in your email app and press Send. SideKick is shared by scanning the session QR code in Step 3.</p>
 {installPrompt ? <Button variant="outline" onClick={()=>void installApp()}><Download/>Install Signal Tracker on this device</Button> : null}
 <DialogFooter><Button onClick={()=>onOpenChange(false)}>Done</Button></DialogFooter>
 </DialogContent></Dialog>;
}

function VerifiedLegend() { return <div className="verified-legend"><Check aria-hidden="true"/><span><strong>Communication settings verified</strong><small>Settings confirmed by a user; this does not identify the connected panel model.</small></span></div>; }
