'use client';
import { randomId } from "@/lib/random-id";
import { useEffect, useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { E3_ACTIONS, commandBytes, isE3Action, type E3Action } from '@/lib/e3-control';

type Command = {id:string;action:E3Action;status:string;result:string;expires_at:number;reset_format:string;epoch:string};
type Props = {onClose:()=>void;code:string;panelName:string;capture:boolean;connected:boolean;publisherToken:string;send:(bytes:Uint8Array)=>Promise<void>};
export function E3Controls({onClose,code,panelName,capture,connected,publisherToken,send}:Props) {
  const [enabled,setEnabled]=useState(false);
  const [pair,setPair]=useState({epoch:'',key:''});
  const [key,setKey]=useState('');
  const [resetFormat,setResetFormat]=useState('');
  const [visible,setVisible]=useState<Record<E3Action,boolean>>({ackAlarm:true,ackTrouble:true,silence:true,reset:true});
  const [ready,setReady]=useState(false);
  const [records,setRecords]=useState<Command[]>([]);
  const [error,setError]=useState('');
  const [pending,setPending]=useState<E3Action|null>(null);
  const [busy,setBusy]=useState(false);
  const current=useRef({enabled,connected,send}); current.current={enabled,connected,send};
  useEffect(()=>()=>{current.current.enabled=false;current.current.connected=false;},[]);
  const seen=useRef(new Set<string>());
  useEffect(()=>{
    setPair({epoch:randomId(),key:randomId().replaceAll('-','').slice(0,16)});
    try { const saved=JSON.parse(localStorage.getItem('e3-visible-controls') || '{}'); setVisible(v=>({...v,...Object.fromEntries(Object.keys(E3_ACTIONS).filter(k=>typeof saved[k]==='boolean').map(k=>[k,saved[k]]))})); } catch { /* Default buttons remain visible. */ }
  },[]);
  async function api(body:Record<string,unknown>) {
    const response=await fetch(`/api/sessions/${code}/controls`,{method:'POST',headers:{'content-type':'application/json',...(capture?{'x-publisher-token':publisherToken}:{})},body:JSON.stringify({...body,key:capture?pair.key:key})});
    const data=await response.json() as {error?:string;commands:Command[];ready:boolean;resetFormat:string}; if(!response.ok) throw new Error(data.error || 'Control request failed.'); return data;
  }
  useEffect(()=>{
    if(!code || !pair.epoch || (!capture && key.length!==16)) {setReady(false);return;}
    let cancelled=false; let timer:ReturnType<typeof setTimeout>;
    const poll=async()=>{
      try {
        if(capture) {
          const data=await api({op:'host',epoch:pair.epoch,enabled:enabled&&connected,resetFormat});
          for(const command of data.commands as Command[]) {
            if(cancelled || !current.current.enabled || !current.current.connected || command.expires_at<Date.now() || command.epoch!==pair.epoch || seen.current.has(command.id) || !isE3Action(command.action)) continue;
            seen.current.add(command.id);
            let status='sent',result='Sent to serial port; panel action unconfirmed. Verify at the panel.';
            try { await current.current.send(commandBytes(command.action,command.reset_format)); }
            catch { status='unknown';result='Transmission failed or interrupted; panel action unknown. No automatic retry.'; }
            await api({op:'result',epoch:pair.epoch,id:command.id,status,result});
          }
        }
        const data=await api({op:'status'});
        if(!cancelled) {setReady(data.ready);setRecords(data.commands);if(!capture)setResetFormat(data.resetFormat);setError('');}
      } catch(e) {if(!cancelled){setReady(false);setError(e instanceof Error?e.message:'Controls unavailable.');}}
      finally {if(!cancelled)timer=setTimeout(poll,1500);}
    };
    void poll();
    return ()=>{cancelled=true;clearTimeout(timer);};
  // Restart the host lease whenever control configuration changes.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  },[code,capture,connected,enabled,pair,key,capture?resetFormat:'',publisherToken]);
  async function requestAction() {
    if(!pending || busy)return;
    setBusy(true);setError('');
    try {await api({op:'request',id:randomId(),action:pending,...(capture?{epoch:pair.epoch}:{})});setPending(null);}
    catch(e){setError(e instanceof Error?e.message:'Request result unknown. Check the panel before retrying.');}
    finally{setBusy(false);}
  }
  return <section className="e3-controls" aria-label="E3 panel controls">
    <div className="e3-heading"><strong>Gamewell-FCI E3 controls</strong><span className="e3-testing">Testing phase — may not work</span></div>
    <p>{panelName}. Confirm actions at the panel. Panel silence is separate from Sidekick beep mute.</p>
    {capture?<>
      <label className="e3-option"><input type="checkbox" checked={enabled} disabled={!connected} onChange={e=>setEnabled(e.target.checked)} />Enable experimental panel controls for this connection</label>
      {enabled&&connected?<p>Sidekick control key: <code>{pair.key}</code></p>:<p>Connect this E3 panel’s serial port to enable testing.</p>}
      <label className="e3-option">Reset test format <select aria-label="Reset test format" value={resetFormat} onChange={e=>setResetFormat(e.target.value)}><option value="">Choose before testing reset</option><option value="hex">R + space + CR (reported hex)</option><option value="text">R + CR (reported text)</option></select></label>
      <p>The reference disagrees on reset’s trailing space. Choose one format deliberately; the app never tries both. Reported reset scope: local region 0; not hardware verified.</p>
    </>:<label className="e3-option">Laptop control key <input aria-label="Laptop control key" type="password" autoComplete="off" value={key} maxLength={16} onChange={e=>setKey(e.target.value.trim().toLowerCase())} placeholder="Enter key from laptop" /></label>}
    <details><summary>Show / hide control buttons</summary><div className="e3-button-options">{Object.entries(E3_ACTIONS).map(([id,action])=><label className="e3-option" key={id}><input type="checkbox" checked={visible[id as E3Action]} onChange={e=>{const next={...visible,[id]:e.target.checked};setVisible(next);localStorage.setItem('e3-visible-controls',JSON.stringify(next));}}/>{action.label}</label>)}</div></details>
    <div className="e3-actions">{Object.entries(E3_ACTIONS).filter(([id])=>visible[id as E3Action]).map(([id,action])=><Button key={id} variant={id==='reset'?'destructive':'outline'} disabled={!ready || capture&&(!enabled||!connected) || id==='reset'&&!resetFormat || busy} onClick={()=>setPending(id as E3Action)}>{action.label}</Button>)}</div>
    <p role="status">{ready?'Controls available for testing':'Controls off or laptop unavailable'}. No automatic retries. Supervisory acknowledgment is not documented.</p>
    {error?<p role="alert" className="e3-error">{error}</p>:null}
    {records.length?<details open><summary>Recent control requests</summary><ul>{records.slice(0,5).map(r=><li key={r.id}><strong>{E3_ACTIONS[r.action]?.label}</strong>: {r.status==='pending'&&r.expires_at<Date.now()?'Expired — not sent':r.status==='claimed'?'Outcome unknown — delivery claimed':r.result||'Requested — awaiting laptop'}</li>)}</ul></details>:null}
    <a href="https://firealarmhackery.com/index.php/2023/12/21/fci-e3-and-s3-terminal-commands/" target="_blank" rel="noreferrer">Independent command reference</a>
    <Button className="e3-close-button" variant="secondary" onClick={onClose}>Close E3 controls</Button>
    <Dialog open={pending!==null} onOpenChange={open=>{if(!open&&!busy)setPending(null);}}><DialogContent className="signal-dialog"><DialogHeader><DialogTitle>{pending?E3_ACTIONS[pending].label:''}?</DialogTitle><DialogDescription>Send an experimental command to {panelName} in session {code}. Testing phase — may not work. Verify the outcome at the panel.</DialogDescription></DialogHeader>{pending?<p>Bytes: <code>{Array.from(commandBytes(pending,resetFormat)).map(b=>b.toString(16).padStart(2,'0').toUpperCase()).join(' ')}</code></p>:null}<Button onClick={()=>void requestAction()} disabled={busy||!ready}>{busy?'Requesting…':'Send test command'}</Button><Button variant="outline" disabled={busy} onClick={()=>setPending(null)}>Cancel</Button></DialogContent></Dialog>
  </section>;
}
