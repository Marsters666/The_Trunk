import { getRawDb } from '../../db';
import { ACCESS_AGE, ACCESS_COOKIE, hasAccess, issueAccess, safeReturn, signature, validPasscode } from '../../lib/site-access';
const escapeHtml = (s:string) => s.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]!));
function page(returnTo:string, message='', status=200) {
  const sidekick = new URL(returnTo, 'https://local.invalid').searchParams.get('mode') === 'companion';
  return new Response(`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${sidekick?'SideKick':'Signal Tracker'} — Coworker access</title><style>*{box-sizing:border-box}body{margin:0;min-height:100dvh;display:grid;place-items:center;background:#0b1013;color:#edf2f4;font:16px system-ui;padding:24px}.card{width:100%;max-width:420px;padding:32px;background:#141e23;border:1px solid #33434c;border-radius:20px}.brand{display:flex;align-items:center;gap:12px;font-size:24px;font-weight:700}.brand img{width:48px;height:48px}h1{font-size:22px;margin-top:32px}p{line-height:1.6;color:#bac7cf}label{display:block;margin-bottom:8px}input,button{width:100%;font:inherit;padding:14px;border-radius:10px}input{background:#0b1013;color:#fff;border:1px solid #60717b;letter-spacing:.25em}button{margin-top:18px;background:#ff5848;color:#120c0b;border:0;font-weight:700;cursor:pointer}.error{color:#ffb4ab}input:focus-visible,button:focus-visible{outline:3px solid #8bd5ff;outline-offset:3px}</style></head><body><main class="card"><div class="brand"><img src="/signal-tracker-logo.png" alt="">${sidekick?'SideKick':'Signal Tracker'}</div><h1>Coworker access</h1><p>Enter the shared passcode to open ${sidekick?'SideKick':'Signal Tracker'}. Ask your team for the code.</p>${message?`<p class="error" role="alert">${escapeHtml(message)}</p>`:''}<form method="post" action="/unlock" target="_top"><input type="hidden" name="returnTo" value="${escapeHtml(returnTo)}"><label for="passcode">Passcode</label><input id="passcode" name="passcode" type="password" inputmode="numeric" autocomplete="current-password" required maxlength="64" autofocus><button type="submit">Continue</button></form><p>This device stays unlocked for 30 days. Your session pairing code is separate.</p><p><a href="https://panelstream-rs232.marsters666.chatgpt.site/unlock?returnTo=${encodeURIComponent(returnTo)}" target="_blank" rel="noopener" style="color:#8bd5ff">Open in a new browser tab</a></p></main></body></html>`,{status,headers:{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store','Content-Security-Policy':"default-src 'none'; img-src 'self'; style-src 'unsafe-inline'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'",'Referrer-Policy':'no-referrer','X-Content-Type-Options':'nosniff'}});
}
export async function GET(request:Request) {
  const returnTo = safeReturn(new URL(request.url).searchParams.get('returnTo'));
  return new Response(null,{status:303,headers:{Location:returnTo,'Cache-Control':'no-store'}});
}
export async function POST(request:Request) {
  let returnTo='/';
  const json = request.headers.get('content-type')?.includes('application/json');
  const fail = (message:string,status:number) => json ? Response.json({error:message},{status,headers:{'Cache-Control':'no-store'}}) : page(returnTo,message,status);
  try {
    if (request.headers.get('origin') !== new URL(request.url).origin) return fail('Please open this page directly and try again.',403);
    if (Number(request.headers.get('content-length') || 0)>4096) return fail('Request too large.',413);
    const body=(await request.text()).slice(0,4096);
    const payload=json?JSON.parse(body):null;
    const form = json?new URLSearchParams({passcode:typeof payload?.passcode==='string'?payload.passcode:''}):new URLSearchParams(body);
    returnTo = safeReturn(form.get('returnTo'));
    const db = getRawDb();
    const now=Date.now();
    const clientKey = await signature('attempts:' + (request.headers.get('cf-connecting-ip') || 'unknown'));
    const limit = await db.prepare('INSERT INTO access_attempts (key,count,expires_at) VALUES (?,1,?) ON CONFLICT(key) DO UPDATE SET count=CASE WHEN expires_at<=? THEN 1 ELSE count+1 END, expires_at=CASE WHEN expires_at<=? THEN ? ELSE expires_at END RETURNING count').bind(clientKey,now+900000,now,now,now+900000).first<{count:number}>();
    if (!limit || limit.count>20) return fail('Too many attempts. Please wait 15 minutes and try again.',429);
    if (!await validPasscode(form.get('passcode') || '')) return fail('Incorrect passcode. Please try again.',401);
    await db.prepare('DELETE FROM access_attempts WHERE key=? OR expires_at<?').bind(clientKey,now).run();
    const token=await issueAccess();
    if(json) return Response.json({token},{headers:{'Cache-Control':'no-store'}});
    return new Response(null,{status:303,headers:{Location:'/unlock?verify=1&returnTo='+encodeURIComponent(returnTo),'Cache-Control':'no-store','Set-Cookie':`${ACCESS_COOKIE}=${token}; Path=/; HttpOnly; Secure; SameSite=None; Partitioned; Max-Age=${ACCESS_AGE}`}});
  } catch { return fail('Access is temporarily unavailable. Please try again shortly.',503); }
}
