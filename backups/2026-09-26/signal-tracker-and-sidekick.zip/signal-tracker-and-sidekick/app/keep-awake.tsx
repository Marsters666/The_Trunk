'use client';
import {useEffect,useRef,useState} from 'react';
import {Monitor,RefreshCw} from 'lucide-react';
import {Button} from '@/components/ui/button';
import {createSessionWakeLock,type AwakeStatus} from '@/lib/session-wake-lock';
export function KeepAwake() {
 const [status,setStatus]=useState<AwakeStatus>('requesting');
 const controller=useRef<ReturnType<typeof createSessionWakeLock>|null>(null);
 useEffect(()=>{
  const current=createSessionWakeLock({request:'wakeLock' in navigator?()=>navigator.wakeLock.request('screen'):undefined,visible:()=>document.visibilityState==='visible',onStatus:setStatus});
  controller.current=current;
  const refresh=()=>void current.acquire();
  document.addEventListener('visibilitychange',refresh);
  window.addEventListener('pageshow',refresh);
  refresh();
  return ()=>{controller.current=null;document.removeEventListener('visibilitychange',refresh);window.removeEventListener('pageshow',refresh);current.stop();};
 },[]);
 const active=status==='active';
 return <div className={`keep-awake ${active?'is-active':'needs-attention'}`}><Monitor aria-hidden="true"/><div><span role="status">{active?'Keep awake active':status==='requesting'?'Requesting keep awake…':status==='paused'?'Keep awake paused':'Keep awake unavailable'}</span>{!active && status!=='requesting'?<p>Keep this tab visible. If protection stays unavailable, disable automatic sleep in your device’s power settings during monitoring.</p>:null}</div>{status==='paused'||status==='unavailable'?<Button size="sm" variant="outline" onClick={()=>void controller.current?.acquire()}><RefreshCw/>Retry</Button>:null}<details><summary>Details</summary><p>Requests screen wake protection while this live session is open. Keep the tab visible and the laptop lid open. Battery saver, manual sleep, or system policy can override this request. Protection ends when you end or leave the session.</p></details></div>;
}
