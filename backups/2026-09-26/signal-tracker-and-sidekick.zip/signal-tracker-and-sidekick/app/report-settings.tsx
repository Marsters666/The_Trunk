'use client';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CATEGORY_LABELS, EVENT_CATEGORIES, type EventCategory } from '@/lib/panelstream';
import type { ExportFormat } from '@/lib/signal-export';
export type ReportSettings = {order?:'time'|'device';name:string; format:ExportFormat; categories:EventCategory[]; from:string; to:string; saving:'manual'|'auto'};
export const defaultReport:ReportSettings={order:'time',name:'',format:'xlsx',categories:[...EVENT_CATEGORIES],from:'',to:'',saving:'auto'};
export function validateReport(value:ReportSettings){
 if(!value.name.trim())throw new Error('Give this session report a file name before starting or saving.');
 if(!value.categories.length)throw new Error('Select at least one signal type.');
 if(value.from && value.to && new Date(value.from)>new Date(value.to))throw new Error('The start time must be before the end time.');
}
export function ReportOptions({value,onChange,chooseFolder,folder,status,compact=false,onNameComplete}:{onNameComplete?:(scroll?:boolean)=>void;compact?:boolean;value:ReportSettings;onChange:(v:ReportSettings)=>void;chooseFolder:()=>void;folder:string;status:string}){
 const update=(patch:Partial<ReportSettings>)=>onChange({...value,...patch});
 return <fieldset className="report-options"><legend>{compact?'Session saving':'Report settings'}</legend><Label>{compact ? "Session name / report file name" : "Report file name"}<Input data-setup="name" value={value.name} onChange={e=>update({name:e.target.value})} onBlur={event=>{if(value.name.trim())onNameComplete?.(!(event.relatedTarget instanceof HTMLElement && event.relatedTarget.closest("button, [role=combobox]")));}} maxLength={80} placeholder="Enter a report name" required/></Label>{!compact&&<><Label>File format</Label><Select value={value.format} onValueChange={v=>update({format:v as ExportFormat})}><SelectTrigger><SelectValue/></SelectTrigger><SelectContent><SelectItem value="xlsx">Excel (.xlsx)</SelectItem><SelectItem value="pdf">PDF (.pdf)</SelectItem></SelectContent></Select><div className="report-types"><span>Signal types</span>{EVENT_CATEGORIES.map(c=><label key={c}><Checkbox checked={value.categories.includes(c)} onCheckedChange={checked=>update({categories:checked?[...value.categories,c]:value.categories.filter(x=>x!==c)})}/>{CATEGORY_LABELS[c]}</label>)}</div><Label>From (local time)<Input type="datetime-local" value={value.from} onChange={e=>update({from:e.target.value})}/></Label><Label>Through (local time)<Input type="datetime-local" value={value.to} onChange={e=>update({to:e.target.value})}/></Label><p className="micro-copy">Leave either time blank for no limit. The ending minute is included.</p></>}<Label>Saving</Label><Select value={value.saving} onValueChange={v=>update({saving:v as ReportSettings['saving']})}><SelectTrigger><SelectValue/></SelectTrigger><SelectContent><SelectItem value="manual">Manual — save when ready</SelectItem><SelectItem value="auto">Automatic — every minute</SelectItem></SelectContent></Select>{value.saving==='auto'&&<><Button data-setup="folder" type="button" variant="outline" className={value.name.trim() && !folder ? "setup-next-action" : undefined} onClick={chooseFolder}>{folder?'Change folder':'Choose local folder'}</Button><p className="micro-copy">{folder?`Folder: ${folder}. `:''}Updates the same report while this page is open. Keep the device awake. After reopening, choose the folder again to resume automatic saving.</p></>}{status&&<p role="status" className="micro-copy">{status}</p>}</fieldset>;
}
