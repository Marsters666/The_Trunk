import { getRawDb } from '../../../db';
import { createPublisherToken, createSessionCode, hashPublisherToken, jsonError } from '../../../lib/server-session';
import { PANEL_OPTIONS } from '../../../lib/wiring-guides';
const ALLOWED_PANELS = new Set([...PANEL_OPTIONS.map(p => p.value), 'gamewell-e3', 'gamewell-s3', 'est4']);

export async function POST(request: Request) {
  try {
    const payload = await request.json() as {name?:string;panelFamily?:string};
    const name = payload.name?.trim().slice(0,80) || 'Field monitoring session';
    const panelFamily = payload.panelFamily?.trim() ?? 'other';
    const db = getRawDb();
    if (!ALLOWED_PANELS.has(panelFamily) && !await db.prepare('SELECT id FROM panel_profiles WHERE id=?').bind(panelFamily).first()) return jsonError('Select a supported panel family.');
    const publisherToken = createPublisherToken();
    const hash = await hashPublisherToken(publisherToken);
    // The unique index arbitrates concurrent allocation. Never check then insert.
    for (let attempt=0; attempt<8; attempt++) {
      const code = createSessionCode();
      const session = await db.prepare('INSERT INTO monitor_sessions (code,name,panel_family,publisher_token_hash) VALUES (?,?,?,?) ON CONFLICT(code) DO NOTHING RETURNING code,name,panel_family AS panelFamily,is_live AS isLive,created_at AS createdAt').bind(code,name,panelFamily,hash).first<{code:string;name:string;panelFamily:string;isLive:number;createdAt:string}>();
      if(session) return Response.json({session:{...session,isLive:Boolean(session.isLive)},publisherToken},{status:201,headers:{'Cache-Control':'no-store'}});
    }
    return jsonError('Could not allocate a unique pairing code. Please try again.',503);
  } catch {return jsonError('The monitoring service is temporarily unavailable.',503);}
}
