import { and, eq, gte, max } from "drizzle-orm";
import { getDb } from "../../../../../db";
import { deliveryHealth, deliveryReceipts, monitorSessions, serialEvents } from "../../../../../db/schema";
import { normalizeSessionCode } from "../../../../../lib/panelstream";
import { jsonError, tokensMatch } from "../../../../../lib/server-session";

const FRESH_MS = 15000;
export async function POST(request: Request, context: { params: Promise<{ code: string }> }) {
  try {
    const code = normalizeSessionCode((await context.params).code);
    const body = await request.json() as { role?: string; clientId?: string; probe?: string; eventId?: number; panelConnected?:boolean; lastPanelAt?:string; pendingUploads?:number };
    const db = getDb();
    const [session] = await db.select().from(monitorSessions).where(eq(monitorSessions.code, code)).limit(1);
    if (!session) return jsonError("Session not found", 404);
    const now = Date.now();
    const captureStatus=JSON.stringify({panelConnected:body.panelConnected===true,lastPanelAt:typeof body.lastPanelAt==='string'?body.lastPanelAt.slice(0,40):'',pendingUploads:Number.isSafeInteger(body.pendingUploads)?Math.max(0,body.pendingUploads!):0});
    const [latest] = await db.select({ id: max(serialEvents.id) }).from(serialEvents).where(eq(serialEvents.sessionCode, code));
    const latestId = latest?.id ?? 0;
    if (body.role === "capture") {
      if (!(await tokensMatch(request.headers.get("x-publisher-token") ?? "", session.publisherTokenHash))) return jsonError("Publisher authorization required", 403);
      if (typeof body.probe !== "string" || body.probe.length > 80 || !body.probe) return jsonError("Invalid probe");
      await db.insert(deliveryHealth).values({ sessionCode: code, probe: body.probe, publisherAt: now, captureStatus }).onConflictDoUpdate({ target: deliveryHealth.sessionCode, set: { probe: body.probe, publisherAt: now, captureStatus } });
      const receipts = await db.select().from(deliveryReceipts).where(and(eq(deliveryReceipts.sessionCode, code), eq(deliveryReceipts.probe, body.probe), gte(deliveryReceipts.receivedAt, now - FRESH_MS), gte(deliveryReceipts.eventId, latestId))).limit(1);
      const paired = await db.select({id: deliveryReceipts.id}).from(deliveryReceipts).where(eq(deliveryReceipts.sessionCode, code)).limit(1);
      return Response.json({ delivered: session.isLive && receipts.length > 0, phonePaired: paired.length > 0 }, { headers: { "Cache-Control": "no-store" } });
    }
    if (body.role !== "companion" || typeof body.clientId !== "string" || !/^[a-zA-Z0-9-]{16,80}$/.test(body.clientId)) return jsonError("Invalid receiver");
    const [health] = await db.select().from(deliveryHealth).where(eq(deliveryHealth.sessionCode, code)).limit(1);
    const delivered = Boolean(session.isLive && health && now - health.publisherAt < FRESH_MS && body.probe === health.probe && Number.isSafeInteger(body.eventId) && body.eventId! >= latestId);
    const id = `${code}:${body.clientId}`;
    // Keep pairing evidence even when delivery is stale; freshness is checked separately.
    const receipt = { id, sessionCode: code, probe: delivered ? health!.probe : '', receivedAt: now, eventId: Number.isSafeInteger(body.eventId) ? body.eventId! : 0 };
    await db.insert(deliveryReceipts).values(receipt).onConflictDoUpdate({ target: deliveryReceipts.id, set: receipt });
    return Response.json({ delivered, phonePaired: true, probe: health?.probe ?? "", captureStatus:health?JSON.parse(health.captureStatus):null }, { headers: { "Cache-Control": "no-store" } });
  } catch {
    return jsonError("Delivery confirmation unavailable", 503);
  }
}
