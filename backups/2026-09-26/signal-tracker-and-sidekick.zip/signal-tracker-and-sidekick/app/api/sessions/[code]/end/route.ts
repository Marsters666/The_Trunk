import { getRawDb } from '../../../../../db';
import { normalizeSessionCode } from '../../../../../lib/panelstream';
import { jsonError, tokensMatch } from '../../../../../lib/server-session';
export async function POST(request:Request, context:{params:Promise<{code:string}>}) {
  try {
    const code=normalizeSessionCode((await context.params).code);
    const db=getRawDb();
    const session=await db.prepare('SELECT publisher_token_hash FROM monitor_sessions WHERE code=?').bind(code).first<{publisher_token_hash:string}>();
    if(!session)return jsonError('Session not found.',404);
    const token=request.headers.get('x-publisher-token')||'';
    if(!token || !await tokensMatch(token,session.publisher_token_hash))return jsonError('Only the recording laptop can end this session.',403);
    await db.batch([
      db.prepare('UPDATE monitor_sessions SET is_live=0,updated_at=CURRENT_TIMESTAMP WHERE code=?').bind(code),
      db.prepare('UPDATE e3_control_hosts SET expires_at=0 WHERE session_code=?').bind(code),
      db.prepare("UPDATE e3_commands SET status='expired',result='Not sent: session ended' WHERE session_code=? AND status='pending'").bind(code),
    ]);
    return Response.json({ended:true});
  } catch {return jsonError('Unable to end the shared session. Retry End Session & Save.',500);}
}
