import { eq, sql } from "drizzle-orm";
import { getDb } from "../../../../../db";
import { monitorSessions, serialEvents } from "../../../../../db/schema";
import { normalizeSessionCode } from "../../../../../lib/panelstream";
import { jsonError, tokensMatch } from "../../../../../lib/server-session";

type RouteContext = { params: Promise<{ code: string }> };

export async function POST(request: Request, context: RouteContext) {
  try {
    const { code: rawCode } = await context.params;
    const code = normalizeSessionCode(rawCode);
    const token = request.headers.get("x-publisher-token") ?? "";
    const db = getDb();
    const [session] = await db
      .select({ tokenHash: monitorSessions.publisherTokenHash, isLive: monitorSessions.isLive })
      .from(monitorSessions)
      .where(eq(monitorSessions.code, code))
      .limit(1);

    if (!session) return jsonError("Session not found.", 404);
    if (!token || !(await tokensMatch(token, session.tokenHash))) return jsonError("Not authorized.", 403);

    if (!session.isLive) return jsonError("An ended session cannot be cleared.", 409);

    await db.batch([
      db.delete(serialEvents).where(eq(serialEvents.sessionCode, code)),
      db
        .update(monitorSessions)
        .set({ updatedAt: sql`CURRENT_TIMESTAMP` })
        .where(eq(monitorSessions.code, code)),
    ]);

    return Response.json({ cleared: true });
  } catch (error) {
    console.error("Unable to clear serial events", error);
    return jsonError("The event feed could not be cleared.", 500);
  }
}
