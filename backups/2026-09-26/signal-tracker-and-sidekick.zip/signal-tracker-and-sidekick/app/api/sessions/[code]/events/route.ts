import { usesNotifierPrinterParser, isNotifierActiveEvent } from "../../../../../lib/notifier-format";
import { notifierEventCategory } from "../../../../../lib/notifier-event-category";
import { notifierCounts } from "../../../../../lib/notifier-queue-server";
import {validCapturedTime} from '../../../../../lib/event-time';
import { and, count, desc, eq, or, sql } from "drizzle-orm";
import { getDb, getRawDb } from "../../../../../db";
import { activeSignals, monitorSessions, serialEvents } from "../../../../../db/schema";
import {
  classifySerialMessage,
  deriveQueueMutation,
  isEventCategory,
  normalizeMessage,
  normalizeSessionCode,
} from "../../../../../lib/panelstream";
import { jsonError, tokensMatch } from "../../../../../lib/server-session";

type RouteContext = { params: Promise<{ code: string }> };

export async function POST(request: Request, context: RouteContext) {
  try {
    const { code: rawCode } = await context.params;
    const code = normalizeSessionCode(rawCode);
    const token = request.headers.get("x-publisher-token") ?? "";
    const payload = (await request.json()) as {
      batchId?: string;
      events?: Array<{ message?: string; category?: string; source?: string; occurredAt?: string }>;
    };
    const db = getDb();

    const [session] = await db
      .select({ panelFamily: monitorSessions.panelFamily, tokenHash: monitorSessions.publisherTokenHash, isLive: monitorSessions.isLive })
      .from(monitorSessions)
      .where(eq(monitorSessions.code, code))
      .limit(1);

    if (!session) return jsonError("Session not found.", 404);
    if (!token || !(await tokensMatch(token, session.tokenHash))) {
      return jsonError("This device cannot publish to the session.", 403);
    }
    if (!session.isLive) return jsonError("This session has ended.", 409);

    if (payload.batchId && !/^[a-zA-Z0-9-]{16,80}$/.test(payload.batchId))return jsonError('Invalid capture batch.');
    if (!Array.isArray(payload.events) || payload.events.length>100)return jsonError('Send between 1 and 100 events per batch.');
    const incoming = payload.events;
    const batchId=payload.batchId || crypto.randomUUID();
    const raw=getRawDb();
    const digest=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify(incoming))))).map(b=>b.toString(16).padStart(2,'0')).join('');
    const receipt=await raw.prepare('SELECT digest FROM capture_batches WHERE id=?').bind(`${code}:${batchId}`).first<{digest:string}>();
    if(receipt && receipt.digest!==digest)return jsonError('Capture batch does not match its original contents.',409);
    if(receipt)return Response.json({accepted:true,batchId,duplicate:true,events:[]});
    const [previous] = usesNotifierPrinterParser(session.panelFamily) ? await db.select({message:serialEvents.message}).from(serialEvents).where(and(eq(serialEvents.sessionCode,code),eq(serialEvents.source,"serial"))).orderBy(desc(serialEvents.id)).limit(1) : [];
    let previousMessage=previous?.message || "";
    const prepared = incoming
      .map((event) => {
        const message = normalizeMessage(event.message ?? "");
        if (!message) return null;
        const category = usesNotifierPrinterParser(session.panelFamily) && event.source !== "manual" ? notifierEventCategory(message,previousMessage) : isEventCategory(event.category)
          ? event.category
          : classifySerialMessage(message);
        if(event.source !== "manual")previousMessage=message;
        return {
          event: {
            sessionCode: code,
            occurredAt: validCapturedTime(event.occurredAt)?event.occurredAt!:new Date().toISOString(),
            category,
            message,
            source: event.source === "manual" ? "manual" : "serial",
          },
          queue: event.source === "manual" || (session.panelFamily === "notifier-n16" && isNotifierActiveEvent(message)) ? null : deriveQueueMutation(message, category),
        };
      })
      .filter((value): value is NonNullable<typeof value> => Boolean(value));

    if (!prepared.length) return jsonError("No readable serial messages were received.");

    // D1 batch is atomic: a lost response can be retried without replaying queue mutations.
    const statements=[raw.prepare('INSERT INTO capture_batches(id,session_code,digest) VALUES (?,?,?)').bind(`${code}:${batchId}`,code,digest)];
    for(const item of prepared) {
      statements.push(raw.prepare('INSERT INTO serial_events(session_code,batch_id,occurred_at,category,message,source) VALUES (?,?,?,?,?,?)').bind(code,batchId,item.event.occurredAt,item.event.category,item.event.message,item.event.source));
      if(!item.queue)continue;
      const category=item.event.category,key='pointKey' in item.queue ? item.queue.pointKey : '';
      if(item.queue.action==='reset-alarms')statements.push(raw.prepare("DELETE FROM active_signals WHERE session_code=? AND category='alarm'").bind(code));
      else if(item.queue.action==='clear')statements.push(raw.prepare('DELETE FROM active_signals WHERE session_code=? AND category=? AND point_key IN (?,?)').bind(code,category,key,`${category}:${key}`));
      else {
        statements.push(raw.prepare('DELETE FROM active_signals WHERE session_code=? AND category=? AND point_key=?').bind(code,category,key));
        statements.push(raw.prepare('INSERT INTO active_signals(session_code,point_key,category,message) VALUES (?,?,?,?) ON CONFLICT(session_code,point_key) DO UPDATE SET category=excluded.category,message=excluded.message,updated_at=CURRENT_TIMESTAMP').bind(code,`${category}:${key}`,category,item.event.message));
      }
    }
    statements.push(raw.prepare('UPDATE monitor_sessions SET updated_at=CURRENT_TIMESTAMP WHERE code=?').bind(code));
    await raw.batch(statements);
    const inserted=await db.select({id:serialEvents.id,category:serialEvents.category,message:serialEvents.message,source:serialEvents.source,occurredAt:serialEvents.occurredAt}).from(serialEvents).where(and(eq(serialEvents.sessionCode,code),eq(serialEvents.batchId,batchId)));

    const groupedCounts = await db
      .select({ category: activeSignals.category, value: count() })
      .from(activeSignals)
      .where(eq(activeSignals.sessionCode, code))
      .groupBy(activeSignals.category);
    const counts = { alarm: 0, supervisory: 0, trouble: 0, other: 0 };
    for (const row of groupedCounts) {
      if (row.category in counts) counts[row.category as keyof typeof counts] = row.value;
    }

    return Response.json({ accepted:true, batchId, events: inserted, counts: usesNotifierPrinterParser(session.panelFamily) ? await notifierCounts(db,code,session.panelFamily) : counts }, { status: 201 });
  } catch (error) {
    console.error("Unable to publish serial events", error);
    return jsonError("The serial message could not be mirrored.", 500);
  }
}
