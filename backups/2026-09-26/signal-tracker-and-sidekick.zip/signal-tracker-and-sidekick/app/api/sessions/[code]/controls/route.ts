import { getRawDb } from '../../../../../db';
import { hashPublisherToken, tokensMatch, jsonError } from '../../../../../lib/server-session';
import { isE3, isE3Action } from '../../../../../lib/e3-control';
import { normalizeSessionCode } from '../../../../../lib/panelstream';

type Context = { params: Promise<{code:string}> };
export async function POST(request: Request, context: Context) {
  try {
    const code = normalizeSessionCode((await context.params).code);
    const db = getRawDb();
    const session = await db.prepare('SELECT * FROM monitor_sessions WHERE code = ?').bind(code).first<{panel_family:string;publisher_token_hash:string;is_live:number}>();
    if (!session || !isE3(session.panel_family)) return jsonError('E3 controls are unavailable for this panel.', 400);
    const body = await request.json() as Record<string, unknown>;
    const now = Date.now();
    const publisher = await tokensMatch(request.headers.get('x-publisher-token') || '', session.publisher_token_hash);
    const host = await db.prepare('SELECT * FROM e3_control_hosts WHERE session_code = ?').bind(code).first<{epoch:string;key_hash:string;expires_at:number;reset_format:string}>();
    if (body.op === 'host') {
      if (!publisher) return jsonError('Laptop authorization required.', 403);
      if (typeof body.epoch !== 'string' || !/^[a-f0-9-]{36}$/.test(body.epoch) || typeof body.key !== 'string' || !/^[a-f0-9]{16}$/.test(body.key)) return jsonError('Invalid control pairing.');
      const resetFormat = ['text','hex'].includes(String(body.resetFormat)) ? String(body.resetFormat) : '';
      const expires = body.enabled === true && session.is_live ? now + 6000 : 0;
      await db.prepare('INSERT INTO e3_control_hosts (session_code,epoch,key_hash,expires_at,reset_format) VALUES (?,?,?,?,?) ON CONFLICT(session_code) DO UPDATE SET epoch=excluded.epoch,key_hash=excluded.key_hash,expires_at=excluded.expires_at,reset_format=excluded.reset_format').bind(code,body.epoch,await hashPublisherToken(body.key),expires,resetFormat).run();
      // Claim once before returning. Lost responses are never replayed.
      await db.prepare("UPDATE e3_commands SET status='expired',result='Not sent: connection or request expired' WHERE session_code=? AND status='pending' AND (expires_at < ? OR epoch <> ? OR ? = 0)").bind(code,now,body.epoch,expires).run();
      const claimed = expires ? await db.prepare("UPDATE e3_commands SET status='claimed',result='Delivery claimed; panel action unconfirmed' WHERE id=(SELECT id FROM e3_commands WHERE session_code=? AND epoch=? AND status='pending' AND expires_at>=? ORDER BY created_at LIMIT 1) AND status='pending' RETURNING *").bind(code,body.epoch,now).all() : {results:[]};
      return Response.json({commands:claimed.results});
    }
    if (body.op === 'result') {
      if (!publisher || !host || host.epoch !== body.epoch) return jsonError('Laptop authorization expired.',403);
      if (!['sent','unknown','failed'].includes(String(body.status))) return jsonError('Invalid result.');
      await db.prepare("UPDATE e3_commands SET status=?,result=? WHERE id=? AND session_code=? AND epoch=? AND status='claimed'").bind(body.status,String(body.result || '').slice(0,300),body.id,code,body.epoch).run();
      return Response.json({ok:true});
    }
    if (!publisher && (!host || typeof body.key !== 'string' || !(await tokensMatch(body.key,host.key_hash)))) return jsonError('Enter the control key displayed on the laptop.',403);
    if (body.op === 'status') {
      const rows = await db.prepare('SELECT id,action,status,result,created_at,expires_at FROM e3_commands WHERE session_code=? ORDER BY created_at DESC LIMIT 10').bind(code).all();
      return Response.json({ready:Boolean(session.is_live && host && host.expires_at>now),resetFormat:host?.reset_format || '',commands:rows.results});
    }
    if (body.op !== 'request' || !isE3Action(body.action) || typeof body.id !== 'string' || !/^[a-f0-9-]{36}$/.test(body.id)) return jsonError('Invalid control request.');
    if (!session.is_live || !host || host.expires_at<=now || body.epoch && body.epoch!==host.epoch) return jsonError('Laptop controls are off or disconnected. Nothing was queued.',409);
    if (body.action==='reset' && !host.reset_format) return jsonError('Choose the reset test format on the laptop first.');
    const duplicate = await db.prepare('SELECT id FROM e3_commands WHERE id=? AND session_code=?').bind(body.id,code).first();
    if (duplicate) return Response.json({id:body.id});
    const result = await db.prepare("INSERT INTO e3_commands (id,session_code,epoch,action,reset_format,status,created_at,expires_at,result) SELECT ?,?,?,?,?, 'pending',?,?,'' WHERE NOT EXISTS (SELECT 1 FROM e3_commands WHERE session_code=? AND created_at>?) ON CONFLICT(id) DO NOTHING RETURNING id").bind(body.id,code,host.epoch,body.action,host.reset_format,now,now+4000,code,now-2000).all();
    if (!result.results.length) return jsonError('A command was just requested. Check its result before trying another.',409);
    return Response.json({id:body.id});
  } catch { return jsonError('Control service unavailable. Do not assume the panel acted.',503); }
}
