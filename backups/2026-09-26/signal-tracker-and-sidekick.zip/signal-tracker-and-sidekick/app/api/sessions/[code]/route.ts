import { usesNotifierPrinterParser } from "../../../../lib/notifier-format";
import { notifierEventCategory } from "../../../../lib/notifier-event-category";
import { notifierCounts, notifierCountSources } from "../../../../lib/notifier-queue-server";
import { and, asc, count, desc, eq, gt, lt } from "drizzle-orm";
import { getDb } from "../../../../db";
import { activeSignals, monitorSessions, serialEvents } from "../../../../db/schema";
import { normalizeSessionCode } from "../../../../lib/panelstream";
import { jsonError } from "../../../../lib/server-session";

type RouteContext = { params: Promise<{ code: string }> };

export async function GET(request: Request, context: RouteContext) {
  try {
    const { code: rawCode } = await context.params;
    const code = normalizeSessionCode(rawCode);
    const exporting = new URL(request.url).searchParams.get("order") === "asc";
    const requestedSince = Number(new URL(request.url).searchParams.get("since") || 0);
    const since = Number.isFinite(requestedSince) ? Math.max(0, requestedSince) : 0;
    const requestedLimit = Number(new URL(request.url).searchParams.get("limit") || 500);
    const limit = Number.isFinite(requestedLimit) ? Math.min(5000, Math.max(1, requestedLimit)) : 500;
    const db = getDb();

    const [session] = await db
      .select({
        code: monitorSessions.code,
        name: monitorSessions.name,
        panelFamily: monitorSessions.panelFamily,
        isLive: monitorSessions.isLive,
        createdAt: monitorSessions.createdAt,
        updatedAt: monitorSessions.updatedAt,
      })
      .from(monitorSessions)
      .where(eq(monitorSessions.code, code))
      .limit(1);

    if (!session) return jsonError("Session not found.", 404);

    const eventRows = await db
      .select({
        id: serialEvents.id,
        category: serialEvents.category,
        message: serialEvents.message,
        source: serialEvents.source,
        occurredAt: serialEvents.occurredAt,
      })
      .from(serialEvents)
      .where(and(eq(serialEvents.sessionCode, code), gt(serialEvents.id, since)))
      .orderBy((exporting || since > 0) ? asc(serialEvents.id) : desc(serialEvents.id))
      .limit(limit);
    const events = (exporting || since > 0) ? eventRows : eventRows.reverse();

    if(usesNotifierPrinterParser(session.panelFamily) && events.length) {
      const [previous]=await db.select({message:serialEvents.message}).from(serialEvents).where(and(eq(serialEvents.sessionCode,code),eq(serialEvents.source,"serial"),lt(serialEvents.id,events[0].id))).orderBy(desc(serialEvents.id)).limit(1);
      let previousMessage=previous?.message || "";
      for(const event of events)if(event.source === "serial") { event.category=notifierEventCategory(event.message,previousMessage);previousMessage=event.message; }
    }
    const groupedCounts = await db
      .select({ category: activeSignals.category, value: count() })
      .from(activeSignals)
      .where(eq(activeSignals.sessionCode, code))
      .groupBy(activeSignals.category);

    const counts = { alarm: 0, supervisory: 0, trouble: 0, other: 0 };
    for (const row of groupedCounts) {
      if (row.category in counts) {
        counts[row.category as keyof typeof counts] = row.value;
      }
    }

    return Response.json({ session, events, queueSources:usesNotifierPrinterParser(session.panelFamily)?await notifierCountSources(db,code,session.panelFamily):[], counts: usesNotifierPrinterParser(session.panelFamily) ? await notifierCounts(db,code,session.panelFamily) : counts });
  } catch (error) {
    console.error("Unable to load monitoring session", error);
    return jsonError("The live feed is temporarily unavailable.", 500);
  }
}
