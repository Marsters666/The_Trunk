import { hasAccess } from '../../../lib/site-access';
export async function GET(request:Request){const authorized=await hasAccess(request);return Response.json({authorized},{status:authorized?200:401,headers:{'Cache-Control':'no-store'}});}
