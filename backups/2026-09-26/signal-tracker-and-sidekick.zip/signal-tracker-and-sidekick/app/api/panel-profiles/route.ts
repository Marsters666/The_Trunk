import { and, eq } from 'drizzle-orm';
import { getDb } from '../../../db';
import { panelProfiles } from '../../../db/schema';
import { PANEL_OPTIONS } from '../../../lib/wiring-guides';
import { validProfile, type PanelProfile } from '../../../lib/panel-profiles';
export async function GET() {
 try { return Response.json({profiles:(await getDb().select().from(panelProfiles)).map(profile => profile.flowMode !== "none" ? {...profile,flowMode:"none",verified:false} : profile)}, {headers:{'Cache-Control':'no-store'}}); }
 catch { return Response.json({error:'Unable to load saved panel profiles.'},{status:503}); }
}
export async function POST(request: Request) {
 try {
  const body = await request.json() as Partial<PanelProfile> & {expectedRevision?:number; confirmVerified?:boolean};
  if (!validProfile(body) || !Number.isSafeInteger(body.expectedRevision) || body.expectedRevision! < 0) return Response.json({error:'Enter a panel name, valid baud rate (50–4,000,000), data bits, parity, stop bits and flow control.'},{status:400});
  const db=getDb();
  const id=body.id || `custom-${crypto.randomUUID()}`;
  if (!/^custom-[a-f0-9-]{36}$/.test(id) && !PANEL_OPTIONS.some(p=>p.value===id && id!=='other')) return Response.json({error:'Invalid panel profile.'},{status:400});
  const values={id,name:body.name!.trim(),baudRate:String(Number(body.baudRate)),dataBits:body.dataBits!,parity:body.parity!,stopBits:body.stopBits!,flowMode:body.flowMode!,revision:body.expectedRevision!+1,verified:body.confirmVerified===true,updatedAt:new Date().toISOString()};
  const result=body.expectedRevision===0
   ? await db.insert(panelProfiles).values(values).onConflictDoNothing().returning()
   : await db.update(panelProfiles).set(values).where(and(eq(panelProfiles.id,id),eq(panelProfiles.revision,body.expectedRevision!))).returning();
  if (!result.length) return Response.json({error:'This profile changed on another device. Reload the profiles and review the latest settings before saving.'},{status:409});
  return Response.json({profile:result[0]});
 } catch { return Response.json({error:'The panel profile could not be saved. Your changes have not been stored.'},{status:503}); }
}
