'use client';
import { useEffect, useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { Button } from '@/components/ui/button';
import { Smartphone } from 'lucide-react';

export function SidekickSetup({session,onCapture,compact=false}:{compact?:boolean;session:{code:string;name:string}|null;onCapture:()=>void}) {
 const [origin,setOrigin]=useState('');
 useEffect(()=>setOrigin(window.location.origin),[]);
 const autoUrl=origin&&session?`${origin}/?mode=companion&session=${encodeURIComponent(session.code)}`:'';
 return <section className={`sidekick-setup${compact ? " is-compact" : ""}`} aria-label="SideKick phone setup">{!compact ? <div className="sidekick-setup-heading"><Smartphone/><div><h1>SideKick Phone App</h1><p>Connect your phone to this laptop’s monitoring session.</p></div><Button variant="outline" onClick={onCapture}>Back to laptop capture</Button></div> : null}
 {session?<div className="sidekick-pair-grid"><section className="sidekick-qr-card"><h2>Scan to pair automatically</h2><p>Open your phone’s camera, point it at this QR code, and tap the link. SideKick opens already paired to <strong>{session.name}</strong>.</p><div className="sidekick-qr">{autoUrl?<QRCodeSVG value={autoUrl} size={256} level="M" marginSize={4} title={`Pair SideKick with ${session.name}, code ${session.code}`} />:<p>Preparing QR code…</p>}</div><p>One code per laptop session. Phones scanning this code join only this session.</p></section>
</div>:<section className="sidekick-link-card"><h2>Start a laptop session first</h2><p>Create a monitoring session in Laptop capture. Its unique QR code will appear here.</p><Button onClick={onCapture}>Go to Laptop capture</Button></section>}
 </section>;
}
