'use client';
import {useRef,useState} from 'react';
import {Button} from '@/components/ui/button';
import {FolderOpen,Printer,Share2,FileText} from 'lucide-react';
import {readReportSheets,reportFileKind,type ReportSheet} from '@/lib/existing-report';

export function ExistingReport(){
  const input=useRef<HTMLInputElement>(null);
  const selection=useRef(0);
  const [file,setFile]=useState<File|null>(null);
  const [sheets,setSheets]=useState<ReportSheet[]|null>(null);
  const [busy,setBusy]=useState(false);
  const [message,setMessage]=useState('');
  const [error,setError]=useState('');
  async function choose(next?:File){
    if(!next)return;
    const revision=++selection.current;
    setError('');setMessage('');setSheets(null);setFile(null);setBusy(false);
    const kind=reportFileKind(next.name);
    if(!kind){setError('Choose a PDF, XLSX or XLS report.');return;}
    if(next.size>25*1024*1024){setError('Choose a report smaller than 25 MB.');return;}
    setFile(next);
    if(kind==='excel'){
      setBusy(true);
      try {const parsed=await readReportSheets(await next.arrayBuffer());if(selection.current===revision)setSheets(parsed);}
      catch(e){if(selection.current===revision)setError(e instanceof Error?e.message:'Unable to read this workbook. Try opening it in Excel.');}
      finally{if(selection.current===revision)setBusy(false);}
    }
  }
  function preview(){
    if(!file)return;
    setError('');
    if(reportFileKind(file.name)==='pdf'){
      const url=URL.createObjectURL(new Blob([file],{type:'application/pdf'}));
      const opened=window.open(url,'_blank');
      if(!opened){URL.revokeObjectURL(url);setError('Allow pop-ups to open this report.');return;}
      opened.opener=null;window.setTimeout(()=>URL.revokeObjectURL(url),600000);
      setMessage('PDF opened. Use the PDF viewer’s Print button.');return;
    }
    if(!sheets)return;
    const page=window.open('','_blank');
    if(!page){setError('Allow pop-ups to preview and print the workbook.');return;}
    page.opener=null;const doc=page.document;doc.title=file.name;
    const style=doc.createElement('style');style.textContent='body{font:14px system-ui;color:#172c3c;background:white;margin:24px}button{padding:12px 20px;font:inherit;cursor:pointer}section{break-before:page}section:first-of-type{break-before:auto}table{border-collapse:collapse;width:100%;table-layout:fixed}td{border:1px solid #9badb8;padding:6px;white-space:pre-wrap;overflow-wrap:anywhere;vertical-align:top}tr:first-child{font-weight:bold;background:#eaf0f5}h1{font-size:20px;overflow-wrap:anywhere}h2{font-size:17px}@page{size:landscape;margin:12mm}@media print{body{margin:0;font-size:9pt}button,.print-note{display:none}tr{break-inside:avoid}}';doc.head.appendChild(style);
    const heading=doc.createElement('h1');heading.textContent=file.name;doc.body.appendChild(heading);
    const note=doc.createElement('p');note.className='print-note';note.textContent='All worksheets, using saved cell values. Original Excel formatting may differ.';doc.body.appendChild(note);
    const print=doc.createElement('button');print.textContent='Print report';print.addEventListener('click',()=>page.print());doc.body.appendChild(print);
    for(const sheet of sheets){const section=doc.createElement('section'),title=doc.createElement('h2');title.textContent=sheet.name;section.appendChild(title);const table=doc.createElement('table');for(const row of sheet.rows){const tr=doc.createElement('tr');for(const value of row){const td=doc.createElement('td');td.textContent=value;tr.appendChild(td);}table.appendChild(tr);}section.appendChild(table);doc.body.appendChild(section);}
    setMessage('Workbook preview opened. Select Print report in the new tab.');
  }
  async function share(){
    if(!file)return;setError('');
    try {
      if(navigator.share && navigator.canShare?.({files:[file]})){
        await navigator.share({files:[file],title:file.name});setMessage('Report handed to your selected sharing app.');
      }else{
        window.location.href=`mailto:?subject=${encodeURIComponent('Signal Tracker report — '+file.name)}&body=${encodeURIComponent('Please see the attached report: '+file.name+'\n\n[Attach this file from your device before sending.]')}`;
        setMessage(`Email draft opened. Attach “${file.name}” from your device before sending. This browser cannot attach files to email drafts automatically.`);
      }
    }catch(e){if(!(e instanceof DOMException&&e.name==='AbortError'))setError('Sharing could not open. Attach the selected report directly in your email app.');}
  }
  return <section className="existing-report" aria-label="Existing report file"><input ref={input} type="file" accept=".pdf,.xlsx,.xls,application/pdf,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel" aria-label="Choose existing report file" onChange={e=>{void choose(e.target.files?.[0]);e.target.value='';}} className="report-file-input"/>
    <Button variant="outline" onClick={()=>input.current?.click()} disabled={busy}><FolderOpen/>{file?'Choose a different report':'Browse this device'}</Button>
    <p>Choose a saved PDF or Excel report from your computer or phone. No active monitoring session is required.</p>
    {file?<div className="selected-report"><FileText/><div><strong>{file.name}</strong><span>{(file.size/1024).toFixed(1)} KB{busy?' · Reading workbook…':sheets?` · ${sheets.length} worksheets`:''}</span></div></div>:null}
    {error?<p role="alert" className="access-error">{error}</p>:null}
    {message?<p role="status">{message}</p>:null}
    <div className="report-actions"><Button onClick={preview} disabled={!file||busy||(reportFileKind(file.name)==='excel'&&!sheets)}><Printer/>Print / preview file</Button><Button variant="outline" onClick={()=>void share()} disabled={!file||busy}><Share2/>Share / email file</Button></div>
    <p className="micro-copy">Files stay on this device until you choose to share. If your browser cannot share attachments, the email draft will ask you to attach the file manually.</p>
  </section>;
}
