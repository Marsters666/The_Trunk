import type { Metadata, Viewport } from "next";
import "./globals.css";
import { AppearanceProvider } from "./appearance";

export const viewport: Viewport = { width:"device-width", initialScale:1, viewportFit:"cover" };

export const metadata: Metadata = {
  title: "Signal Tracker",
  description: "Capture fire alarm panel RS-232 events on a laptop and mirror the private live feed to Signal Tracker Sidekick.",
  manifest: "/manifest.webmanifest",
  applicationName: "Signal Tracker",
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "Signal Tracker Sidekick",
  },
  other: { "mobile-web-app-capable": "yes" },
  icons: {
    icon: "/signal-tracker-logo.png",
    shortcut: "/signal-tracker-logo.png",
    apple: "/signal-tracker-logo.png",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body><AppearanceProvider>{children}</AppearanceProvider></body>
    </html>
  );
}
