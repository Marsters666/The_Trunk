"use client";
import { createContext, useContext, useEffect, useState } from "react";
export type Palette = "graphite" | "ocean" | "forest" | "crimson";
type Theme = "dark" | "light";
const Appearance = createContext<{theme:Theme;setTheme:(theme:Theme)=>void;palette:Palette;setPalette:(palette:Palette)=>void}>({theme:"dark",setTheme:()=>{},palette:"graphite",setPalette:()=>{}});
export function AppearanceProvider({children}:{children:React.ReactNode}) {
  const [palette, updatePalette] = useState<Palette>("graphite");
  const [theme, updateTheme] = useState<Theme>("dark");
  useEffect(() => { try { const saved = localStorage.getItem("signal-tracker-theme"); if(saved === "light" || saved === "dark") { updateTheme(saved); document.documentElement.dataset.theme = saved; } } catch {} }, []);
  useEffect(() => { try { const saved=localStorage.getItem("signal-tracker-palette"); if(saved==="graphite" || saved==="ocean" || saved==="forest" || saved==="crimson") {updatePalette(saved);document.documentElement.dataset.palette=saved;} } catch {} }, []);
  const setPalette=(value:Palette)=>{updatePalette(value);document.documentElement.dataset.palette=value;try{localStorage.setItem("signal-tracker-palette",value);}catch{}};
  const setTheme = (value:Theme) => { updateTheme(value); document.documentElement.dataset.theme = value; try { localStorage.setItem("signal-tracker-theme",value); } catch {} };
  return <Appearance.Provider value={{theme,setTheme,palette,setPalette}}>{children}</Appearance.Provider>;
}
export const useAppearance = () => useContext(Appearance);
