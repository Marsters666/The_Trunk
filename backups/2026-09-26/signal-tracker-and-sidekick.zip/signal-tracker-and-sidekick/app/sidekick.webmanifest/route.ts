export function GET(request:Request) {
 const code=new URL(request.url).searchParams.get('session') || '';
 const start=/^[A-HJ-NP-Z2-9]{8}$/.test(code)?`/?mode=companion&session=${code}`:'/?mode=companion&pair=manual';
 return Response.json({id:'/sidekick',name:'SideKick',short_name:'SideKick',description:'Your paired Signal Tracker phone feed',start_url:start,scope:'/',display:'standalone',background_color:'#070a0d',theme_color:'#0a0e12',icons:[{src:'/sidekick-192.png',sizes:'192x192',type:'image/png',purpose:'any'},{src:'/sidekick-512.png',sizes:'512x512',type:'image/png',purpose:'any'}]},{headers:{'Content-Type':'application/manifest+json','Cache-Control':'no-store'}});
}
