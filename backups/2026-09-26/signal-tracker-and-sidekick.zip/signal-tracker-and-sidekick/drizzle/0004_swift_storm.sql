CREATE TABLE `e3_commands` (
	`id` text PRIMARY KEY NOT NULL,
	`session_code` text NOT NULL,
	`epoch` text NOT NULL,
	`action` text NOT NULL,
	`reset_format` text NOT NULL,
	`status` text NOT NULL,
	`created_at` integer NOT NULL,
	`expires_at` integer NOT NULL,
	`result` text DEFAULT '' NOT NULL,
	FOREIGN KEY (`session_code`) REFERENCES `monitor_sessions`(`code`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `idx_e3_commands_session_status` ON `e3_commands` (`session_code`,`status`);--> statement-breakpoint
CREATE TABLE `e3_control_hosts` (
	`session_code` text PRIMARY KEY NOT NULL,
	`epoch` text NOT NULL,
	`key_hash` text NOT NULL,
	`expires_at` integer NOT NULL,
	`reset_format` text NOT NULL,
	FOREIGN KEY (`session_code`) REFERENCES `monitor_sessions`(`code`) ON UPDATE no action ON DELETE cascade
);
