CREATE TABLE `delivery_health` (
	`session_code` text PRIMARY KEY NOT NULL,
	`probe` text NOT NULL,
	`publisher_at` integer NOT NULL,
	FOREIGN KEY (`session_code`) REFERENCES `monitor_sessions`(`code`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE TABLE `delivery_receipts` (
	`id` text PRIMARY KEY NOT NULL,
	`session_code` text NOT NULL,
	`probe` text NOT NULL,
	`received_at` integer NOT NULL,
	`event_id` integer NOT NULL,
	FOREIGN KEY (`session_code`) REFERENCES `monitor_sessions`(`code`) ON UPDATE no action ON DELETE cascade
);
