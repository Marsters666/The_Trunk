CREATE TABLE `monitor_sessions` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`code` text NOT NULL,
	`name` text NOT NULL,
	`panel_family` text NOT NULL,
	`publisher_token_hash` text NOT NULL,
	`is_live` integer DEFAULT true NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`updated_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_monitor_sessions_code` ON `monitor_sessions` (`code`);--> statement-breakpoint
CREATE TABLE `serial_events` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`session_code` text NOT NULL,
	`category` text NOT NULL,
	`message` text NOT NULL,
	`source` text DEFAULT 'serial' NOT NULL,
	`occurred_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	FOREIGN KEY (`session_code`) REFERENCES `monitor_sessions`(`code`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `idx_serial_events_session_id` ON `serial_events` (`session_code`,`id`);--> statement-breakpoint
CREATE INDEX `idx_serial_events_session_category` ON `serial_events` (`session_code`,`category`);--> statement-breakpoint
PRAGMA optimize;
