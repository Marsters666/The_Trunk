CREATE TABLE `panel_profiles` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`baud_rate` text NOT NULL,
	`data_bits` text NOT NULL,
	`parity` text NOT NULL,
	`stop_bits` text NOT NULL,
	`flow_mode` text NOT NULL,
	`revision` integer DEFAULT 1 NOT NULL,
	`verified` integer DEFAULT false NOT NULL,
	`updated_at` text NOT NULL
);
