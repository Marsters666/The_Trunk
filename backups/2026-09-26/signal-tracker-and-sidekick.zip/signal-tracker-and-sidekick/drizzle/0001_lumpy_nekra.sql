CREATE TABLE `active_signals` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`session_code` text NOT NULL,
	`point_key` text NOT NULL,
	`category` text NOT NULL,
	`message` text NOT NULL,
	`first_seen_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`updated_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	FOREIGN KEY (`session_code`) REFERENCES `monitor_sessions`(`code`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_active_signals_session_point` ON `active_signals` (`session_code`,`point_key`);--> statement-breakpoint
CREATE INDEX `idx_active_signals_session_category` ON `active_signals` (`session_code`,`category`);