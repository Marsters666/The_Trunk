CREATE TABLE `capture_batches` (
	`id` text PRIMARY KEY NOT NULL,
	`session_code` text NOT NULL,
	`digest` text NOT NULL,
	FOREIGN KEY (`session_code`) REFERENCES `monitor_sessions`(`code`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
ALTER TABLE `serial_events` ADD `batch_id` text;